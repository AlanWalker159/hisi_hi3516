/*
 * Copyright (c) Hisilicon Technologies Co., Ltd. 2020-2020. All rights reserved.
 * Description: sample_svp_nnie_check_software_param.h
 * Author: Hisilicon multimedia software (SVP) group
 * Create: 2020-03-10
 */

#ifndef _SAMPLE_SVP_NNIE_CHECK_SOFTWARE_PARAM_H_
#define _SAMPLE_SVP_NNIE_CHECK_SOFTWARE_PARAM_H_

#include "sample_common_nnie.h"
#include "sample_svp_nnie_software.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */
hi_s32 sample_svp_nnie_check_and_fill_cnn_get_top_n_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_cnn_sw_param *sw_param, sample_svp_nnie_cnn_get_top_n_param *param);

hi_s32 sample_svp_nnie_check_rpn_tmp_buf_size_param(hi_u32 ratio_anchors_num, hi_u32 scale_anchors_num,
    hi_u32 conv_height, hi_u32 conv_width, hi_u32 *total_size);

hi_s32 sample_svp_nnie_check_rpn_generate_anchor_box_param(sample_svp_nnie_rpn_generate_base_anchor_param *param,
    hi_bool is_used_for_sw);

hi_s32 sample_svp_nnie_check_and_fill_faster_rcnn_rpn_param(sample_svp_nnie_faster_rcnn_sw_param *sw_param,
    sample_svp_nnie_rpn_param *param);

hi_s32 sample_svp_nnie_check_and_fill_faster_rcnn_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_faster_rcnn_sw_param *sw_param, sample_svp_nnie_faster_rcnn_get_result_param *param);

hi_s32 sample_svp_nnie_check_and_fill_rfcn_rpn_param(sample_svp_nnie_rfcn_sw_param *sw_param,
    sample_svp_nnie_rpn_param *param);

hi_s32 sample_svp_nnie_check_and_fill_rfcn_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_rfcn_sw_param *sw_param, sample_svp_nnie_rfcn_get_result_param *param);

hi_s32 sample_svp_nnie_check_and_fill_ssd_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_ssd_sw_param *sw_param, sample_svp_nnie_ssd_get_result_param *param);

hi_s32 sample_svp_nnie_check_ssd_generate_prior_box_param(sample_svp_nnie_ssd_generate_prior_box_param *param,
    hi_bool is_used_for_sw);

hi_s32 sample_svp_nnie_check_and_fill_yolov1_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov1_sw_param *sw_param, sample_svp_nnie_yolov1_get_result_param *param);

hi_s32 sample_svp_nnie_check_and_fill_yolov2_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov2_sw_param *sw_param, sample_svp_nnie_yolov2_get_result_param *param);

hi_s32 sample_svp_nnie_check_and_fill_yolov3_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov3_sw_param *sw_param, sample_svp_nnie_yolov3_get_result_param *param);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* _SAMPLE_SVP_NNIE_CHECK_SOFTWARE_PARAM_H_ */

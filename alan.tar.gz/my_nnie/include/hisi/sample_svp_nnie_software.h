/*
 * Copyright (c) Hisilicon Technologies Co., Ltd. 2019-2019. All rights reserved.
 * Description: sample_svp_nnie_software.h
 * Author: Hisilicon multimedia software (SVP) group
 * Create: 2019-08-20
 */

#ifndef _SAMPLE_SVP_NNIE_SOFTWARE_H_
#define _SAMPLE_SVP_NNIE_SOFTWARE_H_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "sample_common_nnie.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */

#define sample_svp_nnie_max(a, b)    (((a) > (b)) ? (a) : (b))
#define sample_svp_nnie_min(a, b)    (((a) < (b)) ? (a) : (b))
#define sample_svp_nnie_sigmoid(x)   (hi_float)(1.0f / (1 + exp(-(x))))

#define SAMPLE_SVP_NNIE_ADDR_ALIGN_16                       16 /* 16 byte alignment */
#define SAMPLE_SVP_NNIE_COORD_NUM                            4 /* coordinate numbers */
#define SAMPLE_SVP_NNIE_PROPOSAL_WIDTH                       6 /* the number of proposal values */
#define SAMPLE_SVP_NNIE_QUANT_BASE                        4096 /* the base value */
#define SAMPLE_SVP_NNIE_SCORE_NUM                            2 /* the num of RPN scores */
#define SAMPLE_SVP_NNIE_HALF                              0.5f /* the half value */
#define SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM               3 /* yolov3 report blob num */
#define SAMPLE_SVP_NNIE_YOLOV3_EACH_GRID_BIAS_NUM            6 /* yolov3 bias num of each grid */
#define SAMPLE_SVP_NNIE_YOLOV3_EACH_BBOX_INFER_RESULT_NUM   85 /* yolov3 inference result num of each bbox */
#define SAMPLE_SVP_NNIE_RFCN_SCORE_BLOB_OFFSET              1
#define SAMPLE_SVP_NNIE_RFCN_DELTA_BLOB_OFFSET              2

/* CNN get_top_n unit */
typedef struct {
    hi_u32   class_id;
    hi_u32   conf;
} sample_svp_nnie_cnn_get_top_n_unit;

typedef struct {
    hi_s32 *fc;
    hi_u32 fc_stride;
    hi_u32 class_num;
    hi_u32 batch_num;
    hi_u32 top_n;
    hi_s32 *tmp_buf;
    hi_u32 top_n_stride;
    hi_s32 *get_top_n;
} sample_svp_nnie_cnn_get_top_n_param;

/* stack for sort */
typedef struct {
    hi_s32 min;
    hi_s32 max;
} sample_svp_nnie_stack;

/* stack for sort */
typedef struct {
    hi_s32 x_min;
    hi_s32 y_min;
    hi_s32 x_max;
    hi_s32 y_max;
} sample_svp_nnie_bbox;

typedef struct {
    hi_float center_x;
    hi_float center_y;
    hi_float base_width;
    hi_float base_height;
} sample_svp_nnie_base_box;

typedef struct {
    hi_u32 height_idx;
    hi_u32 width_idx;
    hi_u32 pixel_interval;
    hi_bool is_used_for_sw;
} sample_svp_nnie_anchor_box_ctrl_info;

typedef struct {
    hi_s32 *mem_addr;
    hi_s32 *x_min;
    hi_s32 *y_min;
    hi_s32 *x_max;
    hi_s32 *y_max;
} sample_svp_nnie_anchor_box_dst;

typedef sample_svp_nnie_anchor_box_dst sample_svp_nnie_prior_box_dst;

typedef struct {
    hi_s32 *x_min_var;
    hi_s32 *y_min_var;
    hi_s32 *x_max_var;
    hi_s32 *y_max_var;
} sample_svp_nnie_var_dst;

typedef struct {
    hi_u32 offset;
    hi_u32 var_idx;
    hi_u32 node_idx;
    hi_u32 aspect_ratio_num;
    hi_float *aspect_ratio;
    hi_bool is_used_for_sw;
} sample_svp_nnie_prior_box_ctrl_info;

/* rpn gen base anchor param */
typedef struct {
    hi_u32 ratio_anchor_num;
    hi_u32 scale_anchor_num;
    hi_u32 scales[SAMPLE_SVP_NNIE_RPN_MAX_SCALE_NUM];
    hi_u32 ratios[SAMPLE_SVP_NNIE_RPN_MAX_RATIO_NUM];
    hi_u32 feature_map_height;
    hi_u32 feature_map_width;
    hi_u32 min_size;
    hi_u32 spatial_scale;
    hi_u32 stride;
    hi_s32 *dst;
    hi_u32 dst_size;
} sample_svp_nnie_rpn_generate_base_anchor_param;

/* rpn param */
typedef struct {
    hi_s32 *src[SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM];
    hi_u32 ratio_anchor_num;
    hi_u32 scale_anchor_num;
    hi_u32 ori_img_height;
    hi_u32 ori_img_width;
    hi_u32 conv_num;
    hi_u32 conv_height[SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM];
    hi_u32 conv_width[SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM];
    hi_u32 conv_channel[SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM];
    hi_u32 conv_stride[SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM];
    hi_u32 max_rois;
    hi_u32 min_size;
    hi_u32 spatial_scale;
    hi_u32 nms_threshold;
    hi_u32 filter_threshold;
    hi_u32 num_before_nms;
    hi_s32 *base_anchor;
    hi_u32 *mem_pool;
    hi_u32 dst_stride;
    hi_s32 *proposal_result;
    hi_u32 *num_rois;
} sample_svp_nnie_rpn_param;

typedef struct {
    hi_s32 *bbox_delta;
    hi_u32 bbox_delta_stride;
    hi_s32 *score;
    hi_u32 score_stride;
    hi_s32 *bbox;
    hi_u32 bbox_stride;
    hi_bool is_rpn_sw;
    hi_u32 roi_num;
    hi_u32 *conf_threshold;
    hi_u32 nms_threshold;
    hi_u32 max_roi;
    hi_u32 class_num;
    hi_u32 ori_img_width;
    hi_u32 ori_img_height;
    hi_u32 *mem_pool;
    hi_s32 *dst_score;
    hi_s32 *dst_bbox;
    hi_s32 *class_roi_num;
} sample_svp_nnie_faster_rcnn_get_result_param;

typedef struct {
    hi_u32 roi_idx;
    hi_u32 class_id;
    hi_u32 bbox_delta_idx;
    hi_s32 *bbox_delta;
} sample_svp_nnie_faster_rcnn_rfcn_get_bbox_ctrl_info;

typedef sample_svp_nnie_faster_rcnn_get_result_param sample_svp_nnie_rfcn_get_result_param;

/* ssd gen prior box param */
typedef struct {
    hi_u32 prior_box_width[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_u32 prior_box_height[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_float prior_box_min_size[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM][1];
    hi_float prior_box_max_size[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM][1];
    hi_u32 min_size_num;
    hi_u32 max_size_num;
    hi_u32 ori_img_height;
    hi_u32 ori_img_width;
    hi_u32 input_aspect_ratio_num[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_float prior_box_aspect_ratio[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM][SAMPLE_SVP_NNIE_SSD_MAX_ASPECT_RATIO_NUM];
    hi_float prior_box_step_width[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_float prior_box_step_height[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_float offset;
    hi_bool flip_flag;
    hi_bool clip_flag;
    hi_s32 prior_box_var[SAMPLE_SVP_NNIE_SSD_PRIOR_BOX_VAR_NUM];
    hi_s32 *prior_box[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_u32 prior_box_size[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_u32 dst_stride;
    hi_s32 *dst;
    hi_u32 dst_size;
} sample_svp_nnie_ssd_generate_prior_box_param;

/* stack for sort */
typedef struct {
    hi_u32 mem_offset[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_u32 total_size;
} sample_svp_nnie_ssd_prior_box_mem;

typedef struct {
    hi_u32 concat_num;
    hi_u32 conf_threshold;
    hi_u32 class_num;
    hi_u32 top_k;
    hi_u32 keep_top_k;
    hi_u32 nms_threshold;
    hi_u32 prior_box_num;
    hi_u32 loc_blob_height[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_u32 loc_blob_width[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_u32 loc_blob_chn[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_u32 loc_blob_stride[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_s32 *loc_addr[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_u32 conf_blob_height[SAMPLE_SVP_NNIE_SSD_REPORT_CONF_NODE_NUM];
    hi_u32 conf_blob_width[SAMPLE_SVP_NNIE_SSD_REPORT_CONF_NODE_NUM];
    hi_u32 conf_blob_chn[SAMPLE_SVP_NNIE_SSD_REPORT_CONF_NODE_NUM];
    hi_u32 conf_blob_stride[SAMPLE_SVP_NNIE_SSD_REPORT_CONF_NODE_NUM];
    hi_s32 *conf_addr[SAMPLE_SVP_NNIE_SSD_REPORT_CONF_NODE_NUM];
    hi_s32 *conf_scores;
    hi_s32 *prior_box[SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM];
    hi_s32 *assist_mem_pool;
    hi_s32 *dst_score;
    hi_s32 *dst_roi;
    hi_s32 *class_roi_num;
} sample_svp_nnie_ssd_get_result_param;

/* stack for sort */
typedef struct {
    hi_u32 idx;
    hi_s32 score;
} sample_svp_nnie_yolov1_score;

typedef struct {
    hi_s32 *fc_result;
    hi_u32 class_num;
    hi_u32 bbox_num_each_grid;
    hi_u32 grid_num_height;
    hi_u32 grid_num_width;
    hi_u32 conf_threshold;
    hi_u32 nms_threshold;
    hi_u32 ori_img_width;
    hi_u32 ori_img_height;
    hi_s32 *tmp_buf;
    hi_s32 *dst_scores;
    hi_s32 *dst_roi;
    hi_s32 *class_roi_num;
} sample_svp_nnie_yolov1_get_result_param;

typedef struct {
    hi_float x_min;
    hi_float x_max;
    hi_float y_min;
    hi_float y_max;
    hi_s32 cls_score;
    hi_u32 class_idx;
    hi_u32 mask;
} sample_svp_nnie_yolov2_bbox;

typedef struct {
    hi_s32 *input_data;
    hi_u32 grid_num_width;
    hi_u32 grid_num_height;
    hi_u32 bbox_num_each_grid;
    hi_u32 class_num;
    hi_u32 ori_img_width;
    hi_u32 ori_img_height;
    hi_u32 nms_threshold;
    hi_u32 conf_threshold;
    hi_float *bias;
    hi_u32 *tmp_buf;
    hi_s32 *dst_score;
    hi_s32 *dst_roi;
    hi_s32 *class_roi_num;
} sample_svp_nnie_yolov2_get_result_param;

typedef sample_svp_nnie_yolov2_bbox sample_svp_nnie_yolov3_bbox;

typedef struct {
    hi_s32 *input_blob[SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM];
    hi_u32 input_stride[SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM];
    hi_u32 *grid_num_width;
    hi_u32 *grid_num_height;
    hi_u32 bbox_num_each_grid;
    hi_u32 class_num;
    hi_u32 ori_img_width;
    hi_u32 ori_img_height;
    hi_u32 nms_threshold;
    hi_u32 conf_threshold;
    hi_float bias[SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM][SAMPLE_SVP_NNIE_YOLOV3_BIAS_NUM];
    hi_u32 *tmp_buf;
    hi_s32 *dst_score;
    hi_s32 *dst_roi;
    hi_s32 *class_roi_num;
} sample_svp_nnie_yolov3_get_result_param;

/* CNN */
hi_s32 sample_svp_nnie_cnn_get_top_n(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_cnn_sw_param *sw_param);

/* gen rpn anchor */
hi_u32 sample_svp_nnie_rpn_tmp_buf_size(hi_u32 ratio_anchor_num,
    hi_u32 scale_anchor_num, hi_u32 conv_height, hi_u32 conv_width, hi_u32 *total_size);

hi_s32 sample_svp_nnie_rpn_generate_anchor_box(sample_svp_nnie_rpn_generate_base_anchor_param *param,
    hi_bool is_used_for_sw);

/* faster_rcnn */
hi_s32 sample_svp_nnie_faster_rcnn_rpn(sample_svp_nnie_faster_rcnn_sw_param *sw_param);

hi_s32 sample_svp_nnie_faster_rcnn_get_result(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_faster_rcnn_sw_param *sw_param);

/* RFCN */
hi_s32 sample_svp_nnie_rfcn_rpn(sample_svp_nnie_rfcn_sw_param *sw_param);

hi_s32 sample_svp_nnie_rfcn_get_result(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_rfcn_sw_param *sw_param);

/* SSD */
hi_s32 sample_svp_nnie_ssd_generate_prior_box(sample_svp_nnie_ssd_generate_prior_box_param *param,
    hi_bool is_used_for_sw);

hi_s32 sample_svp_nnie_ssd_get_result(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_ssd_sw_param *sw_param);

/* YOLOV1 */
hi_s32 sample_svp_nnie_yolov1_get_result(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov1_sw_param *sw_param);

/* YOLOV2 */
hi_s32 sample_svp_nnie_yolov2_get_result(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov2_sw_param *sw_param);

/* YOLOV3 */
hi_s32 sample_svp_nnie_yolov3_get_result(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov3_sw_param *sw_param);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* _SAMPLE_SVP_NNIE_SOFTWARE_H_ */

#ifndef __YOLO__H__
#define __YOLO__H__

#ifdef __cplusplus
extern "C"{
#endif


#include "hi_type.h"

/* the image format of the input of the yolov3 model */
#define DEFAULT_CHANNELS  3
#define MODEL_IMG_WIDTH    416
#define MODEL_IMG_HEIGHT   416


/* function : show yolov1 sample */
hi_void sample_svp_nnie_yolov1_detect_out_sw(hi_void);
hi_void sample_svp_nnie_yolov1_detect_out_hw(hi_void);

/* function : show yolov2 sample */
hi_void sample_svp_nnie_yolov2_detect_out_sw(hi_void);
hi_void sample_svp_nnie_yolov2_detect_out_hw(hi_void);

/* function : show yolov3 sample */
hi_void sample_svp_nnie_yolov3_detect_out_sw(hi_void);
hi_void sample_svp_nnie_yolov3_detect_out_hw(hi_void);

/* function : yolov1 sample signal handle */
hi_void sample_svp_nnie_yolov1_handle_sig(hi_void);

/* function : yolov2 sample signal handle */
hi_void sample_svp_nnie_yolov2_handle_sig(hi_void);

/* function : yolov3 sample signal handle */
hi_void sample_svp_nnie_yolov3_handle_sig(hi_void);

#ifdef __cplusplus
}
#endif

#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>


#include <string>
#include <iostream>
#include <vector>
#include <algorithm>


#include "sample_svp_nnie_yolo.hpp"


int main(int argc, char *argv[])
{
    printf("-------------[][%s][]--------------- \n", __func__);

    sample_svp_nnie_yolov3_detect_out_hw();

    return 0;
}

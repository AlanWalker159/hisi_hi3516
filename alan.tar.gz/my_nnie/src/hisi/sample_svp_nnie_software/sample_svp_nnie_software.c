/*
 * Copyright (c) Hisilicon Technologies Co., Ltd. 2019-2020. All rights reserved.
 * Description: sample_svp_nnie_software.c
 * Author: Hisilicon multimedia software (SVP) group
 * Create: 2019-08-20
 */

#include "../../../include/hisi/sample_svp_nnie_software.h"
#include "../../../include/hisi/sample_svp_nnie_check_software_param.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */

#define SAMPLE_SVP_NNIE_EXP_COEF_ROW_NUM  10
#define SAMPLE_SVP_NNIE_EXP_COEF_COL_NUM  16
#define SAMPLE_SVP_NNIE_EXP_COEF_NEGATIVE_VALUE_START_ROW  5
#define SAMPLE_SVP_NNIE_EXP_FOUR_BIT_OFFSET        4
#define SAMPLE_SVP_NNIE_EXP_COEF_IDX_MASK          0xF
#define SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET       0
#define SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET       1
#define SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET       2
#define SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET       3
#define SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET       4
#define SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET       5
#define SAMPLE_SVP_NNIE_BBOX_CENX_OFFSET           0
#define SAMPLE_SVP_NNIE_BBOX_CENY_OFFSET           1
#define SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET          2
#define SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET         3
#define SAMPLE_SVP_NNIE_BBOX_CENX_DELTA_OFFSET      0
#define SAMPLE_SVP_NNIE_BBOX_CENY_DELTA_OFFSET      1
#define SAMPLE_SVP_NNIE_BBOX_WIDTH_DELTA_OFFSET     2
#define SAMPLE_SVP_NNIE_BBOX_HEIGHT_DELTA_OFFSET    3
#define SAMPLE_SVP_NNIE_BBOX_DELTA_NUM              4
#define SAMPLE_SVP_NNIE_YOLOV2_OBJ_CONF_OFFSET      4
#define SAMPLE_SVP_NNIE_YOLOV2_CLASS_CONF_OFFSET    5
#define SAMPLE_SVP_NNIE_YOLOV3_OBJ_CONF_OFFSET      4
#define SAMPLE_SVP_NNIE_YOLOV3_CLASS_CONF_OFFSET    5

static hi_float g_exp_coef_array[SAMPLE_SVP_NNIE_EXP_COEF_ROW_NUM][SAMPLE_SVP_NNIE_EXP_COEF_COL_NUM] = {
    {
        1.0f,          1.00024f,      1.00049f,      1.00073f,
        1.00098f,      1.00122f,      1.00147f,      1.00171f,
        1.00196f,      1.0022f,       1.00244f,      1.00269f,
        1.00293f,      1.00318f,      1.00342f,      1.00367f
    }, {
        1.0f,          1.00391f,      1.00784f,      1.01179f,
        1.01575f,      1.01972f,      1.02371f,      1.02772f,
        1.03174f,      1.03578f,      1.03984f,      1.04391f,
        1.04799f,      1.05209f,      1.05621f,      1.06034f
    }, {
        1.0f,          1.06449f,      1.13315f,      1.20623f,
        1.28403f,      1.36684f,      1.45499f,      1.54883f,
        1.64872f,      1.75505f,      1.86825f,      1.98874f,
        2.117f,        2.25353f,      2.39888f,      2.55359f
    }, {
        1.0f,          2.71828f,      7.38906f,      20.0855f,
        54.5981f,      148.413f,      403.429f,      1096.63f,
        2980.96f,      8103.08f,      22026.5f,      59874.1f,
        162755.0f,     442413.0f,     1.2026e+006f,  3.26902e+006f
    }, {
        1.0f,          8.88611e+006f, 7.8963e+013f,  7.01674e+020f,
        6.23515e+027f, 5.54062e+034f, 5.54062e+034f, 5.54062e+034f,
        5.54062e+034f, 5.54062e+034f, 5.54062e+034f, 5.54062e+034f,
        5.54062e+034f, 5.54062e+034f, 5.54062e+034f, 5.54062e+034f
    }, {
        1.0f,          0.999756f,     0.999512f,     0.999268f,
        0.999024f,     0.99878f,      0.998536f,     0.998292f,
        0.998049f,     0.997805f,     0.997562f,     0.997318f,
        0.997075f,     0.996831f,     0.996588f,     0.996345f
    }, {
        1.0f,          0.996101f,     0.992218f,     0.98835f,
        0.984496f,     0.980658f,     0.976835f,     0.973027f,
        0.969233f,     0.965455f,     0.961691f,     0.957941f,
        0.954207f,     0.950487f,     0.946781f,     0.94309f
    }, {
        1.0f,          0.939413f,     0.882497f,     0.829029f,
        0.778801f,     0.731616f,     0.687289f,     0.645649f,
        0.606531f,     0.569783f,     0.535261f,     0.502832f,
        0.472367f,     0.443747f,     0.416862f,     0.391606f
    }, {
        1.0f,          0.367879f,     0.135335f,     0.0497871f,
        0.0183156f,    0.00673795f,   0.00247875f,   0.000911882f,
        0.000335463f,  0.00012341f,   4.53999e-005f, 1.67017e-005f,
        6.14421e-006f, 2.26033e-006f, 8.31529e-007f, 3.05902e-007f
    }, {
        1.0f,          1.12535e-007f, 1.26642e-014f, 1.42516e-021f,
        1.60381e-028f, 1.80485e-035f, 2.03048e-042f, 0.0f,
        0.0f,          0.0f,          0.0f,          0.0f,
        0.0f,          0.0f,          0.0f,          0.0f
    }
};

static hi_float svp_nnie_quick_exp(hi_s32 value)
{
    hi_u32 tmp_val, row_idx;
    hi_u32 offset_bit = 0;
    hi_float result = 1.0f;

    if (value < 0) {
        tmp_val = *((hi_u32 *)&value);
        tmp_val = (~tmp_val + 0x00000001);
        for (row_idx = SAMPLE_SVP_NNIE_EXP_COEF_NEGATIVE_VALUE_START_ROW; row_idx < SAMPLE_SVP_NNIE_EXP_COEF_ROW_NUM;
            row_idx++) {
            result = result * g_exp_coef_array[row_idx][(tmp_val >> offset_bit) & SAMPLE_SVP_NNIE_EXP_COEF_IDX_MASK];
            offset_bit += SAMPLE_SVP_NNIE_EXP_FOUR_BIT_OFFSET;
        }
    } else {
        tmp_val = (hi_u32)value;
        for (row_idx = 0; row_idx < SAMPLE_SVP_NNIE_EXP_COEF_NEGATIVE_VALUE_START_ROW; row_idx++) {
            result = result * g_exp_coef_array[row_idx][(tmp_val >> offset_bit) & SAMPLE_SVP_NNIE_EXP_COEF_IDX_MASK];
            offset_bit += SAMPLE_SVP_NNIE_EXP_FOUR_BIT_OFFSET;
        }
    }
    return result;
}

static hi_void svp_nnie_softmax(hi_float *src, hi_u32 num)
{
    hi_float max = 0;
    hi_float sum = 0;
    hi_u32 i;

    for (i = 0; i < num; ++i) {
        if (max < src[i]) {
            max = src[i];
        }
    }

    for (i = 0; i < num; ++i) {
        src[i] = (hi_float)svp_nnie_quick_exp((hi_s32)((src[i] - max) * SAMPLE_SVP_NNIE_QUANT_BASE));
        sum += src[i];
    }

    for (i = 0; i < num; ++i) {
        src[i] /= sum;
    }
}

static hi_void svp_nnie_sigmoid(hi_float *src, hi_u32 num)
{
    hi_u32 i;

    for (i = 0; i < num; i++) {
        src[i] = sample_svp_nnie_sigmoid(src[i]);
    }
}

static hi_void svp_nnie_ssd_softmax(hi_s32 *src, hi_s32 array_size, hi_s32 *dst)
{
    /* define parameters */
    hi_s32 max = 0;
    hi_s32 sum = 0;
    hi_s32 i;

    for (i = 0; i < array_size; ++i) {
        if (max < src[i]) {
            max = src[i];
        }
    }
    for (i = 0; i < array_size; ++i) {
        dst[i] = (hi_s32)(SAMPLE_SVP_NNIE_QUANT_BASE * exp ((hi_float)(src[i] - max) / SAMPLE_SVP_NNIE_QUANT_BASE));
        sum += dst[i];
    }
    for (i = 0; i < array_size; ++i) {
        dst[i] = (hi_s32)(((hi_float)dst[i] / (hi_float)sum) * SAMPLE_SVP_NNIE_QUANT_BASE);
    }
}

static hi_void svp_nnie_arg_swap(hi_s32 *src1, hi_s32 *src2)
{
    hi_s32 i, tmp;

    for (i = 0; i < SAMPLE_SVP_NNIE_PROPOSAL_WIDTH; i++) {
        tmp = src1[i];
        src1[i] = src2[i];
        src2[i] = tmp;
    }
}

static hi_void svp_nnie_non_recursive_arg_quick_sort(hi_s32 *array,
    hi_s32 low, hi_s32 high, sample_svp_nnie_stack *stack, hi_u32 max_num)
{
    hi_s32 i = low;
    hi_s32 j = high;
    hi_s32 top = 0;
    hi_s32 key_conf = array[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * low + SAMPLE_SVP_NNIE_COORD_NUM];

    stack[top].min = low;
    stack[top].max = high;

    while (top > -1) {
        low = stack[top].min;
        high = stack[top].max;
        i = low;
        j = high;
        top--;

        key_conf = array[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * low + SAMPLE_SVP_NNIE_COORD_NUM];

        while (i < j) {
            while ((i < j) && (key_conf > array[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_COORD_NUM])) {
                j--;
            }
            if (i < j) {
                svp_nnie_arg_swap(&array[i * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH],
                    &array[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH]);
                i++;
            }

            while ((i < j) && (key_conf < array[i * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_COORD_NUM])) {
                i++;
            }
            if (i < j) {
                svp_nnie_arg_swap(&array[i * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH],
                    &array[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH]);
                j--;
            }
        }

        if (low <= max_num) {
            if (low < i - 1) {
                top++;
                stack[top].min = low;
                stack[top].max = i - 1;
            }

            if (high > i + 1) {
                top++;
                stack[top].min = i + 1;
                stack[top].max = high;
            }
        }
    }
}

static hi_void svp_nnie_overlap(sample_svp_nnie_bbox *bbox1, sample_svp_nnie_bbox *bbox2,
    hi_s32 *area_sum, hi_s32 *area_inter)
{
    hi_s32 inter, total, area1, area2, inter_width, inter_height;
    hi_s32 x_min, y_min, x_max, y_max;

    x_min = sample_svp_nnie_max(bbox1->x_min, bbox2->x_min);
    y_min = sample_svp_nnie_max(bbox1->y_min, bbox2->y_min);
    x_max = sample_svp_nnie_min(bbox1->x_max, bbox2->x_max);
    y_max = sample_svp_nnie_min(bbox1->y_max, bbox2->y_max);

    inter_width = x_max - x_min + 1;
    inter_height = y_max - y_min + 1;

    inter_width = (inter_width >= 0) ? inter_width : 0;
    inter_height = (inter_height >= 0) ? inter_height : 0;

    inter = inter_width * inter_height;
    area1 = (bbox1->x_max - bbox1->x_min + 1) * (bbox1->y_max - bbox1->y_min + 1);
    area2 = (bbox2->x_max - bbox2->x_min + 1) * (bbox2->y_max - bbox2->y_min + 1);

    total = area1 + area2 - inter;

    *area_sum = total;
    *area_inter = inter;
}

static hi_void svp_nnie_non_max_suppression(hi_s32 *proposals, hi_u32 anchors_num,
    hi_u32 nms_threshold, hi_u32 max_roi_num)
{
    sample_svp_nnie_bbox bbox1, bbox2;
    hi_s32 area_total, area_inter;
    hi_u32 i, j;
    hi_u32 num = 0;
    hi_bool no_overlap = HI_TRUE;

    for (i = 0; (i < anchors_num) && (num < max_roi_num); i++) {
        if (proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] != 0) {
            continue;
        }
        num++;
        bbox1.x_min = proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET];
        bbox1.y_min = proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET];
        bbox1.x_max = proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET];
        bbox1.y_max = proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET];
        for (j = i + 1; j < anchors_num; j++) {
            if (proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * j + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] != 0) {
                continue;
            }
            bbox2.x_min = proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * j + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET];
            bbox2.y_min = proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * j + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET];
            bbox2.x_max = proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * j + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET];
            bbox2.y_max = proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * j + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET];
            no_overlap = (bbox2.x_min > bbox1.x_max) || (bbox2.x_max < bbox1.x_min) ||
                (bbox2.y_min > bbox1.y_max) || (bbox2.y_max < bbox1.y_min);
            if (no_overlap) {
                continue;
            }
            (hi_void)svp_nnie_overlap(&bbox1, &bbox2, &area_total, &area_inter);
            if (area_inter * SAMPLE_SVP_NNIE_QUANT_BASE > ((hi_s32)nms_threshold * area_total)) {
                proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * j + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] = 1;
            }
        }
    }
}

static hi_s32 svp_nnie_cnn_get_top_n(sample_svp_nnie_cnn_get_top_n_param *param)
{
    hi_u32 i, j, n, id;
    hi_s32 *score = HI_NULL;
    sample_svp_nnie_cnn_get_top_n_unit tmp;
    sample_svp_nnie_cnn_get_top_n_unit *top_n_unit = HI_NULL;
    sample_svp_nnie_cnn_get_top_n_unit *tmp_unit = (sample_svp_nnie_cnn_get_top_n_unit *)param->tmp_buf;

    for (n = 0; n < param->batch_num; n++) {
        score = (hi_s32 *)((hi_u8 *)param->fc + n * param->fc_stride);
        top_n_unit = (sample_svp_nnie_cnn_get_top_n_unit *)((hi_u8 *)param->get_top_n + n * param->top_n_stride);
        for (i = 0; i < param->class_num; i++) {
            tmp_unit[i].class_id = i;
            tmp_unit[i].conf = (hi_u32)score[i];
        }

        for (i = 0; i < param->top_n; i++) {
            id = i;
            top_n_unit[i].class_id = tmp_unit[i].class_id;
            top_n_unit[i].conf = tmp_unit[i].conf;
            for (j = i + 1; j < param->class_num; j++) {
                id = (tmp_unit[id].conf < tmp_unit[j].conf) ? j : id;
            }

            tmp.class_id = tmp_unit[id].class_id;
            tmp.conf = tmp_unit[id].conf;

            if (i != id) {
                tmp_unit[id].class_id = tmp_unit[i].class_id;
                tmp_unit[id].conf = tmp_unit[i].conf;
                tmp_unit[i].class_id = tmp.class_id;
                tmp_unit[i].conf = tmp.conf;

                top_n_unit[i].class_id = tmp.class_id;
                top_n_unit[i].conf = tmp.conf;
            }
        }
    }

    return HI_SUCCESS;
}

static hi_void svp_nnie_rpn_tanspose(sample_svp_nnie_rpn_param *param, hi_s32 *bbox_delta, hi_float *conf)
{
    hi_u32 map_size, bg_blob_size, line_size, anchors_per_pixel, src_bbox_bias, src_prob_bias;
    hi_u32 src_bbox_idx, src_fg_prob_idx, src_bg_prob_idx, dst_bbox_delta_idx, dst_score_idx, dst_box_idx;
    hi_u32 c, h, w;

    /* do transpose, convert the blob from (M,C,H,W) to (M,H,W,C) */
    map_size = param->conv_height[1] * param->conv_stride[1] / sizeof(hi_u32);
    anchors_per_pixel = param->ratio_anchor_num * param->scale_anchor_num;
    bg_blob_size = anchors_per_pixel * map_size;
    line_size = param->conv_stride[1] / sizeof(hi_u32);
    src_prob_bias = 0;
    src_bbox_bias = 0;

    for (c = 0; c < param->conv_channel[1]; c++) {
        for (h = 0; h < param->conv_height[1]; h++) {
            for (w = 0; w < param->conv_width[1]; w++) {
                src_bbox_idx = src_bbox_bias + c * map_size + h * line_size + w;
                src_bg_prob_idx = src_prob_bias + (c / SAMPLE_SVP_NNIE_COORD_NUM) * map_size + h * line_size + w;
                src_fg_prob_idx = bg_blob_size + src_bg_prob_idx;

                dst_box_idx = (anchors_per_pixel) * (h * param->conv_width[1] + w) + c / SAMPLE_SVP_NNIE_COORD_NUM;

                dst_bbox_delta_idx = SAMPLE_SVP_NNIE_COORD_NUM * dst_box_idx + c % SAMPLE_SVP_NNIE_COORD_NUM;
                bbox_delta[dst_bbox_delta_idx] = (hi_s32)param->src[1][src_bbox_idx];

                dst_score_idx = (SAMPLE_SVP_NNIE_SCORE_NUM) * dst_box_idx;
                conf[dst_score_idx] = (hi_float)((hi_s32)param->src[0][src_bg_prob_idx]) /
                    SAMPLE_SVP_NNIE_QUANT_BASE;
                conf[dst_score_idx + 1] = (hi_float)((hi_s32)param->src[0][src_fg_prob_idx]) /
                    SAMPLE_SVP_NNIE_QUANT_BASE;
            }
        }
    }
}

static hi_s32 svp_nnie_rpn_filter_bbox(sample_svp_nnie_rpn_param *param, hi_u32 anchor_num, hi_s32 *proposals,
    hi_u32 *dst_num)
{
    hi_u32 proposal_cnt = 0;
    hi_u32 i;
    hi_s32 ret;

    for (i = 0; i < anchor_num; i++) {
        if (proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i + SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET] <
            (hi_s32)param->filter_threshold) {
            proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] = 1;
        }
    }
    for (i = 0; i < anchor_num; i++) {
        if ((proposals[SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] == 0) &&
            (proposal_cnt != i)) {
            ret = memcpy_s((proposals + SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * proposal_cnt),
                sizeof(hi_u32) * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH, (proposals + SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i),
                sizeof(hi_u32) * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH);
            sample_svp_check_exps_return(ret != EOK, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
                SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,memcpy_s %u-th propoasl failed!\n", i);
            proposal_cnt++;
        }
    }
    *dst_num = proposal_cnt;
    return HI_SUCCESS;
}

static hi_s32 svp_nnie_rpn_clip_and_filter_bbox(sample_svp_nnie_rpn_param *param,
    hi_u32 anchor_num, hi_s32 *proposals, hi_u32 *num_after_filter)
{
    hi_u32 i, proposal_width, proposal_height, proposal_cnt;
    hi_s32 ret;
    hi_s32 *tmp = HI_NULL;

    /* clip_flag bbox */
    for (i = 0; i < anchor_num; i++) {
        tmp = proposals;
        tmp = tmp + SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i;
        *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET) = sample_svp_nnie_max(sample_svp_nnie_min(
            *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET), (hi_s32)param->ori_img_width - 1), 0);
        *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET) = sample_svp_nnie_max(sample_svp_nnie_min(
            *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET), (hi_s32)param->ori_img_height - 1), 0);
        *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET) = sample_svp_nnie_max(sample_svp_nnie_min(
            *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET), (hi_s32)param->ori_img_width - 1), 0);
        *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET) = sample_svp_nnie_max(sample_svp_nnie_min(
            *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET), (hi_s32)param->ori_img_height - 1), 0);
    }

    /* remove the bboxes which are too small */
    for (i = 0; i < anchor_num; i++) {
        tmp = proposals;
        tmp = tmp + SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i;
        proposal_width = *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET) -
            *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET) + 1;
        proposal_height = *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET) -
            *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET) + 1;
        if (proposal_width < (hi_s32)param->min_size || proposal_height < (hi_s32)param->min_size) {
            *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET) = 1;
        }
    }

    /* remove the bboxes whose score is less than filter thresh */
    if (param->filter_threshold > 0) {
        ret = svp_nnie_rpn_filter_bbox(param, anchor_num, proposals, &proposal_cnt);
        sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,svp_nnie_rpn_filter_bbox failed!\n");
    }
    *num_after_filter = (param->filter_threshold > 0) ? proposal_cnt : anchor_num;
    return HI_SUCCESS;
}

static hi_void svp_nnie_rpn_decode_bbox(hi_s32 *anchors, hi_u32 num_anchors,
    hi_s32 *bbox_delta, hi_float *conf, hi_s32 *proposals)
{
    hi_u32 i;
    hi_s32 proposal_width, proposal_height, proposal_center_x, proposal_center_y;
    hi_s32 pred_w, pred_h, pred_center_x, pred_center_y;

    for (i = 0; i < num_anchors; i++) {
        proposal_width = *(anchors + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET) -
            *(anchors + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET) + 1;
        proposal_height = *(anchors + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET) -
            *(anchors + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET) + 1;
        proposal_center_x = *(anchors + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET) +
            (hi_s32)(proposal_width * SAMPLE_SVP_NNIE_HALF);
        proposal_center_y = *(anchors + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET) +
            (hi_s32)(proposal_height * SAMPLE_SVP_NNIE_HALF);
        pred_center_x = (hi_s32)(((hi_float)(*(bbox_delta + SAMPLE_SVP_NNIE_BBOX_CENX_DELTA_OFFSET)) /
            SAMPLE_SVP_NNIE_QUANT_BASE) * proposal_width + proposal_center_x);
        pred_center_y = (hi_s32)(((hi_float)(*(bbox_delta + SAMPLE_SVP_NNIE_BBOX_CENY_DELTA_OFFSET)) /
            SAMPLE_SVP_NNIE_QUANT_BASE) * proposal_height + proposal_center_y);
        pred_w = (hi_s32)(proposal_width * svp_nnie_quick_exp ((hi_s32)(*(bbox_delta +
            SAMPLE_SVP_NNIE_BBOX_WIDTH_DELTA_OFFSET))));
        pred_h = (hi_s32)(proposal_height * svp_nnie_quick_exp ((hi_s32)(*(bbox_delta +
            SAMPLE_SVP_NNIE_BBOX_HEIGHT_DELTA_OFFSET))));
        *(proposals + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET) = (hi_s32)(pred_center_x - SAMPLE_SVP_NNIE_HALF * pred_w);
        *(proposals + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET) = (hi_s32)(pred_center_y - SAMPLE_SVP_NNIE_HALF * pred_h);
        *(proposals + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET) = (hi_s32)(pred_center_x + SAMPLE_SVP_NNIE_HALF * pred_w);
        *(proposals + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET) = (hi_s32)(pred_center_y + SAMPLE_SVP_NNIE_HALF * pred_h);
        *(proposals + SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET) = (hi_s32)(*(conf + 1) * SAMPLE_SVP_NNIE_QUANT_BASE);
        *(proposals + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET) = 0;
        anchors += SAMPLE_SVP_NNIE_COORD_NUM;
        proposals += SAMPLE_SVP_NNIE_PROPOSAL_WIDTH;
        bbox_delta += SAMPLE_SVP_NNIE_COORD_NUM;
        conf += SAMPLE_SVP_NNIE_SCORE_NUM;
    }
}

static hi_void svp_nnie_rpn_fill_dst_blob(hi_u32 num_after_filter, hi_s32 *proposals, sample_svp_nnie_rpn_param *param)
{
    hi_u32 i, roi_cnt;
    hi_s32 *tmp = HI_NULL;
    hi_u32 offset = param->dst_stride / sizeof(hi_u32);

    roi_cnt = 0;
    for (i = 0; i < num_after_filter; i++) {
        tmp = proposals;
        tmp = tmp + SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i;
        if (*(tmp + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET) == 0) {
            /*
             * in this sample,the output roi coordinates will be input in hardware,
             * so the type coordinates are convert to HI_S20Q12
             */
            param->proposal_result[offset * roi_cnt + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] =
                *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET) * SAMPLE_SVP_NNIE_QUANT_BASE;
            param->proposal_result[offset * roi_cnt + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] =
                *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET) * SAMPLE_SVP_NNIE_QUANT_BASE;
            param->proposal_result[offset * roi_cnt + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] =
                *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET) * SAMPLE_SVP_NNIE_QUANT_BASE;
            param->proposal_result[offset * roi_cnt + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] =
                *(tmp + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET) * SAMPLE_SVP_NNIE_QUANT_BASE;
            roi_cnt++;
        }
        if (roi_cnt >= param->max_rois) {
            break;
        }
    }
    *param->num_rois = roi_cnt;
}

static hi_s32 svp_nnie_rpn(sample_svp_nnie_rpn_param *param)
{
    hi_u32 i, anchor_num, num_after_filter, size;
    hi_s32 *tmp = HI_NULL;
    hi_float *score = HI_NULL;
    hi_s32 *bbox_delta = HI_NULL;
    hi_s32 *proposals = HI_NULL;
    hi_float *conf = HI_NULL;
    sample_svp_nnie_stack *stack = HI_NULL;
    hi_s32 ret;

    /* addr offset */
    anchor_num = param->ratio_anchor_num * param->scale_anchor_num * (param->conv_height[0] * param->conv_width[0]);
    size = SAMPLE_SVP_NNIE_COORD_NUM * anchor_num;
    tmp = (hi_s32 *)param->mem_pool;

    bbox_delta = tmp;
    tmp += size;

    conf = (hi_float *)tmp;
    size = anchor_num * SAMPLE_SVP_NNIE_SCORE_NUM;
    tmp += size;

    proposals = (hi_s32 *)tmp;
    size = SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * anchor_num;
    tmp += size;

    stack = (sample_svp_nnie_stack *)tmp;

    /* transpose */
    (hi_void)svp_nnie_rpn_tanspose(param, bbox_delta, conf);

    /* do softmax */
    score = conf;
    for (i = 0; i < anchor_num; i++) {
        (hi_void)svp_nnie_softmax(score, SAMPLE_SVP_NNIE_SCORE_NUM);
        score += SAMPLE_SVP_NNIE_SCORE_NUM;
    }

    /* decode bbox */
    (hi_void)svp_nnie_rpn_decode_bbox(param->base_anchor, anchor_num, bbox_delta, conf, proposals);

    /* clip and filter bbox */
    ret = svp_nnie_rpn_clip_and_filter_bbox(param, anchor_num, proposals, &num_after_filter);
    sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,svp_nnie_rpn_clip_and_filter_bbox failed!\n");

    /* sort */
    if (num_after_filter > 1) {
        (hi_void)svp_nnie_non_recursive_arg_quick_sort(proposals, 0, num_after_filter - 1, stack,
            param->num_before_nms);
        num_after_filter = (num_after_filter < param->num_before_nms) ? num_after_filter : param->num_before_nms;

        /* do nms to remove highly overlapped bbox */
        (hi_void)svp_nnie_non_max_suppression(proposals, num_after_filter, param->nms_threshold, param->max_rois);
    }
    /* fill dst proposal */
    (hi_void)svp_nnie_rpn_fill_dst_blob(num_after_filter, proposals, param);

    return HI_SUCCESS;
}

static hi_void svp_nnie_rpn_generate_each_anchor_box(sample_svp_nnie_rpn_generate_base_anchor_param *param,
    sample_svp_nnie_base_box *base_box, sample_svp_nnie_anchor_box_ctrl_info *ctrl, sample_svp_nnie_anchor_box_dst *dst)
{
    hi_u32 i, j;
    hi_float width, height, ratio_size, ratio_value;
    hi_float scale_coord[SAMPLE_SVP_NNIE_COORD_NUM];
    hi_u32 pixel_interval = ctrl->pixel_interval;

    for (i = 0; i < param->ratio_anchor_num; i++) {
        ratio_value = (hi_float)param->ratios[i] / SAMPLE_SVP_NNIE_QUANT_BASE;
        ratio_size = (base_box->base_width * base_box->base_height) / ratio_value;
        width = sqrt(ratio_size);
        width = (hi_float)((hi_s32)(width) >= 0 ? (hi_s32)(width + SAMPLE_SVP_NNIE_HALF) :
            (hi_s32)(width - SAMPLE_SVP_NNIE_HALF));
        height = width * ratio_value;
        height = (hi_float)((hi_s32)(height) >= 0 ? (hi_s32)(height + SAMPLE_SVP_NNIE_HALF) :
            (hi_s32)(height - SAMPLE_SVP_NNIE_HALF));

        for (j = 0; j < param->scale_anchor_num; j++) {
            scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] = (hi_float)(base_box->center_x - (width *
                ((hi_float)param->scales[j] / SAMPLE_SVP_NNIE_QUANT_BASE) - 1) * SAMPLE_SVP_NNIE_HALF);
            scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] = (hi_float)(base_box->center_y - (height *
                ((hi_float)param->scales[j] / SAMPLE_SVP_NNIE_QUANT_BASE) - 1) * SAMPLE_SVP_NNIE_HALF);
            scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] = (hi_float)(base_box->center_x + (width *
                ((hi_float)param->scales[j] / SAMPLE_SVP_NNIE_QUANT_BASE) - 1) * SAMPLE_SVP_NNIE_HALF);
            scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] = (hi_float)(base_box->center_y + (height *
                ((hi_float)param->scales[j] / SAMPLE_SVP_NNIE_QUANT_BASE) - 1) * SAMPLE_SVP_NNIE_HALF);

            if (ctrl->is_used_for_sw == HI_TRUE) {
                *(dst->mem_addr++) = (hi_s32)(ctrl->width_idx * pixel_interval +
                    scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET]);
                *(dst->mem_addr++) = (hi_s32)(ctrl->height_idx * pixel_interval +
                    scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET]);
                *(dst->mem_addr++) = (hi_s32)(ctrl->width_idx * pixel_interval +
                    scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET]);
                *(dst->mem_addr++) = (hi_s32)(ctrl->height_idx * pixel_interval +
                    scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET]);
            } else {
                *(dst->x_min++) = (hi_s32)(ctrl->width_idx * pixel_interval +
                    scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET]) * SAMPLE_SVP_NNIE_QUANT_BASE;
                *(dst->y_min++) = (hi_s32)(ctrl->height_idx * pixel_interval +
                    scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET]) * SAMPLE_SVP_NNIE_QUANT_BASE;
                *(dst->x_max++) = (hi_s32)(ctrl->width_idx * pixel_interval +
                    scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET]) * SAMPLE_SVP_NNIE_QUANT_BASE;
                *(dst->y_max++) = (hi_s32)(ctrl->height_idx * pixel_interval +
                    scale_coord[SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET]) * SAMPLE_SVP_NNIE_QUANT_BASE;
            }
        }
    }
}

static hi_void svp_nnie_faster_rcnn_rfcn_get_result_fill_dst_blob(sample_svp_nnie_faster_rcnn_get_result_param *param,
    hi_s32 *proposal, hi_u32 class_id, hi_u32 *total_bbox_num)
{
    hi_s32 *score = HI_NULL;
    hi_s32 *bbox = HI_NULL;
    hi_s32 *roi_cnt = HI_NULL;
    hi_u32 i, roi_out_cnt, line_offset;

    score = (hi_s32 *)param->dst_score;
    bbox = (hi_s32 *)param->dst_bbox;
    roi_cnt = (hi_s32 *)param->class_roi_num;

    score += *total_bbox_num;
    bbox += SAMPLE_SVP_NNIE_COORD_NUM * (*total_bbox_num);

    roi_out_cnt = 0;
    for (i = 0; i < param->roi_num; i++) {
        line_offset = SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * i;
        if ((proposal[line_offset + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] == 0) &&
            (proposal[line_offset + SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET] > (hi_s32)param->conf_threshold[class_id])) {
            score[roi_out_cnt] = proposal[line_offset + SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET];
            bbox[roi_out_cnt * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] =
                proposal[line_offset + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET];
            bbox[roi_out_cnt * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] =
                proposal[line_offset + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET];
            bbox[roi_out_cnt * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] =
                proposal[line_offset + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET];
            bbox[roi_out_cnt * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] =
                proposal[line_offset + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET];
            roi_out_cnt++;
        }
        if (roi_out_cnt >= param->roi_num) {
            break;
        }
    }
    roi_cnt[class_id] = (hi_s32)roi_out_cnt;
    *total_bbox_num += roi_out_cnt;
}

static hi_void svp_nnie_faster_rcnn_rfcn_get_result_get_bbox(sample_svp_nnie_faster_rcnn_get_result_param *param,
    sample_svp_nnie_base_box *box, sample_svp_nnie_faster_rcnn_rfcn_get_bbox_ctrl_info *ctrl,
    hi_float *score, hi_s32 *proposal)
{
    hi_u32 offset;
    hi_float pred_w, pred_h, pred_center_x, pred_center_y;

    pred_center_x = ((hi_float)ctrl->bbox_delta[ctrl->bbox_delta_idx + SAMPLE_SVP_NNIE_BBOX_CENX_DELTA_OFFSET] /
        SAMPLE_SVP_NNIE_QUANT_BASE) * box->base_width + box->center_x;
    pred_center_y = ((hi_float)ctrl->bbox_delta[ctrl->bbox_delta_idx + SAMPLE_SVP_NNIE_BBOX_CENY_DELTA_OFFSET] /
        SAMPLE_SVP_NNIE_QUANT_BASE) * box->base_height + box->center_y;
    pred_w = box->base_width * svp_nnie_quick_exp ((hi_s32)(ctrl->bbox_delta[ctrl->bbox_delta_idx +
        SAMPLE_SVP_NNIE_BBOX_WIDTH_DELTA_OFFSET]));
    pred_h = box->base_height * svp_nnie_quick_exp ((hi_s32)(ctrl->bbox_delta[ctrl->bbox_delta_idx +
        SAMPLE_SVP_NNIE_BBOX_HEIGHT_DELTA_OFFSET]));

    offset = SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * ctrl->roi_idx;
    proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] = (hi_s32)(pred_center_x - SAMPLE_SVP_NNIE_HALF * pred_w);

    proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] = (hi_s32)(pred_center_y - SAMPLE_SVP_NNIE_HALF * pred_h);

    proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] = (hi_s32)(pred_center_x + SAMPLE_SVP_NNIE_HALF * pred_w);

    proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] = (hi_s32)(pred_center_y + SAMPLE_SVP_NNIE_HALF * pred_h);

    proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET] =
        (hi_s32)(score[param->class_num * ctrl->roi_idx + ctrl->class_id] * SAMPLE_SVP_NNIE_QUANT_BASE);

    proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] = 0;

    /* clip bbox */
    proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] = sample_svp_nnie_max(sample_svp_nnie_min(
        proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET], (hi_s32)param->ori_img_width - 1), 0);
    proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] = sample_svp_nnie_max(sample_svp_nnie_min(
        proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET], (hi_s32)param->ori_img_height - 1), 0);
    proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] = sample_svp_nnie_max(sample_svp_nnie_min(
        proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET], (hi_s32)param->ori_img_width - 1), 0);
    proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] = sample_svp_nnie_max(sample_svp_nnie_min(
        proposal[offset + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET], (hi_s32)param->ori_img_height - 1), 0);
}

static hi_void svp_nnie_faster_rcnn_get_result_decode_bbox_sw(sample_svp_nnie_faster_rcnn_get_result_param *param,
    hi_u32 class_id, hi_float *score, hi_s32 *proposal)
{
    hi_u32 i;
    hi_u32 proposal_offset = param->bbox_stride / sizeof(hi_s32);
    hi_u32 bbox_delta_offset = param->bbox_delta_stride / sizeof(hi_u32);
    sample_svp_nnie_base_box box;
    sample_svp_nnie_faster_rcnn_rfcn_get_bbox_ctrl_info ctrl;

    for (i = 0; i < param->roi_num; i++) {
        box.base_width = (hi_float)(param->bbox[proposal_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] -
            param->bbox[proposal_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] + 1);

        box.base_height = (hi_float)(param->bbox[proposal_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] -
            param->bbox[proposal_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] + 1);

        box.center_x = (hi_float)(param->bbox[proposal_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] +
            SAMPLE_SVP_NNIE_HALF * box.base_width);

        box.center_y = (hi_float)(param->bbox[proposal_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] +
            SAMPLE_SVP_NNIE_HALF * box.base_height);
        ctrl.bbox_delta_idx = bbox_delta_offset * i + SAMPLE_SVP_NNIE_COORD_NUM * class_id;
        ctrl.class_id = class_id;
        ctrl.roi_idx = i;
        ctrl.bbox_delta = param->bbox_delta;
        (hi_void)svp_nnie_faster_rcnn_rfcn_get_result_get_bbox(param, &box, &ctrl, score, proposal);
    }
}

static hi_void svp_nnie_faster_rcnn_get_result_decode_bbox_hw(sample_svp_nnie_faster_rcnn_get_result_param *param,
    hi_u32 class_id, hi_float *score, hi_s32 *proposal)
{
    hi_u32 i;
    hi_u32 bbox_offset = param->bbox_stride / sizeof(hi_s32);
    hi_u32 bbox_delta_offset = param->bbox_delta_stride / sizeof(hi_u32);
    hi_s32 *x_min = param->bbox;
    hi_s32 *y_min = x_min + bbox_offset;
    hi_s32 *x_max = y_min + bbox_offset;
    hi_s32 *y_max = x_max + bbox_offset;
    sample_svp_nnie_base_box box;
    sample_svp_nnie_faster_rcnn_rfcn_get_bbox_ctrl_info ctrl;

    for (i = 0; i < param->roi_num; i++) {
        box.base_width = (hi_float)(x_max[i] - x_min[i] + 1);

        box.base_height = (hi_float)(y_max[i] - y_min[i] + 1);

        box.center_x = (hi_float)(x_min[i] + SAMPLE_SVP_NNIE_HALF * box.base_width);

        box.center_y = (hi_float)(y_min[i] + SAMPLE_SVP_NNIE_HALF * box.base_height);

        ctrl.bbox_delta_idx = bbox_delta_offset * i + SAMPLE_SVP_NNIE_COORD_NUM * class_id;
        ctrl.class_id = class_id;
        ctrl.roi_idx = i;
        ctrl.bbox_delta = param->bbox_delta;
        (hi_void)svp_nnie_faster_rcnn_rfcn_get_result_get_bbox(param, &box, &ctrl, score, proposal);
    }
}

static hi_s32 svp_nnie_faster_rcnn_get_result(sample_svp_nnie_faster_rcnn_get_result_param *param)
{
    hi_float *score_mem_pool = HI_NULL;
    hi_float *tmp = HI_NULL;
    hi_s32 *proposal_mem_pool = HI_NULL;
    sample_svp_nnie_stack *stack = HI_NULL;
    hi_u32 score_line_offset = param->score_stride / sizeof(hi_u32);
    hi_u32 i, j, dst_idx, src_idx, size;
    hi_u32 total_bbox_num = 0;

    /* get start pointer of mem_pool */
    tmp = (hi_float *)param->mem_pool;
    score_mem_pool = tmp;
    size = param->max_roi * param->class_num;
    tmp += size;

    proposal_mem_pool = (hi_s32 *)tmp;
    size = param->max_roi * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH;
    tmp += size;
    stack = (sample_svp_nnie_stack *)tmp;

    /* get score */
    dst_idx = 0;
    for (i = 0; i < param->roi_num; i++) {
        for (j = 0; j < param->class_num; j++) {
            src_idx = i * score_line_offset + j;
            score_mem_pool[dst_idx++] = (hi_float)((hi_s32)param->score[src_idx]) / SAMPLE_SVP_NNIE_QUANT_BASE;
        }
    }

    /* get each class's detection results */
    for (i = 0; i < param->class_num; i++) {
        if (param->is_rpn_sw == HI_TRUE) {
            (hi_void)svp_nnie_faster_rcnn_get_result_decode_bbox_sw(param, i, score_mem_pool, proposal_mem_pool);
        } else {
            (hi_void)svp_nnie_faster_rcnn_get_result_decode_bbox_hw(param, i, score_mem_pool, proposal_mem_pool);
        }
        if (param->roi_num > 1) {
            (hi_void)svp_nnie_non_recursive_arg_quick_sort(proposal_mem_pool, 0, param->roi_num - 1,
                stack, param->roi_num);

            (hi_void)svp_nnie_non_max_suppression(proposal_mem_pool, param->roi_num, param->nms_threshold,
                param->roi_num);
        }

        (hi_void)svp_nnie_faster_rcnn_rfcn_get_result_fill_dst_blob(param, proposal_mem_pool, i,  &total_bbox_num);
    }
    return HI_SUCCESS;
}

static hi_void svp_nnie_rfcn_get_result_decode_bbox_sw(sample_svp_nnie_rfcn_get_result_param *param,
    hi_u32 class_id, hi_s32 *bbox_mem_pool, hi_float *score, hi_s32 *proposal)
{
    hi_u32 i;
    hi_u32 bbox_offset = param->bbox_stride / sizeof(hi_s32);
    sample_svp_nnie_base_box box;
    sample_svp_nnie_faster_rcnn_rfcn_get_bbox_ctrl_info ctrl;

    for (i = 0; i < param->roi_num; i++) {
        box.base_width = param->bbox[bbox_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] -
            param->bbox[bbox_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] + 1;
        box.base_height = param->bbox[bbox_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] -
            param->bbox[bbox_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] + 1;
        box.center_x = param->bbox[bbox_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] +
            SAMPLE_SVP_NNIE_HALF * box.base_width;
        box.center_y = param->bbox[bbox_offset * i + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] +
            SAMPLE_SVP_NNIE_HALF * box.base_height;
        ctrl.bbox_delta = bbox_mem_pool;
        ctrl.bbox_delta_idx = SAMPLE_SVP_NNIE_COORD_NUM * i;
        ctrl.class_id = class_id;
        ctrl.roi_idx = i;
        (hi_void)svp_nnie_faster_rcnn_rfcn_get_result_get_bbox(param, &box, &ctrl, score, proposal);
    }
}

static hi_void svp_nnie_rfcn_get_result_decode_bbox_hw(sample_svp_nnie_rfcn_get_result_param *param,
    hi_u32 class_id, hi_s32 *bbox_mem_pool, hi_float *score, hi_s32 *proposal)
{
    hi_u32 i;
    hi_u32 bbox_offset = param->bbox_stride / sizeof(hi_s32);
    hi_s32 *x_min = param->bbox;
    hi_s32 *y_min = x_min + bbox_offset;
    hi_s32 *x_max = y_min + bbox_offset;
    hi_s32 *y_max = x_max + bbox_offset;
    sample_svp_nnie_base_box box;
    sample_svp_nnie_faster_rcnn_rfcn_get_bbox_ctrl_info ctrl;

    for (i = 0; i < param->roi_num; i++) {
        box.base_width = x_max[i] - x_min[i] + 1;
        box.base_height = y_max[i] - y_min[i] + 1;
        box.center_x = x_min[i] + SAMPLE_SVP_NNIE_HALF * box.base_width;
        box.center_y = y_min[i] + SAMPLE_SVP_NNIE_HALF * box.base_height;
        ctrl.bbox_delta = bbox_mem_pool;
        ctrl.bbox_delta_idx = SAMPLE_SVP_NNIE_COORD_NUM * i;
        ctrl.class_id = class_id;
        ctrl.roi_idx = i;
        (hi_void)svp_nnie_faster_rcnn_rfcn_get_result_get_bbox(param, &box, &ctrl, score, proposal);
    }
}

static hi_s32 svp_nnie_rfcn_get_result(sample_svp_nnie_rfcn_get_result_param *param)
{
    hi_u32 i, j, dst_idx, src_idx, size;
    hi_float *tmp = HI_NULL;
    hi_float *scores_mem = HI_NULL;
    hi_s32 *bbox_mem = HI_NULL;
    hi_s32 *proposal_mem = HI_NULL;
    sample_svp_nnie_stack *stack = HI_NULL;
    hi_u32 total_bbox_num = 0;

    /* get start pointer of mem_pool */
    tmp = (hi_float *)(param->mem_pool);
    scores_mem = tmp;
    size = param->max_roi * param->class_num;
    tmp += size;

    bbox_mem = (hi_s32 *)tmp;
    size = param->max_roi * SAMPLE_SVP_NNIE_COORD_NUM;
    tmp += size;

    proposal_mem = (hi_s32 *)tmp;
    size = param->max_roi * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH;
    tmp += size;
    stack = (sample_svp_nnie_stack *)tmp;

    /* prepare input data */
    for (i = 0; i < param->roi_num; i++) {
        for (j = 0; j < param->class_num; j++) {
            dst_idx = param->class_num * i + j;
            src_idx = param->score_stride / sizeof(hi_u32) * i + j;
            scores_mem[dst_idx] = (hi_float)(param->score[src_idx]) / SAMPLE_SVP_NNIE_QUANT_BASE;
        }
    }

    for (i = 0; i < param->roi_num; i++) {
        for (j = 0; j < SAMPLE_SVP_NNIE_COORD_NUM; j++) {
            src_idx = param->bbox_delta_stride / sizeof(hi_u32) * i + SAMPLE_SVP_NNIE_COORD_NUM + j;
            dst_idx = SAMPLE_SVP_NNIE_COORD_NUM * i + j;
            bbox_mem[dst_idx] = param->bbox_delta[src_idx];
        }
    }
    /* get each class's detection results */
    for (i = 0; i < param->class_num; i++) {
        if (param->is_rpn_sw == HI_TRUE) {
            (hi_void)svp_nnie_rfcn_get_result_decode_bbox_sw(param, i, bbox_mem, scores_mem, proposal_mem);
        } else {
            (hi_void)svp_nnie_rfcn_get_result_decode_bbox_hw(param, i, bbox_mem, scores_mem, proposal_mem);
        }
        if (param->roi_num > 1) {
            (hi_void)svp_nnie_non_recursive_arg_quick_sort(proposal_mem, 0, param->roi_num - 1, stack, param->roi_num);
            (hi_void)svp_nnie_non_max_suppression(proposal_mem, param->roi_num, param->nms_threshold, param->roi_num);
            (hi_void)svp_nnie_faster_rcnn_rfcn_get_result_fill_dst_blob(
                (sample_svp_nnie_faster_rcnn_get_result_param *)param, proposal_mem, i,  &total_bbox_num);
        }
    }
    return HI_SUCCESS;
}

static hi_void svp_nnie_ssd_generate_each_prior_box_coord(sample_svp_nnie_base_box *base_box,
    sample_svp_nnie_prior_box_ctrl_info *ctrl, sample_svp_nnie_prior_box_dst *dst)
{
    hi_u32 offset = ctrl->offset;

    if (ctrl->is_used_for_sw == HI_TRUE) {
        dst->mem_addr[offset++] = (hi_s32)(base_box->center_x - base_box->base_width * SAMPLE_SVP_NNIE_HALF);
        dst->mem_addr[offset++] = (hi_s32)(base_box->center_y - base_box->base_height * SAMPLE_SVP_NNIE_HALF);
        dst->mem_addr[offset++] = (hi_s32)(base_box->center_x + base_box->base_width * SAMPLE_SVP_NNIE_HALF);
        dst->mem_addr[offset++] = (hi_s32)(base_box->center_y + base_box->base_height * SAMPLE_SVP_NNIE_HALF);
    } else {
        dst->x_min[offset] = (hi_s32)(base_box->center_x - base_box->base_width * SAMPLE_SVP_NNIE_HALF) *
            SAMPLE_SVP_NNIE_QUANT_BASE;
        dst->y_min[offset] = (hi_s32)(base_box->center_y - base_box->base_height * SAMPLE_SVP_NNIE_HALF) *
            SAMPLE_SVP_NNIE_QUANT_BASE;
        dst->x_max[offset] = (hi_s32)(base_box->center_x + base_box->base_width * SAMPLE_SVP_NNIE_HALF) *
            SAMPLE_SVP_NNIE_QUANT_BASE;
        dst->y_max[offset] = (hi_s32)(base_box->center_y + base_box->base_height * SAMPLE_SVP_NNIE_HALF) *
            SAMPLE_SVP_NNIE_QUANT_BASE;
        offset++;
    }
    ctrl->offset = offset;
}

static hi_void svp_nnie_ssd_generate_each_prior_box(sample_svp_nnie_ssd_generate_prior_box_param *param,
    hi_float center_x, hi_float center_y, sample_svp_nnie_prior_box_ctrl_info *ctrl, sample_svp_nnie_prior_box_dst *dst)
{
    hi_u32 i, n;
    hi_float max_box_width;
    sample_svp_nnie_base_box base_box;

    base_box.center_x = center_x;
    base_box.center_y = center_y;

    for (n = 0; n < param->min_size_num; n++) {
        /* first prior */
        base_box.base_height = param->prior_box_min_size[ctrl->node_idx][n];
        base_box.base_width = param->prior_box_min_size[ctrl->node_idx][n];
        svp_nnie_ssd_generate_each_prior_box_coord(&base_box, ctrl, dst);
        /* second prior */
        if (param->max_size_num > 0) {
            max_box_width = sqrt(param->prior_box_min_size[ctrl->node_idx][n] *
                param->prior_box_max_size[ctrl->node_idx][n]);
            base_box.base_height = max_box_width;
            base_box.base_width = max_box_width;
            svp_nnie_ssd_generate_each_prior_box_coord(&base_box, ctrl, dst);
        }
        /* rest of priors, skip aspect_ratio == 1 */
        for (i = 1; i < ctrl->aspect_ratio_num; i++) {
            base_box.base_height = (hi_float)(param->prior_box_min_size[ctrl->node_idx][n] /
                sqrt(ctrl->aspect_ratio[i]));
            base_box.base_width = (hi_float)(param->prior_box_min_size[ctrl->node_idx][n] *
                sqrt(ctrl->aspect_ratio[i]));
            svp_nnie_ssd_generate_each_prior_box_coord(&base_box, ctrl, dst);
        }
    }
}

static hi_void svp_nnie_ssd_generate_prior_box(sample_svp_nnie_ssd_generate_prior_box_param *param,
    sample_svp_nnie_prior_box_ctrl_info *ctrl)
{
    hi_u32 i, j, h, w, var_offset;
    hi_float center_x, center_y;
    sample_svp_nnie_var_dst var_dst;
    hi_u32 total_prior_box_num = (param->min_size_num * ctrl->aspect_ratio_num + param->max_size_num) *
        param->prior_box_height[ctrl->node_idx] * param->prior_box_width[ctrl->node_idx];
    sample_svp_nnie_prior_box_dst dst;

    /* fill addr info */
    if (ctrl->is_used_for_sw == HI_TRUE) {
        dst.mem_addr = param->prior_box[ctrl->node_idx];
        ctrl->offset = 0;
    } else {
        dst.x_min = param->dst;
        dst.y_min = dst.x_min + param->dst_stride / sizeof(hi_s32);
        dst.x_max = dst.y_min + param->dst_stride / sizeof(hi_s32);
        dst.y_max = dst.x_max + param->dst_stride / sizeof(hi_s32);
    }

    /* generate prior box */
    for (h = 0; h < param->prior_box_height[ctrl->node_idx]; h++) {
        center_y = (h + param->offset) * param->prior_box_step_height[ctrl->node_idx];
        for (w = 0; w < param->prior_box_width[ctrl->node_idx]; w++) {
            center_x = (w + param->offset) * param->prior_box_step_width[ctrl->node_idx];
            svp_nnie_ssd_generate_each_prior_box(param, center_x, center_y, ctrl, &dst);
        }
    }

    /* get var */
    if (ctrl->is_used_for_sw == HI_TRUE) {
        for (i = 0; i < total_prior_box_num; i++) {
            for (j = 0; j < SAMPLE_SVP_NNIE_COORD_NUM; j++) {
                dst.mem_addr[ctrl->offset++] = (hi_s32)param->prior_box_var[j];
            }
        }
    } else {
        var_dst.x_min_var = dst.y_max + param->dst_stride / sizeof(hi_s32);
        var_dst.y_min_var = var_dst.x_min_var + param->dst_stride / sizeof(hi_s32);
        var_dst.x_max_var = var_dst.y_min_var + param->dst_stride / sizeof(hi_s32);
        var_dst.y_max_var = var_dst.x_max_var + param->dst_stride / sizeof(hi_s32);
        for (i = 0; i < total_prior_box_num; i++) {
            var_offset = 0;
            var_dst.x_min_var[ctrl->var_idx] = (hi_s32)param->prior_box_var[var_offset++];
            var_dst.y_min_var[ctrl->var_idx] = (hi_s32)param->prior_box_var[var_offset++];
            var_dst.x_max_var[ctrl->var_idx] = (hi_s32)param->prior_box_var[var_offset++];
            var_dst.y_max_var[ctrl->var_idx] = (hi_s32)param->prior_box_var[var_offset++];
            ctrl->var_idx++;
        }
    }
}

static hi_void svp_nnie_ssd_generate_prior_box_clip(sample_svp_nnie_ssd_generate_prior_box_param *param,
    sample_svp_nnie_prior_box_ctrl_info *ctrl)
{
    hi_u32 i;
    hi_s32 *prior_box = param->prior_box[ctrl->node_idx];
    hi_s32 *x_min = param->dst;
    hi_s32 *y_min = x_min + param->dst_stride / sizeof(hi_s32);
    hi_s32 *x_max = y_min + param->dst_stride / sizeof(hi_s32);
    hi_s32 *y_max = x_max + param->dst_stride / sizeof(hi_s32);
    hi_u32 idx = ctrl->offset;
    hi_u32 prior_box_num = param->prior_box_width[ctrl->node_idx] * param->prior_box_height[ctrl->node_idx] *
        (param->min_size_num * ctrl->aspect_ratio_num + param->max_size_num);
    hi_u32 ori_img_width_quant = param->ori_img_width * SAMPLE_SVP_NNIE_QUANT_BASE;
    hi_u32 ori_img_height_quant = param->ori_img_height * SAMPLE_SVP_NNIE_QUANT_BASE;

    /* clip prior box coordinate */
    if (ctrl->is_used_for_sw == HI_TRUE) {
        for (i = 0; i < prior_box_num; i++) {
            prior_box[i * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] =
                sample_svp_nnie_min(sample_svp_nnie_max(prior_box[i * SAMPLE_SVP_NNIE_COORD_NUM +
                SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET], 0), param->ori_img_width);
            prior_box[i * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] =
                sample_svp_nnie_min(sample_svp_nnie_max(prior_box[i * SAMPLE_SVP_NNIE_COORD_NUM +
                SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET], 0), param->ori_img_height);
            prior_box[i * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] =
                sample_svp_nnie_min(sample_svp_nnie_max(prior_box[i * SAMPLE_SVP_NNIE_COORD_NUM +
                SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET], 0), param->ori_img_width);
            prior_box[i * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] =
                sample_svp_nnie_min(sample_svp_nnie_max(prior_box[i * SAMPLE_SVP_NNIE_COORD_NUM +
                SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET], 0), param->ori_img_height);
        }
    } else {
        for (i = 0; i < prior_box_num; i++) {
            x_min[idx] = sample_svp_nnie_min(sample_svp_nnie_max(x_min[idx], 0), ori_img_width_quant);
            y_min[idx] = sample_svp_nnie_min(sample_svp_nnie_max(y_min[idx], 0), ori_img_height_quant);
            x_max[idx] = sample_svp_nnie_min(sample_svp_nnie_max(x_max[idx], 0), ori_img_width_quant);
            y_max[idx] = sample_svp_nnie_min(sample_svp_nnie_max(y_max[idx], 0), ori_img_height_quant);
            idx++;
        }
    }
}

static hi_void svp_nnie_ssd_softmax_concat(sample_svp_nnie_ssd_get_result_param *param,
    hi_s32 **conf_addr, hi_s32 *softmax_out_data)
{
    hi_u32 n, i, w, line_offset, line_num;
    hi_s32 *input_data = HI_NULL;
    hi_s32 *input_tmp = HI_NULL;

    for (n = 0; n < param->concat_num; n++) {
        input_data = conf_addr[n];
        input_tmp = input_data;
        line_offset = param->conf_blob_stride[n] / sizeof(hi_u32);
        line_num = param->conf_blob_chn[n] * param->conf_blob_height[n];
        for (i = 0; i < line_num; i++) {
            for (w = 0; w < param->conf_blob_width[n] / param->class_num; w++) {
                (hi_void)svp_nnie_ssd_softmax(input_tmp, param->class_num, softmax_out_data);
                softmax_out_data += param->class_num;
                input_tmp += param->class_num;
            }
            input_data += line_offset;
            input_tmp = input_data;
        }
    }
}

static hi_void svp_nnie_ssd_decode_bbox(sample_svp_nnie_ssd_get_result_param *param,
    hi_s32 **bbox_delta, hi_s32 *decode_bboxes)
{
    hi_u32 i, n, w, line_offset, line_num;
    hi_s32 *delta = HI_NULL;
    hi_s32 *prior_box = HI_NULL;
    hi_s32 *prior_var = HI_NULL;
    hi_float prior_width, prior_height, prior_center_x, prior_center_y;
    hi_float decode_box_center_x, decode_box_center_y, decode_box_width, decode_box_height;

    for (i = 0; i < param->concat_num; i++) {
        delta = bbox_delta[i];
        line_offset = param->loc_blob_stride[i] / sizeof(hi_s32);
        prior_box = param->prior_box[i];
        prior_var = prior_box + param->loc_blob_chn[i] * param->loc_blob_height[i] * param->loc_blob_width[i];
        line_num = param->loc_blob_chn[i] * param->loc_blob_height[i];

        for (n = 0; n < line_num; n++) {
            for (w = 0; w < param->loc_blob_width[i]; w += SAMPLE_SVP_NNIE_COORD_NUM) {
                prior_width = (hi_float)(prior_box[w + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] -
                    prior_box[w + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET]);
                prior_height = (hi_float)(prior_box[w + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] -
                    prior_box[w + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET]);
                prior_center_x = (prior_box[w + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] +
                    prior_box[w + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET]) * SAMPLE_SVP_NNIE_HALF;
                prior_center_y = (prior_box[w + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] +
                    prior_box[w + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET]) * SAMPLE_SVP_NNIE_HALF;

                decode_box_center_x = ((hi_float)prior_var[w + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] /
                    SAMPLE_SVP_NNIE_QUANT_BASE) * ((hi_float)delta[w + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] /
                    SAMPLE_SVP_NNIE_QUANT_BASE) * prior_width + prior_center_x;

                decode_box_center_y = ((hi_float)prior_var[w + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] /
                    SAMPLE_SVP_NNIE_QUANT_BASE) * ((hi_float)delta[w + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] /
                    SAMPLE_SVP_NNIE_QUANT_BASE) * prior_height + prior_center_y;

                decode_box_width = exp(((hi_float)prior_var[w + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] /
                    SAMPLE_SVP_NNIE_QUANT_BASE) * ((hi_float)delta[w + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] /
                    SAMPLE_SVP_NNIE_QUANT_BASE)) * prior_width;

                decode_box_height = exp(((hi_float)prior_var[w + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] /
                    SAMPLE_SVP_NNIE_QUANT_BASE) *  ((hi_float)delta[w + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] /
                    SAMPLE_SVP_NNIE_QUANT_BASE)) * prior_height;

                *(decode_bboxes++) = (hi_s32)(decode_box_center_x - decode_box_width * SAMPLE_SVP_NNIE_HALF);
                *(decode_bboxes++) = (hi_s32)(decode_box_center_y - decode_box_height * SAMPLE_SVP_NNIE_HALF);
                *(decode_bboxes++) = (hi_s32)(decode_box_center_x + decode_box_width * SAMPLE_SVP_NNIE_HALF);
                *(decode_bboxes++) = (hi_s32)(decode_box_center_y + decode_box_height * SAMPLE_SVP_NNIE_HALF);
            }
            prior_box += param->loc_blob_width[i];
            prior_var += param->loc_blob_width[i];
            delta += line_offset;
        }
    }
}

static hi_void svp_nnie_ssd_quick_sort(hi_s32 *proposal, sample_svp_nnie_stack *stack, hi_u32 sort_num, hi_u32 top_n)
{
    if (sort_num > 1) {
        (hi_void)svp_nnie_non_recursive_arg_quick_sort(proposal, 0, sort_num - 1, stack, top_n);
    }
}

static hi_void svp_nnie_ssd_bbox_nms(sample_svp_nnie_ssd_get_result_param *param,
    hi_s32 *decode_bboxes, sample_svp_nnie_stack *stack, hi_s32 *proposal, hi_u32 *total_roi_num)
{
    hi_u32 after_top_k_num = 0;
    hi_u32 i, j, after_filter, cnt;
    hi_s32 *dst_score = HI_NULL;
    hi_s32 *dst_bbox = HI_NULL;
    hi_s32 *class_roi_num = HI_NULL;

    for (i = 0; i < param->class_num; i++) {
        for (j = 0; j < param->prior_box_num; j++) {
            proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] =
                decode_bboxes[j * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET];
            proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] =
                decode_bboxes[j * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET];
            proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] =
                decode_bboxes[j * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET];
            proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] =
                decode_bboxes[j * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET];
            proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET] =
                param->conf_scores[j * param->class_num + i];
            proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] = 0;
        }
        (hi_void)svp_nnie_ssd_quick_sort(proposal, stack, param->prior_box_num, param->top_k);
        after_filter = (param->prior_box_num < param->top_k) ? param->prior_box_num : param->top_k;
        (hi_void)svp_nnie_non_max_suppression(proposal, after_filter, param->nms_threshold, after_filter);
        cnt = 0;
        dst_score = (hi_s32 *)param->dst_score + after_top_k_num;
        dst_bbox = (hi_s32 *)param->dst_roi + after_top_k_num * SAMPLE_SVP_NNIE_COORD_NUM;
        class_roi_num = (hi_s32 *)param->class_roi_num;
        for (j = 0; j < after_filter; j++) {
            if (proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] == 0 &&
                proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET] >
                (hi_s32)param->conf_threshold) {
                dst_score[cnt] = proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET];
                dst_bbox[cnt * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] =
                    proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET];
                dst_bbox[cnt * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] =
                    proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET];
                dst_bbox[cnt * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] =
                    proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET];
                dst_bbox[cnt * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] =
                    proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET];
                cnt++;
            }
        }
        class_roi_num[i] = (hi_s32)cnt;
        after_top_k_num += cnt;
    }
    *total_roi_num = after_top_k_num;
}

static hi_void svp_nnie_ssd_keep_top_k(sample_svp_nnie_ssd_get_result_param *param,
    sample_svp_nnie_stack *stack, hi_s32 *proposal)
{
    hi_u32 i, j, offset, num;
    hi_s32 *dst_score = HI_NULL;
    hi_s32 *dst_bbox = HI_NULL;
    hi_u32 keep_cnt = 0;

    offset = param->class_roi_num[0];
    for (i = 1; i < param->class_num; i++) {
        dst_score = (hi_s32 *)param->dst_score + offset;
        dst_bbox = (hi_s32 *)param->dst_roi + offset * SAMPLE_SVP_NNIE_COORD_NUM;
        for (j = 0; j < (hi_u32)param->class_roi_num[i]; j++) {
            proposal[keep_cnt * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] =
                dst_bbox[j * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET];
            proposal[keep_cnt * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] =
                dst_bbox[j * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET];
            proposal[keep_cnt * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] =
                dst_bbox[j * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET];
            proposal[keep_cnt * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] =
                dst_bbox[j * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET];
            proposal[keep_cnt * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET] = dst_score[j];
            proposal[keep_cnt * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] = i;
            keep_cnt++;
        }
        offset = offset + param->class_roi_num[i];
    }

    (hi_void)svp_nnie_ssd_quick_sort(proposal, stack, keep_cnt, keep_cnt);
    offset = param->class_roi_num[0];
    for (i = 1; i < param->class_num; i++) {
        num = 0;
        dst_score = (hi_s32 *)param->dst_score + offset;
        dst_bbox = (hi_s32 *)param->dst_roi + offset * SAMPLE_SVP_NNIE_COORD_NUM;
        for (j = 0; j < param->keep_top_k; j++) {
            if (proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_FLAG_OFFSET] == i) {
                dst_score[num] = proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET];
                dst_bbox[num * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] =
                    proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET];
                dst_bbox[num * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] =
                    proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET];
                dst_bbox[num * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] =
                    proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET];
                dst_bbox[num * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] =
                    proposal[j * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET];
                num++;
            }
        }
        param->class_roi_num[i] = (hi_s32)num;
        offset += num;
    }
}

static hi_void svp_nnie_ssd_detection_out_forward(sample_svp_nnie_ssd_get_result_param *param)
{
    hi_u32 i;
    hi_u32 prior_box_num = 0;
    hi_u32 total_roi_num;
    hi_s32 *proposal = HI_NULL;
    hi_s32 *decode_bboxes = HI_NULL;
    hi_s32 *after_top_k = HI_NULL;
    sample_svp_nnie_stack *stack = HI_NULL;

    for (i = 0; i < param->concat_num; i++) {
        prior_box_num += param->conf_blob_chn[i] * param->conf_blob_height[i] *
            param->conf_blob_width[i] / param->class_num;
    }
    param->prior_box_num = prior_box_num;

    /* prepare for assist mem_pool */
    decode_bboxes = param->assist_mem_pool;
    proposal = decode_bboxes + prior_box_num * SAMPLE_SVP_NNIE_COORD_NUM;
    after_top_k = proposal + SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * prior_box_num;
    stack = (sample_svp_nnie_stack *)(after_top_k + prior_box_num * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH);

    (hi_void)svp_nnie_ssd_decode_bbox(param, param->loc_addr, decode_bboxes);
    (hi_void)svp_nnie_ssd_bbox_nms(param, decode_bboxes, stack, proposal, &total_roi_num);

    if (total_roi_num > param->keep_top_k) {
        (hi_void)svp_nnie_ssd_keep_top_k(param, stack, after_top_k);
    }
}

static hi_s32 svp_nnie_yolov1_iou(hi_float *bbox, hi_u32 idx1, hi_u32 idx2)
{
    hi_float width, height, intersection, iou;

    width = sample_svp_nnie_min(
        bbox[idx1 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENX_OFFSET] +
        SAMPLE_SVP_NNIE_HALF * bbox[idx1 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET],
        bbox[idx2 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENX_OFFSET] +
        SAMPLE_SVP_NNIE_HALF * bbox[idx2 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET]) -
        sample_svp_nnie_max(
        bbox[idx1 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENX_OFFSET] -
        SAMPLE_SVP_NNIE_HALF * bbox[idx1 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET],
        bbox[idx2 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENX_OFFSET] -
        SAMPLE_SVP_NNIE_HALF * bbox[idx2 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET]);

    height = sample_svp_nnie_min(
        bbox[idx1 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENY_OFFSET] +
        SAMPLE_SVP_NNIE_HALF * bbox[idx1 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET],
        bbox[idx2 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENY_OFFSET] +
        SAMPLE_SVP_NNIE_HALF * bbox[idx2 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET]) -
        sample_svp_nnie_max(
        bbox[idx1 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENY_OFFSET] -
        SAMPLE_SVP_NNIE_HALF * bbox[idx1 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET],
        bbox[idx2 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENY_OFFSET] -
        SAMPLE_SVP_NNIE_HALF * bbox[idx2 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET]);
    intersection = ((width < 0) || (height < 0)) ? 0 : (width * height);
    iou = intersection / (bbox[idx1 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET] *
        bbox[idx1 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET] +
        bbox[idx2 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET] *
        bbox[idx2 * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET] - intersection);

    return (hi_s32)(iou * SAMPLE_SVP_NNIE_QUANT_BASE);
}

static hi_void svp_nnie_yolov1_arg_swap(hi_s32 *src1, hi_s32 *src2, hi_u32 array_size)
{
    hi_s32 i, tmp;

    for (i = 0; i < array_size; i++) {
        tmp = src1[i];
        src1[i] = src2[i];
        src2[i] = tmp;
    }
}

static hi_void svp_nnie_yolo_non_recursive_arg_quick_sort(hi_s32 *array, hi_s32 array_num, hi_u32 array_size,
    hi_u32 score_idx, sample_svp_nnie_stack *stack)
{
    hi_s32 i, j, low, high;
    hi_s32 top = 0;
    hi_s32 key_conf = array[score_idx];

    if (array_num < 1) {
        return;
    }
    stack[top].min = 0;
    stack[top].max = array_num - 1;

    while (top > -1) {
        low = stack[top].min;
        high = stack[top].max;
        i = low;
        j = high;
        top--;

        key_conf = array[array_size * low + score_idx];

        while (i < j) {
            while ((i < j) && (key_conf > array[j * array_size + score_idx])) {
                j--;
            }
            if (i < j) {
                svp_nnie_yolov1_arg_swap(&array[i * array_size], &array[j * array_size], array_size);
                i++;
            }

            while ((i < j) && (key_conf < array[i * array_size + score_idx])) {
                i++;
            }
            if (i < j) {
                svp_nnie_yolov1_arg_swap(&array[i * array_size], &array[j * array_size], array_size);
                j--;
            }
        }

        if (low < i - 1) {
            top++;
            stack[top].min = low;
            stack[top].max = i - 1;
        }

        if (high > i + 1) {
            top++;
            stack[top].min = i + 1;
            stack[top].max = high;
        }
    }
}

static hi_void svp_nnie_yolov1_nms(sample_svp_nnie_yolov1_get_result_param *param,
    hi_s32 *score, hi_float *bbox, hi_u32 bbox_num, hi_u32 *tmp_buf)
{
    hi_u32 i, j, idx1, idx2;
    sample_svp_nnie_yolov1_score *score_info = (sample_svp_nnie_yolov1_score *)tmp_buf;
    sample_svp_nnie_stack *assit_buf = (sample_svp_nnie_stack *)((hi_u8 *)tmp_buf +
        bbox_num * sizeof(sample_svp_nnie_yolov1_score));

    for (i = 0; i < bbox_num; i++) {
        if (score[i] < (hi_s32)param->conf_threshold) {
            score[i] = 0;
        }
    }

    for (i = 0; i < bbox_num; i++) {
        score_info[i].idx = i;
        score_info[i].score = (score[i]);
    }

    /* quick sort */
    (hi_void)svp_nnie_yolo_non_recursive_arg_quick_sort((hi_s32 *)score_info, bbox_num,
        sizeof(sample_svp_nnie_yolov1_score) / sizeof(hi_u32), 1, assit_buf);

    /* NMS */
    for (i = 0; i < bbox_num; i++) {
        idx1 = score_info[i].idx;
        if (score_info[i].score == 0) {
            break;
        }
        for (j = i + 1; j < bbox_num; j++) {
            idx2 = score_info[j].idx;
            if (score_info[j].score == 0) {
                break;
            }
            if (svp_nnie_yolov1_iou(bbox, idx1, idx2) > (hi_s32)param->nms_threshold) {
                score_info[j].score = 0;
                score[score_info[j].idx] = 0;
            }
        }
    }
}

static hi_void svp_nnie_yolov1_convert_position(hi_float *bbox,
    hi_u32 ori_img_width, hi_u32 ori_img_height, hi_float *roi)
{
    hi_float x_min, y_min, x_max, y_max;

    x_min = *(bbox + SAMPLE_SVP_NNIE_BBOX_CENX_OFFSET) - *(bbox + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET) *
        SAMPLE_SVP_NNIE_HALF;
    x_min = x_min > 0 ? x_min : 0;

    y_min = *(bbox + SAMPLE_SVP_NNIE_BBOX_CENY_OFFSET) - *(bbox + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET) *
        SAMPLE_SVP_NNIE_HALF;
    y_min = y_min > 0 ? y_min : 0;

    x_max = *(bbox + SAMPLE_SVP_NNIE_BBOX_CENX_OFFSET) + *(bbox + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET) *
        SAMPLE_SVP_NNIE_HALF;
    x_max = x_max > ori_img_width ? ori_img_width : x_max;

    y_max = *(bbox + SAMPLE_SVP_NNIE_BBOX_CENY_OFFSET) + *(bbox + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET) *
        SAMPLE_SVP_NNIE_HALF;
    y_max = y_max > ori_img_height ? ori_img_height : y_max;

    roi[SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] = x_min;
    roi[SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] = y_min;
    roi[SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] = x_max;
    roi[SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] = y_max;
}

static hi_void svp_nnie_yolov1_get_bbox_and_score(sample_svp_nnie_yolov1_get_result_param *param,
    hi_float *class_prob, hi_float *bbox_conf, hi_float *bbox, hi_s32 *score)
{
    hi_u32 i, j, k, offset;
    hi_u32 index = 0;
    hi_float conf;
    hi_u32 grid_num = param->grid_num_height * param->grid_num_width;

    for (i = 0; i < grid_num; i++) {
        for (j = 0; j < param->bbox_num_each_grid; j++) {
            for (k = 0; k < param->class_num; k++) {
                offset = k * grid_num * param->bbox_num_each_grid;
                conf = (*(class_prob + i * param->class_num + k)) * (*(bbox_conf + i * param->bbox_num_each_grid + j));
                *(score + offset + index) = (hi_s32)(conf * SAMPLE_SVP_NNIE_QUANT_BASE);
            }
            index++;
        }
    }

    for (i = 0; i < grid_num; i++) {
        offset = i * param->bbox_num_each_grid;
        for (j = 0; j < param->bbox_num_each_grid; j++) {
            bbox[(offset + j) * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENX_OFFSET] =
                (bbox[(offset + j) * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENX_OFFSET] +
                i % param->grid_num_width) / param->grid_num_width * param->ori_img_width;

            bbox[(offset + j) * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENY_OFFSET] =
                (bbox[(offset + j) * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_CENY_OFFSET] + i /
                param->grid_num_width) / param->grid_num_height * param->ori_img_height;

            bbox[(offset + j) * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET] =
                bbox[(offset + j) * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET] *
                bbox[(offset + j) * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_WIDTH_OFFSET] *
                param->ori_img_width;

            bbox[(offset + j) * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET] =
                bbox[(offset + j) * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET] *
                bbox[(offset + j) * SAMPLE_SVP_NNIE_COORD_NUM + SAMPLE_SVP_NNIE_BBOX_HEIGHT_OFFSET] *
                param->ori_img_height;
        }
    }
}

static hi_void svp_nnie_yolov1_bbox_filter_and_nms(sample_svp_nnie_yolov1_get_result_param *param,
    hi_float *bbox, hi_s32 *score, hi_u32 *mem_pool)
{
    hi_u32 i, j, idx, roi_num;
    hi_u32 bbox_num = param->grid_num_height * param->grid_num_width * param->bbox_num_each_grid;
    hi_s32 *each_class_score = HI_NULL;
    hi_float roi[SAMPLE_SVP_NNIE_COORD_NUM];
    sample_svp_nnie_yolov1_score *score_unit = HI_NULL;

    for (i = 0; i < param->class_num; i++) {
        each_class_score = score + bbox_num * i;
        (hi_void)svp_nnie_yolov1_nms(param, each_class_score, bbox, bbox_num, mem_pool);

        score_unit = (sample_svp_nnie_yolov1_score *)mem_pool;
        roi_num = 0;
        for (j = 0; j < bbox_num; j++) {
            if (score_unit[j].score != 0) {
                roi_num++;
                *(param->dst_scores++) = score_unit[j].score;
                idx = score_unit[j].idx;
                (hi_void)svp_nnie_yolov1_convert_position((bbox + idx * SAMPLE_SVP_NNIE_COORD_NUM),
                    param->ori_img_width, param->ori_img_height, roi);
                *(param->dst_roi++) = (hi_s32)roi[SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET];
                *(param->dst_roi++) = (hi_s32)roi[SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET];
                *(param->dst_roi++) = (hi_s32)roi[SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET];
                *(param->dst_roi++) = (hi_s32)roi[SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET];
            } else {
                continue;
            }
        }
        *(param->class_roi_num++) = roi_num;
    }
}

static hi_void svp_nnie_yolov1_detection(sample_svp_nnie_yolov1_get_result_param *param)
{
    hi_float *class_prob = HI_NULL;
    hi_float *bbox_conf = HI_NULL;
    hi_float *bbox = HI_NULL;
    hi_s32 *score = HI_NULL;
    hi_u32 *assist_buf = HI_NULL;
    hi_u32 grid_num = param->grid_num_height * param->grid_num_width;
    hi_u32 i, offset;

    offset = grid_num * (param->bbox_num_each_grid * (SAMPLE_SVP_NNIE_BBOX_DELTA_NUM + 1) + param->class_num);
    class_prob = (hi_float *)param->tmp_buf;
    bbox_conf = class_prob + grid_num * param->class_num;
    bbox = bbox_conf + grid_num * param->bbox_num_each_grid;

    score = (hi_s32 *)(class_prob + offset);
    assist_buf = (hi_u32 *)(score + grid_num * param->bbox_num_each_grid * param->class_num);

    for (i = 0; i < offset; i++) {
        ((hi_float *)param->tmp_buf)[i] = param->fc_result[i] / ((hi_float)SAMPLE_SVP_NNIE_QUANT_BASE);
    }
    (hi_void)svp_nnie_yolov1_get_bbox_and_score(param, class_prob, bbox_conf, bbox, score);
    (hi_void)svp_nnie_yolov1_bbox_filter_and_nms(param, bbox, score, assist_buf);
}

static hi_void svp_nnie_yolov2_iou(sample_svp_nnie_yolov2_bbox *bbox1,
    sample_svp_nnie_yolov2_bbox *bbox2, hi_float *iou)
{
    hi_float inter_width, inter_height, inter_area, box1_area, box2_area, union_area;

    *iou = 0;
    inter_width = sample_svp_nnie_min(bbox1->x_max, bbox2->x_max) - sample_svp_nnie_max(bbox1->x_min, bbox2->x_min);
    inter_height = sample_svp_nnie_min(bbox1->y_max, bbox2->y_max) - sample_svp_nnie_max(bbox1->y_min, bbox2->y_min);
    if ((inter_width <= 0) || (inter_height <= 0)) {
        return;
    }

    inter_area = inter_width * inter_height;
    box1_area = (bbox1->x_max - bbox1->x_min) * (bbox1->y_max - bbox1->y_min);
    box2_area = (bbox2->x_max - bbox2->x_min) * (bbox2->y_max - bbox2->y_min);
    union_area = box1_area + box2_area - inter_area;

    *iou = inter_area / union_area;
}

static hi_void svp_nnie_yolov2_non_max_suppression(sample_svp_nnie_yolov2_bbox *bbox,
    hi_u32 bbox_num, hi_u32 nms_threshold, hi_u32 max_roi_num)
{
    hi_u32 i, j;
    hi_u32 num = 0;
    hi_float iou;
    for (i = 0; i < bbox_num && num < max_roi_num; i++) {
        if (bbox[i].mask != 0) {
            continue;
        }
        num++;
        for (j = i + 1; j < bbox_num; j++) {
            if (bbox[j].mask != 0) {
                continue;
            }
            svp_nnie_yolov2_iou(&bbox[i], &bbox[j], &iou);
            if (iou >= (hi_float)nms_threshold / SAMPLE_SVP_NNIE_QUANT_BASE) {
                bbox[j].mask = 1;
            }
        }
    }
}

static hi_void svp_nnie_get_max_val(hi_float *val, hi_u32 num, hi_float *max_val, hi_u32 *max_val_idx)
{
    hi_u32 i;
    hi_float max_tmp;

    max_tmp = val[0];
    *max_val_idx = 0;
    for (i = 1; i < num; i++) {
        if (val[i] > max_tmp) {
            max_tmp = val[i];
            *max_val_idx = i;
        }
    }

    *max_val = max_tmp;
}

static hi_void svp_nnie_yolov2_get_bbox_and_score(sample_svp_nnie_yolov2_get_result_param *param,
    hi_float *input_data, hi_float *bbox_tmp, sample_svp_nnie_yolov2_bbox *bbox, hi_u32 *out_bbox_num)
{
    hi_u32 grid_num = param->grid_num_width * param->grid_num_height;
    hi_u32 para_num = (SAMPLE_SVP_NNIE_COORD_NUM + 1 + param->class_num);
    hi_u32 bbox_num = 0;
    hi_s32 score;
    hi_u32 h, w, c, k, max_val_idx, idx;
    hi_u32 n = 0;
    hi_float x, y, width, height, obj_score, max_score;

    /* permute */
    for (h = 0; h < param->grid_num_height; h++) {
        for (w = 0; w < param->grid_num_width; w++) {
            for (c = 0; c < param->bbox_num_each_grid * para_num; c++) {
                bbox_tmp[n++] = input_data[c * grid_num + h * param->grid_num_width + w];
            }
        }
    }

    for (n = 0; n < grid_num; n++) {
        w = n % param->grid_num_width;
        h = n / param->grid_num_width;
        for (k = 0; k < param->bbox_num_each_grid; k++) {
            idx = (n * param->bbox_num_each_grid + k) * para_num;
            x = (hi_float)((w + sample_svp_nnie_sigmoid(bbox_tmp[idx + SAMPLE_SVP_NNIE_BBOX_CENX_DELTA_OFFSET])) /
                param->grid_num_width);
            y = (hi_float)((h + sample_svp_nnie_sigmoid(bbox_tmp[idx + SAMPLE_SVP_NNIE_BBOX_CENY_DELTA_OFFSET])) /
                param->grid_num_height);
            width = (hi_float)((exp(bbox_tmp[idx + SAMPLE_SVP_NNIE_BBOX_WIDTH_DELTA_OFFSET]) *
                param->bias[SAMPLE_SVP_NNIE_DOUBLE * k]) / param->grid_num_width);
            height = (hi_float)((exp(bbox_tmp[idx + SAMPLE_SVP_NNIE_BBOX_HEIGHT_DELTA_OFFSET]) *
                param->bias[SAMPLE_SVP_NNIE_DOUBLE * k + 1]) / param->grid_num_height);

            obj_score = sample_svp_nnie_sigmoid(bbox_tmp[idx + SAMPLE_SVP_NNIE_YOLOV2_OBJ_CONF_OFFSET]);
            (hi_void)svp_nnie_softmax(&bbox_tmp[idx + SAMPLE_SVP_NNIE_YOLOV2_CLASS_CONF_OFFSET], param->class_num);

            svp_nnie_get_max_val(&bbox_tmp[idx + SAMPLE_SVP_NNIE_YOLOV2_CLASS_CONF_OFFSET],
                param->class_num, &max_score, &max_val_idx);

            score = (hi_s32)(max_score * obj_score * SAMPLE_SVP_NNIE_QUANT_BASE);
            if (score > param->conf_threshold) {
                bbox[bbox_num].x_min = (hi_float)(x - width * SAMPLE_SVP_NNIE_HALF);
                bbox[bbox_num].x_max = (hi_float)(x + width * SAMPLE_SVP_NNIE_HALF);
                bbox[bbox_num].y_min = (hi_float)(y - height * SAMPLE_SVP_NNIE_HALF);
                bbox[bbox_num].y_max = (hi_float)(y + height * SAMPLE_SVP_NNIE_HALF);
                bbox[bbox_num].cls_score = score;
                bbox[bbox_num].class_idx = max_val_idx;
                bbox[bbox_num].mask = 0;
                bbox_num++;
            }
        }
    }
    *out_bbox_num = bbox_num;
}

static hi_void svp_nnie_yolov2_bbox_filter_and_nms(sample_svp_nnie_yolov2_get_result_param *param,
    sample_svp_nnie_yolov2_bbox *bbox, hi_u32 bbox_num, sample_svp_nnie_stack *assist_stack)
{
    hi_u32 i, n;

    /* quick_sort */
    if (bbox_num > 1) {
        svp_nnie_yolo_non_recursive_arg_quick_sort((hi_s32 *)bbox, bbox_num,
            sizeof(sample_svp_nnie_yolov2_bbox) / sizeof(hi_s32), SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET, assist_stack);
    }
    /* nms */
    svp_nnie_yolov2_non_max_suppression(bbox, bbox_num, param->nms_threshold, bbox_num);
    /* get the result */
    (hi_void)memset_s((hi_void *)param->class_roi_num, param->class_num * sizeof(hi_u32),
        0, param->class_num * sizeof(hi_u32));
    for (i = 0; i < param->class_num; i++) {
        for (n = 0; n < bbox_num; n++) {
            if (bbox[n].mask == 0 && i == bbox[n].class_idx) {
                *(param->dst_roi++) = (hi_s32)sample_svp_nnie_max(bbox[n].x_min * param->ori_img_width, 0);
                *(param->dst_roi++) = (hi_s32)sample_svp_nnie_max(bbox[n].y_min * param->ori_img_height, 0);
                *(param->dst_roi++) = (hi_s32)sample_svp_nnie_min(bbox[n].x_max * param->ori_img_width,
                    param->ori_img_width);
                *(param->dst_roi++) = (hi_s32)sample_svp_nnie_min(bbox[n].y_max * param->ori_img_height,
                    param->ori_img_height);
                *(param->dst_score++) = bbox[n].cls_score;
                *(param->class_roi_num + bbox[n].class_idx) = *(param->class_roi_num + bbox[n].class_idx) + 1;
            }
        }
    }
}

static hi_s32 svp_nnie_yolov2_get_result(sample_svp_nnie_yolov2_get_result_param *param)
{
    hi_u32 i, bbox_num;
    hi_u32 grid_num = param->grid_num_width * param->grid_num_height;
    hi_u32 para_num = (SAMPLE_SVP_NNIE_COORD_NUM + 1 + param->class_num);
    hi_u32 total_bbox_num = grid_num * param->bbox_num_each_grid;
    hi_float *bbox_tmp = HI_NULL;
    hi_float *input_data = HI_NULL;
    hi_u32 assist_buff_size = total_bbox_num * sizeof(sample_svp_nnie_stack);
    hi_u32 bbox_buff_size = total_bbox_num * sizeof(sample_svp_nnie_yolov2_bbox);
    sample_svp_nnie_stack *assist_stack = HI_NULL;
    sample_svp_nnie_yolov2_bbox *bbox = HI_NULL;

    /* store float type data */
    input_data = (hi_float *)param->tmp_buf;
    /* assist buffer for sort */
    assist_stack = (sample_svp_nnie_stack *)(input_data + total_bbox_num * para_num);
    /* assit box buffer */
    bbox = (sample_svp_nnie_yolov2_bbox *)((hi_u8 *)assist_stack + assist_buff_size);
    /* bbox tmp buffer */
    bbox_tmp = (hi_float *)((hi_u8 *)bbox + bbox_buff_size);

    for (i = 0; i < total_bbox_num * para_num; i++) {
        input_data[i] = (hi_float)(param->input_data[i]) / SAMPLE_SVP_NNIE_QUANT_BASE;
    }

    (hi_void)svp_nnie_yolov2_get_bbox_and_score(param, input_data, bbox_tmp, bbox, &bbox_num);
    (hi_void)svp_nnie_yolov2_bbox_filter_and_nms(param, bbox, bbox_num, assist_stack);
    return HI_SUCCESS;
}

static hi_void svp_nnie_yolov3_decode_bbox(sample_svp_nnie_yolov3_get_result_param *param,
    hi_float *permute, hi_u32 idx, sample_svp_nnie_yolov3_bbox *bbox, hi_u32 *total_bbox_num)
{
    hi_u32 j, k, grid_x_idx, grid_y_idx, max_value_idx, offset;
    hi_float start_x, start_y, width, height, obj_score, max_score;
    hi_s32 class_score;
    hi_u32 bbox_offset = *total_bbox_num;

    /* decode bbox and calculate score */
    for (j = 0; j < param->grid_num_width[idx] * param->grid_num_height[idx]; j++) {
        grid_x_idx = j % param->grid_num_width[idx];
        grid_y_idx = j / param->grid_num_width[idx];
        for (k = 0; k < param->bbox_num_each_grid; k++) {
            offset = (j * param->bbox_num_each_grid + k) * SAMPLE_SVP_NNIE_YOLOV3_EACH_BBOX_INFER_RESULT_NUM;
            /* decode bbox */
            start_x = ((hi_float)grid_x_idx + sample_svp_nnie_sigmoid(permute[offset +
                SAMPLE_SVP_NNIE_BBOX_CENX_DELTA_OFFSET])) / param->grid_num_width[idx];
            start_y = ((hi_float)grid_y_idx + sample_svp_nnie_sigmoid(permute[offset +
                SAMPLE_SVP_NNIE_BBOX_CENY_DELTA_OFFSET])) / param->grid_num_height[idx];
            width = (hi_float)(exp(permute[offset + SAMPLE_SVP_NNIE_BBOX_WIDTH_DELTA_OFFSET]) *
                param->bias[idx][SAMPLE_SVP_NNIE_DOUBLE * k]) / param->ori_img_width;
            height = (hi_float)(exp(permute[offset + SAMPLE_SVP_NNIE_BBOX_HEIGHT_DELTA_OFFSET]) *
                param->bias[idx][SAMPLE_SVP_NNIE_DOUBLE * k + 1]) / param->ori_img_height;

            /* calculate score */
            svp_nnie_sigmoid(&permute[offset + SAMPLE_SVP_NNIE_YOLOV3_OBJ_CONF_OFFSET], (param->class_num + 1));
            svp_nnie_get_max_val(&permute[offset + SAMPLE_SVP_NNIE_YOLOV3_CLASS_CONF_OFFSET],
                param->class_num, &max_score, &max_value_idx);
            obj_score = permute[offset + SAMPLE_SVP_NNIE_YOLOV3_OBJ_CONF_OFFSET];
            class_score = (hi_s32)(max_score * obj_score * SAMPLE_SVP_NNIE_QUANT_BASE);
            /* filter low score roi */
            if (class_score > param->conf_threshold) {
                bbox[bbox_offset].x_min = (hi_float)(start_x - width * SAMPLE_SVP_NNIE_HALF);
                bbox[bbox_offset].y_min = (hi_float)(start_y - height * SAMPLE_SVP_NNIE_HALF);
                bbox[bbox_offset].x_max = (hi_float)(start_x + width * SAMPLE_SVP_NNIE_HALF);
                bbox[bbox_offset].y_max = (hi_float)(start_y + height * SAMPLE_SVP_NNIE_HALF);
                bbox[bbox_offset].cls_score = class_score;
                bbox[bbox_offset].mask = 0;
                bbox[bbox_offset].class_idx = max_value_idx;
                bbox_offset++;
            }
        }
    }
    *total_bbox_num = bbox_offset;
}

static hi_void svp_nnie_yolov3_get_bbox_and_score(sample_svp_nnie_yolov3_get_result_param *param,
    hi_u32 blob_idx, hi_float *permute, sample_svp_nnie_yolov3_bbox *bbox, hi_u32 *out_bbox_num)
{
    hi_u32 c, h, w, offset, chn_offset, height_offset;
    hi_s32 *input_blob = HI_NULL;

    /* permute */
    offset = 0;
    input_blob = param->input_blob[blob_idx];
    chn_offset = param->grid_num_height[blob_idx] * param->input_stride[blob_idx] / sizeof(hi_s32);
    height_offset = param->input_stride[blob_idx] / sizeof(hi_s32);
    for (h = 0; h < param->grid_num_height[blob_idx]; h++) {
        for (w = 0; w < param->grid_num_width[blob_idx]; w++) {
            for (c = 0; c < SAMPLE_SVP_NNIE_YOLOV3_EACH_BBOX_INFER_RESULT_NUM * param->bbox_num_each_grid; c++) {
                permute[offset++] = (hi_float)(input_blob[c * chn_offset + h * height_offset + w]) /
                    SAMPLE_SVP_NNIE_QUANT_BASE;
            }
        }
    }
    /* decode bbox and calculate score */
    svp_nnie_yolov3_decode_bbox(param, permute, blob_idx, bbox, out_bbox_num);
}

static hi_void svp_nnie_yolov3_bbox_filter_and_nms(sample_svp_nnie_yolov3_get_result_param *param,
    sample_svp_nnie_yolov3_bbox *bbox, hi_u32 bbox_num, hi_s32 *assist_buf)
{
    hi_u32 i, j, class_roi_cnt;
    /* quick sort */
    (hi_void)svp_nnie_yolo_non_recursive_arg_quick_sort((hi_s32 *)bbox, bbox_num,
        sizeof(sample_svp_nnie_yolov3_bbox) / sizeof(hi_u32), SAMPLE_SVP_NNIE_PROPOSAL_CONF_OFFSET,
        (sample_svp_nnie_stack *)assist_buf);

    /* yolov3 and yolov2 have the same nms operation */
    (hi_void)svp_nnie_yolov2_non_max_suppression(bbox, bbox_num, param->nms_threshold, bbox_num);

    /* get result */
    for (i = 0; i < param->class_num; i++) {
        class_roi_cnt = 0;
        for (j = 0; j < bbox_num; j++) {
            if ((bbox[j].mask == 0) && (i == bbox[j].class_idx)) {
                *(param->dst_roi++) = sample_svp_nnie_max((hi_s32)(bbox[j].x_min * param->ori_img_width), 0);
                *(param->dst_roi++) = sample_svp_nnie_max((hi_s32)(bbox[j].y_min * param->ori_img_height), 0);
                *(param->dst_roi++) = sample_svp_nnie_min((hi_s32)(bbox[j].x_max * param->ori_img_width),
                    param->ori_img_width);
                *(param->dst_roi++) = sample_svp_nnie_min((hi_s32)(bbox[j].y_max * param->ori_img_height),
                    param->ori_img_height);
                *(param->dst_score++) = bbox[j].cls_score;
                class_roi_cnt++;
            }
        }
        *(param->class_roi_num + i) = class_roi_cnt;
    }
}

static hi_s32 svp_nnie_yolov3_get_result(sample_svp_nnie_yolov3_get_result_param *param)
{
    hi_u32 i;
    hi_float *permute = HI_NULL;
    hi_u32 blob_size, out_bbox_num;
    hi_u32 max_blob_size = 0;
    hi_u32 total_bbox_num = 0;
    sample_svp_nnie_yolov3_bbox *bbox = HI_NULL;
    hi_s32 *assist_buf = HI_NULL;

    for (i = 0; i < SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM; i++) {
        blob_size = param->grid_num_width[i] * param->grid_num_height[i] * sizeof(hi_u32) *
            SAMPLE_SVP_NNIE_YOLOV3_EACH_BBOX_INFER_RESULT_NUM * param->bbox_num_each_grid;
        if (max_blob_size < blob_size) {
            max_blob_size = blob_size;
        }
    }

    for (i = 0; i < SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM; i++) {
        total_bbox_num += param->grid_num_width[i] * param->grid_num_height[i] * param->bbox_num_each_grid;
    }

    /* get each tmpbuf addr */
    permute = (hi_float *)param->tmp_buf;
    bbox = (sample_svp_nnie_yolov3_bbox *)(permute + max_blob_size / sizeof(hi_s32));
    assist_buf = (hi_s32 *)(bbox + total_bbox_num);
    out_bbox_num = 0;
    for (i = 0; i < SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM; i++) {
        (hi_void)svp_nnie_yolov3_get_bbox_and_score(param, i, permute, bbox, &out_bbox_num);
    }
    (hi_void)svp_nnie_yolov3_bbox_filter_and_nms(param, bbox, out_bbox_num, assist_buf);
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_cnn_get_top_n(sample_svp_nnie_param *nnie_param, sample_svp_nnie_cnn_sw_param *sw_param)
{
    hi_s32 ret;
    sample_svp_nnie_cnn_get_top_n_param param;

    ret = sample_svp_nnie_check_and_fill_cnn_get_top_n_param(nnie_param, sw_param, &param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_cnn_get_top_n_param!\n");
    ret = svp_nnie_cnn_get_top_n(&param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,get top_n failed!\n");
    return ret;
}

hi_u32 sample_svp_nnie_rpn_tmp_buf_size(hi_u32 ratio_anchor_num,
    hi_u32 scale_anchor_num, hi_u32 conv_height, hi_u32 conv_width, hi_u32 *total_size)
{
    hi_s32 ret;
    hi_u64 size;
    hi_u32 anchors_num, bbox_delta_size, proposal_size, score_size, stack_size;

    ret = sample_svp_nnie_check_rpn_tmp_buf_size_param(ratio_anchor_num, scale_anchor_num, conv_height,
        conv_width, total_size);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_rpn_tmp_buf_size_param failed!\n");

    anchors_num = ratio_anchor_num * scale_anchor_num * conv_height * conv_width;
    bbox_delta_size = sizeof(hi_u32) * SAMPLE_SVP_NNIE_COORD_NUM * anchors_num;
    proposal_size = sizeof(hi_u32) * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * anchors_num;
    score_size = sizeof(hi_float) * anchors_num * SAMPLE_SVP_NNIE_DOUBLE;
    stack_size = sizeof(sample_svp_nnie_stack) * anchors_num;

    size = bbox_delta_size + proposal_size + score_size + stack_size;
    sample_svp_check_exps_return(size > SAMPLE_SVP_NNIE_MAX_U32, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,size(%llu) is greater than %u!\n", size, SAMPLE_SVP_NNIE_MAX_U32);
    *total_size = (hi_u32)size;
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_faster_rcnn_rpn(sample_svp_nnie_faster_rcnn_sw_param *sw_param)
{
    hi_s32 ret;
    sample_svp_nnie_rpn_param param;

    ret = sample_svp_nnie_check_and_fill_faster_rcnn_rpn_param(sw_param, &param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_faster_rcnn_rpn_param failed!\n");

    ret = svp_nnie_rpn(&param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,svp_nnie_rpn failed!\n");
    if (sw_param->rpn_bbox.shape.whc.height > 0) {
        ret = sample_common_svp_flush_cache(sw_param->rpn_bbox.phys_addr,
            sample_svp_convert_addr_to_ptr(hi_void, sw_param->rpn_bbox.virt_addr), sw_param->rpn_bbox.num *
            sw_param->rpn_bbox.shape.whc.chn * sw_param->rpn_bbox.shape.whc.height * sw_param->rpn_bbox.stride);
        sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,flush cache failed!\n");
    }
    return ret;
}

static hi_s32 sample_svp_nnie_trans_rpn_bbox_data_type(hi_svp_blob *bbox)
{
    hi_u32 i;
    hi_u32 offset = bbox->stride / sizeof(hi_s32);
    hi_s32 *tmp = sample_svp_convert_addr_to_ptr(hi_s32, bbox->virt_addr);
    hi_s32 *x_min = HI_NULL;
    hi_s32 *y_min = HI_NULL;
    hi_s32 *x_max = HI_NULL;
    hi_s32 *y_max = HI_NULL;
    hi_s32 ret;

    sample_svp_check_exps_return(bbox->virt_addr == 0, HI_ERR_SVP_NNIE_NULL_PTR,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,bbox->virt_addr can't be 0!\n");
    if (bbox->type == HI_SVP_BLOB_TYPE_BBOX_S20Q12) {
        for (i = 0; i < bbox->shape.whc.height; i++) {
            *(tmp + offset * i + SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET) /= SAMPLE_SVP_NNIE_QUANT_BASE;
            *(tmp + offset * i + SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET) /= SAMPLE_SVP_NNIE_QUANT_BASE;
            *(tmp + offset * i + SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET) /= SAMPLE_SVP_NNIE_QUANT_BASE;
            *(tmp + offset * i + SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET) /= SAMPLE_SVP_NNIE_QUANT_BASE;
        }
    } else if (bbox->type == HI_SVP_BLOB_TYPE_BSI_SQ32) {
        x_min = tmp + sample_svp_nnie_align_32(bbox->shape.whc.chn * sizeof(hi_s32)) / sizeof(hi_s32);
        y_min = x_min + offset;
        x_max = y_min + offset;
        y_max = x_max + offset;
        for (i = 0; i < *tmp; i++) {
            *(x_min + i) /= SAMPLE_SVP_NNIE_QUANT_BASE;
            *(y_min + i) /= SAMPLE_SVP_NNIE_QUANT_BASE;
            *(x_max + i) /= SAMPLE_SVP_NNIE_QUANT_BASE;
            *(y_max + i) /= SAMPLE_SVP_NNIE_QUANT_BASE;
        }
        ret = sample_common_svp_flush_cache(bbox->phys_addr, (hi_void *)tmp, bbox->num * bbox->shape.whc.chn *
            bbox->shape.whc.height * bbox->stride + sample_svp_nnie_align_32(bbox->shape.whc.chn * sizeof(hi_s32)));
        sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_common_svp_flush_cache failed!\n");
    } else {
        sample_svp_check_exps_return(1, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,bbox->type(%d) must be %d or %d!\n", bbox->type, HI_SVP_BLOB_TYPE_BBOX_S20Q12,
            HI_SVP_BLOB_TYPE_BSI_SQ32);
    }
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_faster_rcnn_get_result(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_faster_rcnn_sw_param *sw_param)
{
    hi_s32 ret;
    sample_svp_nnie_faster_rcnn_get_result_param param;

    sample_svp_check_exps_return(sw_param == HI_NULL, HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param is HI_NULL!\n");
    ret = sample_svp_nnie_check_and_fill_faster_rcnn_get_result_param(nnie_param, sw_param, &param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_faster_rcnn_get_result failed!\n");
    ret = sample_svp_nnie_trans_rpn_bbox_data_type(&(sw_param->rpn_bbox));
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_trans_rpn_bbox_data_type failed!\n");
    ret = svp_nnie_faster_rcnn_get_result(&param);

    return ret;
}

hi_s32 sample_svp_nnie_rfcn_rpn(sample_svp_nnie_rfcn_sw_param *sw_param)
{
    hi_s32 ret;
    sample_svp_nnie_rpn_param param;

    ret = sample_svp_nnie_check_and_fill_rfcn_rpn_param(sw_param, &param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_rfcn_rpn_param failed!\n");

    ret = svp_nnie_rpn(&param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,svp_nnie_rpn failed!\n");
    if (sw_param->rpn_bbox.shape.whc.height > 0) {
        ret = sample_common_svp_flush_cache(sw_param->rpn_bbox.phys_addr,
            sample_svp_convert_addr_to_ptr(hi_void, sw_param->rpn_bbox.virt_addr), sw_param->rpn_bbox.num *
            sw_param->rpn_bbox.shape.whc.chn * sw_param->rpn_bbox.shape.whc.height * sw_param->rpn_bbox.stride);
        sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,flush cache failed!\n");
    }
    return ret;
}

hi_s32 sample_svp_nnie_rfcn_get_result(sample_svp_nnie_param *nnie_param, sample_svp_nnie_rfcn_sw_param *sw_param)
{
    hi_s32 ret;
    sample_svp_nnie_rfcn_get_result_param param;

    ret = sample_svp_nnie_check_and_fill_rfcn_get_result_param(nnie_param, sw_param, &param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_faster_rcnn_get_result failed!\n");
    ret = sample_svp_nnie_trans_rpn_bbox_data_type(&(sw_param->rpn_bbox));
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_trans_rpn_bbox_data_type failed!\n");

    ret = svp_nnie_rfcn_get_result(&param);

    return ret;
}

hi_s32 sample_svp_nnie_ssd_get_result(sample_svp_nnie_param *nnie_param, sample_svp_nnie_ssd_sw_param *sw_param)
{
    hi_s32 ret;
    sample_svp_nnie_ssd_get_result_param param;

    ret = sample_svp_nnie_check_and_fill_ssd_get_result_param(nnie_param, sw_param, &param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_ssd_get_result_param failed!\n");

    /* softmax */
    param.conf_scores = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->softmax_tmp_buf.virt_addr);
    sample_svp_check_exps_return(param.conf_scores == HI_NULL, HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->softmax_tmp_buf.virt_addr is 0\n");
    (hi_void)svp_nnie_ssd_softmax_concat(&param, param.conf_addr, param.conf_scores);

    /* detection */
    (hi_void)svp_nnie_ssd_detection_out_forward(&param);

    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_yolov1_get_result(sample_svp_nnie_param *nnie_param, sample_svp_nnie_yolov1_sw_param *sw_param)
{
    hi_s32 ret;
    sample_svp_nnie_yolov1_get_result_param param;

    ret = sample_svp_nnie_check_and_fill_yolov1_get_result_param(nnie_param, sw_param, &param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_yolov1_get_result_param failed\n");
    (hi_void)svp_nnie_yolov1_detection(&param);
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_yolov2_get_result(sample_svp_nnie_param *nnie_param, sample_svp_nnie_yolov2_sw_param *sw_param)
{
    hi_s32 ret;
    sample_svp_nnie_yolov2_get_result_param param;

    ret = sample_svp_nnie_check_and_fill_yolov2_get_result_param(nnie_param, sw_param, &param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_yolov2_get_result_param failed\n");

    ret = svp_nnie_yolov2_get_result(&param);
    return ret;
}

hi_s32 sample_svp_nnie_yolov3_get_result(sample_svp_nnie_param *nnie_param, sample_svp_nnie_yolov3_sw_param *sw_param)
{
    hi_s32 ret;
    sample_svp_nnie_yolov3_get_result_param param;

    ret = sample_svp_nnie_check_and_fill_yolov3_get_result_param(nnie_param, sw_param, &param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov3_get_result failed\n");
    ret = svp_nnie_yolov3_get_result(&param);
    return ret;
}

hi_s32 sample_svp_nnie_rpn_generate_anchor_box(sample_svp_nnie_rpn_generate_base_anchor_param *param,
    hi_bool is_used_for_sw)
{
    hi_u32 base_anchor[SAMPLE_SVP_NNIE_COORD_NUM] = { 0, 0, (param->min_size - 1), (param->min_size - 1) };
    hi_u32 w, h;
    sample_svp_nnie_base_box base_box;
    sample_svp_nnie_anchor_box_ctrl_info ctrl;
    sample_svp_nnie_anchor_box_dst dst = {0};
    hi_s32 ret;

    ret = sample_svp_nnie_check_rpn_generate_anchor_box_param(param, is_used_for_sw);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_rpn_generate_anchor_box_param failed\n");
    /* calculate the start pointer of each part in MemPool */
    dst.mem_addr = (hi_s32 *)param->dst;
    if (is_used_for_sw == HI_FALSE) {
        dst.x_min = param->dst;
        dst.y_min = dst.x_min + param->stride / sizeof(hi_s32);
        dst.x_max = dst.y_min + param->stride / sizeof(hi_s32);
        dst.y_max = dst.x_max + param->stride / sizeof(hi_s32);
    }

    /* Generate the base box */
    base_box.base_width = (hi_float)(base_anchor[SAMPLE_SVP_NNIE_PROPOSAL_XMAX_OFFSET] -
        base_anchor[SAMPLE_SVP_NNIE_PROPOSAL_XMIN_OFFSET] + 1);
    base_box.base_height = (hi_float)(base_anchor[SAMPLE_SVP_NNIE_PROPOSAL_YMAX_OFFSET] -
        base_anchor[SAMPLE_SVP_NNIE_PROPOSAL_YMIN_OFFSET] + 1);
    base_box.center_x = (hi_float)(base_anchor[0] + ((base_box.base_width - 1) * SAMPLE_SVP_NNIE_HALF));
    base_box.center_y = (hi_float)(base_anchor[1] + ((base_box.base_height - 1) * SAMPLE_SVP_NNIE_HALF));

    /* fill ctrl info */
    ctrl.is_used_for_sw = is_used_for_sw;
    ctrl.pixel_interval = SAMPLE_SVP_NNIE_QUANT_BASE / param->spatial_scale;

    for (h = 0; h < param->feature_map_height; h++) {
        ctrl.height_idx = h;
        for (w = 0; w < param->feature_map_width; w++) {
            ctrl.width_idx = w;
            svp_nnie_rpn_generate_each_anchor_box(param, &base_box, &ctrl, &dst);
        }
    }
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_ssd_generate_prior_box(sample_svp_nnie_ssd_generate_prior_box_param *param,
    hi_bool is_used_for_sw)
{
    hi_u32 i, j, aspect_ratio_num;
    hi_float aspect_ratio[SAMPLE_SVP_NNIE_SSD_MAX_ASPECT_RATIO_NUM];
    sample_svp_nnie_prior_box_ctrl_info ctrl;
    hi_s32 ret;

    ret = sample_svp_nnie_check_ssd_generate_prior_box_param(param, is_used_for_sw);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_ssd_generate_prior_box_param failed\n");

    ctrl.is_used_for_sw = is_used_for_sw;
    ctrl.offset = 0;
    ctrl.var_idx = 0;

    for (i = 0; i < SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM; i++) {
        aspect_ratio_num = 0;
        sample_svp_check_exps_return((param->flip_flag == HI_TRUE && param->input_aspect_ratio_num[i] >
            (SAMPLE_SVP_NNIE_SSD_MAX_ASPECT_RATIO_NUM - 1) / SAMPLE_SVP_NNIE_DOUBLE),
            HI_ERR_SVP_NNIE_ILLEGAL_PARAM,  SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,when flip_flag is true, input_aspect_ratio_num[%u](%u) can't be greater than %u!\n",
            i, param->input_aspect_ratio_num[i],
            (SAMPLE_SVP_NNIE_SSD_MAX_ASPECT_RATIO_NUM - 1) / SAMPLE_SVP_NNIE_DOUBLE);

        sample_svp_check_exps_return((param->flip_flag == HI_FALSE && param->input_aspect_ratio_num[i] >
            (SAMPLE_SVP_NNIE_SSD_MAX_ASPECT_RATIO_NUM - 1)),
            HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,when flip_flag is false, input_aspect_ratio_num[%u](%u) can't be greater than %u!\n",
            i, param->input_aspect_ratio_num[i], SAMPLE_SVP_NNIE_SSD_MAX_ASPECT_RATIO_NUM - 1);

        /* gen aspect ratio */
        aspect_ratio[0] = 1;
        aspect_ratio_num++;
        for (j = 0; j < param->input_aspect_ratio_num[i]; j++) {
            aspect_ratio[aspect_ratio_num++] = param->prior_box_aspect_ratio[i][j];
            if (param->flip_flag) {
                aspect_ratio[aspect_ratio_num++] = 1.0f / param->prior_box_aspect_ratio[i][j];
            }
        }

        /* gen prior box coordinate */
        ctrl.aspect_ratio = aspect_ratio;
        ctrl.aspect_ratio_num = aspect_ratio_num;
        ctrl.node_idx = i;
        (hi_void)svp_nnie_ssd_generate_prior_box(param, &ctrl);

        /* clip prior box coordinate */
        if (param->clip_flag == HI_TRUE) {
            (hi_void)svp_nnie_ssd_generate_prior_box_clip(param, &ctrl);
        }
    }
    return HI_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

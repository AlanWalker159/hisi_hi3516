/*
 * Copyright (c) Hisilicon Technologies Co., Ltd. 2020-2020. All rights reserved.
 * Description: sample_svp_nnie_check_software_param.c
 * Author: Hisilicon multimedia software (SVP) group
 * Create: 2020-03-10
 */

#include "../../../include/hisi/sample_svp_nnie_check_software_param.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */

#define SAMPLE_SVP_NNIE_MAX_IMG_WIDTH  4096
#define SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT 4096

static hi_s32 sample_svp_nnie_check_cnn_blob(sample_svp_nnie_param *nnie_param, sample_svp_nnie_cnn_sw_param *sw_param)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    /* check src blob */
    sample_svp_check_exps_return(nnie_param->seg_data[0].dst[0].type != HI_SVP_BLOB_TYPE_VEC_S20Q12,
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param->seg_data[0].dst[0].type(%d) must be %d!\n",
        nnie_param->seg_data[0].dst[0].type, HI_SVP_BLOB_TYPE_VEC_S20Q12);
    sample_svp_check_exps_return(nnie_param->seg_data[0].dst[0].num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,nnie_param->seg_data[0].dst[0].num(%u) is 0!\n", nnie_param->seg_data[0].dst[0].num);
    sample_svp_check_exps_return(((nnie_param->seg_data[0].dst[0].shape.whc.width == 0) ||
        (nnie_param->seg_data[0].dst[0].shape.whc.width < sw_param->top_n)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param->seg_data[0].dst[0].shape.whc.width(%u) is 0 or less than %u!\n",
        nnie_param->seg_data[0].dst[0].shape.whc.width, sw_param->top_n);
    sample_svp_check_exps_return(nnie_param->seg_data[0].dst[0].shape.whc.height != 1, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param->seg_data[0].dst[0].shape.whc.height(%u) should be 1!\n",
        nnie_param->seg_data[0].dst[0].shape.whc.height);
    sample_svp_check_exps_return(nnie_param->seg_data[0].dst[0].shape.whc.chn != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,nnie_param->seg_data[0].dst[0].shape.whc.chn(%u) should be 1!\n",
        nnie_param->seg_data[0].dst[0].shape.whc.chn);
    sample_svp_check_exps_return(nnie_param->seg_data[0].dst[0].stride <
        ((hi_u64)nnie_param->seg_data[0].dst[0].shape.whc.width * sizeof(hi_u32)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,nnie_param->seg_data[0].dst[0].stride(%u) is less than %llu!\n", nnie_param->seg_data[0].dst[0].stride,
        ((hi_u64)nnie_param->seg_data[0].dst[0].shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(nnie_param->seg_data[0].dst[0].stride) != 0,
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param->seg_data[0].dst[0].stride(%u) should be %u bytes align!\n",
        nnie_param->seg_data[0].dst[0].stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(nnie_param->seg_data[0].dst[0].virt_addr == 0,
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param->seg_data[0].dst[0].virt_addr is 0!\n");

    /* check dst blob */
    sample_svp_check_exps_return(sw_param->top_n_result.type != HI_SVP_BLOB_TYPE_U32, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->top_n_result.type(%d) must be %d!\n", sw_param->top_n_result.type, HI_SVP_BLOB_TYPE_U32);
    sample_svp_check_exps_return(sw_param->top_n_result.num != nnie_param->seg_data[0].dst[0].num,
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->top_n_result.num(%u) should be equal to %u!\n",
        sw_param->top_n_result.num, nnie_param->seg_data[0].dst[0].num);
    sample_svp_check_exps_return(sw_param->top_n_result.shape.whc.chn != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->top_n_result.shape.whc.chn(%u) must be 1!\n", sw_param->top_n_result.shape.whc.chn);
    sample_svp_check_exps_return(sw_param->top_n_result.shape.whc.height != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->top_n_result.shape.whc.height(%u) must be 1!\n", sw_param->top_n_result.shape.whc.height);
    sample_svp_check_exps_return(sw_param->top_n_result.shape.whc.width !=
        sw_param->top_n * sizeof(sample_svp_nnie_cnn_get_top_n_unit) / sizeof(hi_u32), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->top_n_result.shape.whc.width(%u) must be %u!\n", sw_param->top_n_result.shape.whc.width,
        (hi_u32)(sw_param->top_n * sizeof(sample_svp_nnie_cnn_get_top_n_unit) / sizeof(hi_u32)));
    sample_svp_check_exps_return(sw_param->top_n_result.stride < (sw_param->top_n_result.shape.whc.width *
        sizeof(hi_u32)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->top_n_result.stride(%u) is less than %u!\n",
        sw_param->top_n_result.stride, (hi_u32)(sw_param->top_n_result.shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(sw_param->top_n_result.stride) != 0, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->top_n_result.stride(%u) should be %u bytes align!\n",
        sw_param->top_n_result.stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(sw_param->top_n_result.virt_addr == 0,
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->top_n_result.virt_addr is 0!\n");
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_cnn_get_top_n_input_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_cnn_sw_param *sw_param)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u64 size;

    sample_svp_check_exps_return(sw_param->top_n == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->top_n(%u) is 0!\n", sw_param->top_n);
    ret = sample_svp_nnie_check_cnn_blob(nnie_param, sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_cnn_blob failed!\n");
    size = nnie_param->seg_data[0].dst[0].shape.whc.width * sizeof(sample_svp_nnie_cnn_get_top_n_unit);
    sample_svp_check_exps_return(sw_param->assist_buf.virt_addr == 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->assist_buf.virt_addr is 0!\n");
    sample_svp_check_exps_return(sw_param->assist_buf.size < size, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->assist_buf.size(%u) is less than %llu!\n",
        sw_param->assist_buf.size, size);
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_and_fill_cnn_get_top_n_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_cnn_sw_param *sw_param, sample_svp_nnie_cnn_get_top_n_param *param)
{
    hi_u32 ret;

    sample_svp_check_exps_return(((nnie_param == HI_NULL) || (sw_param == HI_NULL) || (param == HI_NULL)),
        HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param or sw_param or param is HI_NULL!\n");

    ret = sample_svp_nnie_check_cnn_get_top_n_input_param(nnie_param, sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_cnn_get_top_n_input_param failed!\n");

    param->fc = sample_svp_convert_addr_to_ptr(hi_s32, nnie_param->seg_data[0].dst[0].virt_addr);
    param->fc_stride = nnie_param->seg_data[0].dst[0].stride;
    param->class_num = nnie_param->seg_data[0].dst[0].shape.whc.width;
    param->batch_num = nnie_param->seg_data[0].dst[0].num;
    param->top_n = sw_param->top_n;
    param->tmp_buf = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->assist_buf.virt_addr);
    param->top_n_stride = sw_param->top_n_result.stride;
    param->get_top_n = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->top_n_result.virt_addr);

    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_rpn_tmp_buf_size_param(hi_u32 ratio_anchors_num, hi_u32 scale_anchors_num,
    hi_u32 conv_height, hi_u32 conv_width, hi_u32 *total_size)
{
    sample_svp_check_exps_return(((ratio_anchors_num == 0) || (ratio_anchors_num > SAMPLE_SVP_NNIE_RPN_MAX_RATIO_NUM)),
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,ratio_anchors_num(%u) should be (0, %u]!\n", ratio_anchors_num, SAMPLE_SVP_NNIE_RPN_MAX_RATIO_NUM);
    sample_svp_check_exps_return(((scale_anchors_num == 0) || (scale_anchors_num > SAMPLE_SVP_NNIE_RPN_MAX_SCALE_NUM)),
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,scale_anchors_num(%u) should be (0, %u]!\n", scale_anchors_num, SAMPLE_SVP_NNIE_RPN_MAX_SCALE_NUM);
    sample_svp_check_exps_return(conv_height == 0 || conv_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT,
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,conv_height(%u) should be (0, %u]!\n", conv_height, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(conv_width == 0 || conv_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH,
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,conv_width(%u) should be (0, %u]!\n", conv_width, SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(total_size == HI_NULL, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,total_size is HI_NULL!\n");
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_rpn_generate_anchor_box_param(sample_svp_nnie_rpn_generate_base_anchor_param *param,
    hi_bool is_used_for_sw)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u32 anchor_num;

    sample_svp_check_exps_return(((is_used_for_sw != HI_TRUE) && (is_used_for_sw != HI_FALSE)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,is_used_for_sw(%d) should be [%d, %d]!\n",
        is_used_for_sw, HI_FALSE, HI_TRUE);
    sample_svp_check_exps_return(param == HI_NULL, HI_ERR_SVP_NNIE_NULL_PTR,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,param is HI_NULL!\n");
    sample_svp_check_exps_return(((param->ratio_anchor_num == 0) ||
        (param->ratio_anchor_num > SAMPLE_SVP_NNIE_RPN_MAX_RATIO_NUM)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,ratio_anchor_num(%u) must be (0, %u]!\n", param->ratio_anchor_num, SAMPLE_SVP_NNIE_RPN_MAX_RATIO_NUM);
    sample_svp_check_exps_return(((param->scale_anchor_num == 0) ||
        (param->scale_anchor_num > SAMPLE_SVP_NNIE_RPN_MAX_SCALE_NUM)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,scale_anchor_num(%u) must be (0, %u]!\n", param->scale_anchor_num, SAMPLE_SVP_NNIE_RPN_MAX_SCALE_NUM);
    sample_svp_check_exps_return(((param->feature_map_height == 0) ||
        (param->feature_map_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,feature_map_height(%u) should be (0, %u]!\n", param->feature_map_height, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(((param->feature_map_width == 0) ||
        (param->feature_map_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,feature_map_width(%u) should be (0, %u]!\n", param->feature_map_width, SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(param->min_size > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,param->min_size(%u) must be [0, %u]!\n", param->min_size, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(((param->spatial_scale == 0) || (param->spatial_scale > SAMPLE_SVP_NNIE_QUANT_BASE)),
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,param->spatial_scale(%u) must be (0, %u]!\n", param->spatial_scale,
        SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(param->dst == HI_NULL, HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,param->dst is HI_NULL!\n");
    anchor_num = param->ratio_anchor_num * param->scale_anchor_num * param->feature_map_height *
        param->feature_map_width;
    if (is_used_for_sw == HI_FALSE) {
        sample_svp_check_exps_return(((param->stride == 0) ||
            (param->stride < sample_svp_nnie_align_16(anchor_num * sizeof(hi_s32)))), ret,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,param->stride(%u) is 0 or less than %u!\n", param->stride,
            (hi_u32)sample_svp_nnie_align_16(anchor_num * sizeof(hi_s32)));
        sample_svp_check_exps_return(sample_svp_nnie_check_align_16(param->stride) != 0, ret,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,param->stride(%u) should be %u bytes align!\n",
            param->stride, SAMPLE_SVP_NNIE_ALIGN_16);

        sample_svp_check_exps_return(param->dst_size < param->stride * SAMPLE_SVP_NNIE_COORD_NUM,
            ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,param->dst_size(%u) is less than %u!\n", param->dst_size,
            param->stride * SAMPLE_SVP_NNIE_COORD_NUM);
    } else {
        sample_svp_check_exps_return(param->dst_size < anchor_num * SAMPLE_SVP_NNIE_COORD_NUM * sizeof(hi_u32),
            ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,param->dst_size(%u) is less than %u!\n", param->dst_size,
            (hi_u32)(anchor_num * SAMPLE_SVP_NNIE_COORD_NUM * sizeof(hi_u32)));
    }

    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_sw_rpn_dst_blob(hi_svp_dst_blob *rpn_bbox, hi_u32 max_roi_num)
{
    sample_svp_check_exps_return(rpn_bbox->type != HI_SVP_BLOB_TYPE_BBOX_S20Q12, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->type(%d) must be %d!\n", rpn_bbox->type,
        HI_SVP_BLOB_TYPE_BBOX_S20Q12);
    sample_svp_check_exps_return(rpn_bbox->num == 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->num(%u) is 0!\n", rpn_bbox->num);
    sample_svp_check_exps_return(rpn_bbox->shape.whc.chn != 1, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->shape.whc.chn(%u) must be 1!\n", rpn_bbox->shape.whc.chn);
    sample_svp_check_exps_return(((rpn_bbox->shape.whc.height == 0) || (rpn_bbox->shape.whc.height > max_roi_num)),
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,rpn_bbox->shape.whc.height(%u) should be (0, %u]!\n", rpn_bbox->shape.whc.height, max_roi_num);
    sample_svp_check_exps_return(rpn_bbox->shape.whc.width != SAMPLE_SVP_NNIE_COORD_NUM,
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,rpn_bbox->shape.whc.width(%u) must be %u!\n", rpn_bbox->shape.whc.width, SAMPLE_SVP_NNIE_COORD_NUM);
    sample_svp_check_exps_return(rpn_bbox->stride < rpn_bbox->shape.whc.width * sizeof(hi_u32),
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->stride(%u) is less than %u!\n",
        rpn_bbox->stride, (hi_u32)(rpn_bbox->shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(rpn_bbox->stride) != 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->stride(%u) must be %u bytes align!\n",
        rpn_bbox->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(rpn_bbox->virt_addr == 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->virt_addr(%llu) is 0!\n", rpn_bbox->virt_addr);
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_hw_rpn_dst_blob(hi_svp_dst_blob *rpn_bbox, hi_u32 max_roi_num)
{
    sample_svp_check_exps_return(rpn_bbox->type != HI_SVP_BLOB_TYPE_BSI_SQ32, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->type(%d) must be %d!\n", rpn_bbox->type,
        HI_SVP_BLOB_TYPE_BSI_SQ32);
    sample_svp_check_exps_return(rpn_bbox->num == 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->num(%u) is 0!\n", rpn_bbox->num);
    sample_svp_check_exps_return(rpn_bbox->shape.whc.chn != 1, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->shape.whc.chn(%u) must be 1!\n", rpn_bbox->shape.whc.chn);
    sample_svp_check_exps_return(rpn_bbox->shape.whc.height != SAMPLE_SVP_NNIE_BSI_S20Q12_HEIGHT,
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,rpn_bbox->shape.whc.height(%u) must be %u!\n",
        rpn_bbox->shape.whc.height, SAMPLE_SVP_NNIE_BSI_S20Q12_HEIGHT);
    sample_svp_check_exps_return(rpn_bbox->shape.whc.width != max_roi_num,
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,rpn_bbox->shape.whc.width(%u) must be %u!\n", rpn_bbox->shape.whc.width, max_roi_num);
    sample_svp_check_exps_return(rpn_bbox->stride < (hi_u64)rpn_bbox->shape.whc.width * sizeof(hi_u32),
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->stride(%u) is less than %u!\n",
        rpn_bbox->stride, (hi_u32)(rpn_bbox->shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(rpn_bbox->stride) != 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->stride(%u) must be %u bytes align!\n",
        rpn_bbox->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(rpn_bbox->virt_addr == 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,rpn_bbox->virt_addr(%llu) is 0!\n", rpn_bbox->virt_addr);
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_rpn_dst_blob(hi_svp_dst_blob *rpn_bbox, hi_u32 max_roi_num, hi_bool is_rpn_sw)
{
    hi_s32 ret;

    if (is_rpn_sw == HI_TRUE) {
        ret = sample_svp_nnie_check_sw_rpn_dst_blob(rpn_bbox, max_roi_num);
        sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_svp_nnie_check_sw_rpn_dst_blob failed!\n");
    } else {
        ret = sample_svp_nnie_check_hw_rpn_dst_blob(rpn_bbox, max_roi_num);
        sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_svp_nnie_check_hw_rpn_dst_blob failed!\n");
    }
    return ret;
}

static hi_s32 sample_svp_nnie_check_rpn_src_blob(hi_svp_blob *score, hi_svp_blob *bbox, hi_u32 anchor_num,
    hi_u32 ori_img_height, hi_u32 ori_img_width)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    /* check score blob */
    sample_svp_check_exps_return(score->type != HI_SVP_BLOB_TYPE_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->type(%d) should be %u!\n", score->type, HI_SVP_BLOB_TYPE_S20Q12);
    sample_svp_check_exps_return(score->num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->num(%u) is 0!\n", score->num);
    sample_svp_check_exps_return(score->shape.whc.chn != anchor_num * SAMPLE_SVP_NNIE_DOUBLE, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,score->shape.whc.chn(%u) should be %u!\n",
        score->shape.whc.chn, anchor_num * SAMPLE_SVP_NNIE_DOUBLE);
    sample_svp_check_exps_return(((score->shape.whc.height == 0) ||
        (score->shape.whc.height > ori_img_height)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->shape.whc.height(%u) should be (0, %u]!\n", score->shape.whc.height, ori_img_height);
    sample_svp_check_exps_return(((score->shape.whc.width == 0) ||
        (score->shape.whc.width > ori_img_width)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->shape.whc.width(%u) should be (0, %u]!\n", score->shape.whc.width, ori_img_width);
    sample_svp_check_exps_return((score->stride < score->shape.whc.width * sizeof(hi_u32)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,score->stride(%u) is less than %u!\n",
        score->stride, (hi_u32)(score->shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(score->stride), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,score->stride(%u) should be %u bytes align!\n",
        score->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(score->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->virt_addr is 0!\n");

    /* check bbox blob */
    sample_svp_check_exps_return(bbox->type != HI_SVP_BLOB_TYPE_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->type(%d) should be %u!\n", bbox->type, HI_SVP_BLOB_TYPE_S20Q12);
    sample_svp_check_exps_return(bbox->num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->num(%u) is 0!\n", bbox->num);
    sample_svp_check_exps_return(bbox->shape.whc.chn != anchor_num * SAMPLE_SVP_NNIE_COORD_NUM, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,bbox->shape.whc.chn(%u) should be %u!\n",
        bbox->shape.whc.chn, anchor_num * SAMPLE_SVP_NNIE_DOUBLE);
    sample_svp_check_exps_return(((bbox->shape.whc.height == 0) ||
        (bbox->shape.whc.height > ori_img_height)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->shape.whc.height(%u) should be (0, %u]!\n", bbox->shape.whc.height, ori_img_height);
    sample_svp_check_exps_return(((bbox->shape.whc.width == 0) ||
        (bbox->shape.whc.width > ori_img_width)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->shape.whc.width(%u) should be (0, %u]!\n", bbox->shape.whc.width, ori_img_width);
    sample_svp_check_exps_return((bbox->stride < bbox->shape.whc.width * sizeof(hi_u32)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,bbox->stride(%u) is less than %u!\n",
        bbox->stride, (hi_u32)(bbox->shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(bbox->stride), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,bbox->stride(%u) should be %u bytes align!\n",
        bbox->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(bbox->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->virt_addr is 0!\n");
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_rpn_tmp_buf(hi_svp_blob *score, hi_svp_blob *bbox,
    hi_u32 anchor_num, hi_svp_mem_info *anchor_mem, hi_svp_mem_info *tmp_mem)
{
    hi_u64 size;
    hi_u32 bbox_delta_size, proposal_size, score_size, stack_size, total_anchor_num;

    sample_svp_check_exps_return(score->shape.whc.height != bbox->shape.whc.height,
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->shape.whc.height(%u) should be equal to bbox->shape.whc.height(%u)!\n",
        score->shape.whc.height, bbox->shape.whc.height);
    sample_svp_check_exps_return(score->shape.whc.width != bbox->shape.whc.width,
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->shape.whc.width(%u) should be equal to bbox->shape.whc.width(%u)!\n",
        score->shape.whc.width, bbox->shape.whc.width);

    /* check base anchor mem size */
    sample_svp_check_exps_return(anchor_mem->virt_addr == 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,anchor_mem->virt_addr is 0!\n");
    total_anchor_num = score->shape.whc.width * score->shape.whc.height * anchor_num;
    size = total_anchor_num * SAMPLE_SVP_NNIE_COORD_NUM * sizeof(hi_u32);
    sample_svp_check_exps_return(anchor_mem->size < size, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,anchor_size(%u) is less than %llu!\n", anchor_mem->size, size);

    sample_svp_check_exps_return(tmp_mem->virt_addr == 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,tmp_mem->virt_addr is 0!\n");
    bbox_delta_size = sizeof(hi_u32) * SAMPLE_SVP_NNIE_COORD_NUM * total_anchor_num;
    proposal_size = sizeof(hi_u32) * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * total_anchor_num;
    score_size = sizeof(hi_float) * total_anchor_num * SAMPLE_SVP_NNIE_DOUBLE;
    stack_size = sizeof(sample_svp_nnie_stack) * total_anchor_num;
    size = bbox_delta_size + proposal_size + score_size + stack_size;
    sample_svp_check_exps_return(tmp_mem->size < size, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,tmp_mem->size(%u) is less than %llu!\n", tmp_mem->size, size);
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_rpn_param(sample_svp_nnie_two_seg_net_sw_param *sw_param)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    sample_svp_check_exps_return(sw_param->conv_num != SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->conv_num(%u) must be %u!\n", sw_param->conv_num,
        SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM);

    sample_svp_check_exps_return(((sw_param->ratio_anchor_num == 0) ||
        (sw_param->ratio_anchor_num > SAMPLE_SVP_NNIE_RPN_MAX_RATIO_NUM)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,ratio_anchor_num(%u) should be (0, %u]!\n",
        sw_param->ratio_anchor_num, SAMPLE_SVP_NNIE_RPN_MAX_RATIO_NUM);
    sample_svp_check_exps_return(((sw_param->scale_anchor_num == 0) ||
        (sw_param->scale_anchor_num > SAMPLE_SVP_NNIE_RPN_MAX_SCALE_NUM)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,scale_anchor_num(%u) should be (0, %u]!\n",
        sw_param->scale_anchor_num, SAMPLE_SVP_NNIE_RPN_MAX_SCALE_NUM);
    sample_svp_check_exps_return(((sw_param->ori_img_height == 0) ||
        (sw_param->ori_img_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->ori_img_height(%u) should be (0, %u]!\n",
        sw_param->ori_img_height, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(((sw_param->ori_img_width == 0) ||
        (sw_param->ori_img_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->ori_img_width(%u) should be (0, %u]!\n",
        sw_param->ori_img_width, SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(sw_param->max_roi_num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->max_rois(%u) can't be 0!\n", sw_param->max_roi_num);
    sample_svp_check_exps_return(((sw_param->min_size == 0) || (sw_param->min_size > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)),
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->max_rois(%u) should be (0, %u]!\n",
        sw_param->min_size, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(((sw_param->spatial_scale == 0) ||
        (sw_param->spatial_scale > SAMPLE_SVP_NNIE_QUANT_BASE)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->spatial_scale(%u) must be (0, %u]!\n", sw_param->spatial_scale, SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(sw_param->nms_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->nms_threshold(%u) must be [0, %u]!\n", sw_param->nms_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(sw_param->filter_threshold > SAMPLE_SVP_NNIE_QUANT_BASE,
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->filter_threshold(%u) must be [0, %u]!\n",
        sw_param->filter_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(sw_param->num_before_nms == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->num_before_nms(%u) is 0!\n", sw_param->num_before_nms);

    ret = sample_svp_nnie_check_rpn_src_blob(&sw_param->conv[0], &sw_param->conv[1],
        sw_param->ratio_anchor_num * sw_param->scale_anchor_num, sw_param->ori_img_height, sw_param->ori_img_width);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_rpn_src_blob failed!\n");
    ret = sample_svp_nnie_check_rpn_tmp_buf(&sw_param->conv[0], &sw_param->conv[1],
        sw_param->ratio_anchor_num * sw_param->scale_anchor_num, &sw_param->rpn_base_anchor, &sw_param->rpn_tmp_buf);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_rpn_tmp_buf failed!\n");
    ret = sample_svp_nnie_check_sw_rpn_dst_blob(&sw_param->rpn_bbox, sw_param->max_roi_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sample_svp_nnie_check_sw_rpn_dst_blob failed!\n");
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_and_fill_faster_rcnn_rpn_param(sample_svp_nnie_faster_rcnn_sw_param *sw_param,
    sample_svp_nnie_rpn_param *param)
{
    hi_s32 ret;
    hi_u32 i;

    sample_svp_check_exps_return(((sw_param == HI_NULL) || (param == HI_NULL)), HI_ERR_SVP_NNIE_NULL_PTR,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param or param is HI_NULL!\n");

    ret = sample_svp_nnie_check_rpn_param(sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sample_svp_nnie_check_rpn_param failed!\n");

    param->conv_num = sw_param->conv_num;
    for (i = 0; i < param->conv_num; i++) {
        param->src[i] = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->conv[i].virt_addr);
        param->conv_height[i] = sw_param->conv[i].shape.whc.height;
        param->conv_width[i] = sw_param->conv[i].shape.whc.width;
        param->conv_channel[i] = sw_param->conv[i].shape.whc.chn;
        param->conv_stride[i] = sw_param->conv[i].stride;
    }

    param->ratio_anchor_num = sw_param->ratio_anchor_num;
    param->scale_anchor_num = sw_param->scale_anchor_num;
    param->ori_img_height = sw_param->ori_img_height;
    param->ori_img_width = sw_param->ori_img_width;
    param->max_rois = sw_param->max_roi_num;
    param->min_size = sw_param->min_size;
    param->spatial_scale = sw_param->spatial_scale;
    param->nms_threshold = sw_param->nms_threshold;
    param->filter_threshold = sw_param->filter_threshold;
    param->num_before_nms = sw_param->num_before_nms;
    param->base_anchor = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->rpn_base_anchor.virt_addr);
    param->mem_pool = sample_svp_convert_addr_to_ptr(hi_u32, sw_param->rpn_tmp_buf.virt_addr);
    param->dst_stride = sw_param->rpn_bbox.stride;
    param->proposal_result = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->rpn_bbox.virt_addr);
    param->num_rois = &(sw_param->rpn_bbox.shape.whc.height);

    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_faster_rcnn_get_result_src_blob(hi_svp_src_blob *bbox, hi_svp_src_blob *score,
    hi_u32 max_roi_num, hi_u32 class_num)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    sample_svp_check_exps_return(bbox->num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->num(%u) is 0!\n", bbox->num);
    sample_svp_check_exps_return(bbox->type != HI_SVP_BLOB_TYPE_VEC_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->type(%d) should be %d!\n", bbox->type, HI_SVP_BLOB_TYPE_VEC_S20Q12);
    sample_svp_check_exps_return(bbox->shape.whc.chn != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->shape.whc.chn(%u) should be 1!\n", bbox->shape.whc.chn);
    sample_svp_check_exps_return(bbox->shape.whc.height != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->shape.whc.height(%u) should be 1!\n", bbox->shape.whc.height);
    sample_svp_check_exps_return((bbox->shape.whc.width != class_num * SAMPLE_SVP_NNIE_COORD_NUM), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,bbox->shape.whc.width(%u) should be %u!\n", bbox->shape.whc.width,
        class_num * SAMPLE_SVP_NNIE_COORD_NUM);

    sample_svp_check_exps_return(bbox->num < max_roi_num, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->num(%u) is less than %u!\n", bbox->num, max_roi_num);
    sample_svp_check_exps_return((bbox->stride < bbox->shape.whc.width * sizeof(hi_u32)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,bbox->stride(%u) is less than %u!\n",
        bbox->stride, (hi_u32)(bbox->shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(bbox->stride) != 0, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,bbox->stride(%u) is not %u bytes align!\n",
        bbox->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(bbox->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->virt_addr is 0!\n");

    sample_svp_check_exps_return(score->num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->num(%u) is 0!\n", score->num);
    sample_svp_check_exps_return(score->type != HI_SVP_BLOB_TYPE_VEC_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->type(%d) should be %d!\n", score->type, HI_SVP_BLOB_TYPE_VEC_S20Q12);
    sample_svp_check_exps_return(score->shape.whc.chn != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->shape.whc.chn(%u) should be 1!\n", score->shape.whc.chn);
    sample_svp_check_exps_return(score->shape.whc.height != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->shape.whc.height(%u) should be 1!\n", score->shape.whc.height);
    sample_svp_check_exps_return((score->shape.whc.width != class_num), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->shape.whc.width(%u) should be %u!\n", score->shape.whc.width, class_num);
    sample_svp_check_exps_return(score->num < max_roi_num, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->num(%u) is less than %u!\n", score->num, max_roi_num);
    sample_svp_check_exps_return((score->stride < score->shape.whc.width * sizeof(hi_u32)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,score->stride(%u) is less than %u!\n",
        score->stride, (hi_u32)(score->shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(score->stride) != 0, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,score->stride(%u) is not %u bytes align!\n",
        score->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(score->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->virt_addr is 0!\n");
        return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_each_get_result_dst_blob(hi_svp_dst_blob *blob, hi_u32 dst_width)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    sample_svp_check_exps_return(blob->num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->num(%d) is 0!\n", blob->num);
    sample_svp_check_exps_return(blob->shape.whc.chn != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.chn(%u) should be 1!\n", blob->shape.whc.chn);
    sample_svp_check_exps_return(blob->shape.whc.height != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.height(%u) should be 1!\n", blob->shape.whc.height);
    sample_svp_check_exps_return((blob->shape.whc.width < dst_width), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.width(%u) is less than %u!\n", blob->shape.whc.width, dst_width);
    sample_svp_check_exps_return((blob->stride < blob->shape.whc.width * sizeof(hi_u32)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,blob->stride(%u) is less than %u!\n",
        blob->stride, (hi_u32)(blob->shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(blob->stride) != 0, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,blob->stride(%u) is not %u bytes align!\n",
        blob->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(blob->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->virt_addr is 0!\n");

    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_get_result_dst_blob(hi_svp_src_blob *bbox, hi_svp_src_blob *score,
    hi_svp_src_blob *class_roi_num, hi_u32 max_roi_num, hi_u32 class_num)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    sample_svp_check_exps_return(bbox->type != HI_SVP_BLOB_TYPE_S32, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->type(%d) should be %d!\n", bbox->type, HI_SVP_BLOB_TYPE_S32);
    ret = sample_svp_nnie_check_each_get_result_dst_blob(bbox, class_num * max_roi_num * SAMPLE_SVP_NNIE_COORD_NUM);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_each_get_result_dst_blob failed!\n");
    sample_svp_check_exps_return(score->type != HI_SVP_BLOB_TYPE_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->type(%d) should be %d!\n", score->type, HI_SVP_BLOB_TYPE_S20Q12);
    ret = sample_svp_nnie_check_each_get_result_dst_blob(score, class_num * max_roi_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_each_get_result_dst_blob failed!\n");
    sample_svp_check_exps_return(class_roi_num->type != HI_SVP_BLOB_TYPE_U32, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,class_roi_num->type(%d) should be %d!\n", class_roi_num->type, HI_SVP_BLOB_TYPE_U32);
    ret = sample_svp_nnie_check_each_get_result_dst_blob(class_roi_num, class_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_each_get_result_dst_blob failed!\n");

    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_faster_rcnn_get_result_input_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_faster_rcnn_sw_param *sw_param)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u32 i, score_size, proposal_size, stack_size;
    hi_u64 size;

    /* check param */
    sample_svp_check_exps_return(sw_param->conv_num != SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->conv_num(%u) must be %u!\n", sw_param->conv_num,
        SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM);
    sample_svp_check_exps_return(sw_param->max_roi_num == 0, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->max_roi_num(%u) is 0!\n", sw_param->max_roi_num);
    sample_svp_check_exps_return(sw_param->nms_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->nms_threshold(%u) must be [0, %u]!\n",
        sw_param->nms_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(((sw_param->class_num == 0) || (sw_param->class_num > SAMPLE_SVP_NNIE_MAX_CLASS_NUM)),
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->class_num(%u) should be (0, %u]!\n",
        sw_param->class_num, SAMPLE_SVP_NNIE_MAX_CLASS_NUM);
    for (i = 0; i < sw_param->class_num; i++) {
        sample_svp_check_exps_return(sw_param->conf_threshold[i] > SAMPLE_SVP_NNIE_QUANT_BASE, ret,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->conf_threshold[%u](%u) must be [0, %u]!\n",
            i, sw_param->conf_threshold[i], SAMPLE_SVP_NNIE_QUANT_BASE);
    }
    sample_svp_check_exps_return(((sw_param->ori_img_width == 0) ||
        (sw_param->ori_img_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->ori_img_width(%u) should be (0, %u]!\n", sw_param->ori_img_width,
        SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(((sw_param->ori_img_height == 0) ||
        (sw_param->ori_img_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->ori_img_height(%u) should be (0, %u]!\n", sw_param->ori_img_height,
        SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);

    /* check blob */
    ret = sample_svp_nnie_check_faster_rcnn_get_result_src_blob(&nnie_param->seg_data[1].dst[0],
        &nnie_param->seg_data[1].dst[1], sw_param->max_roi_num, sw_param->class_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_faster_rcnn_get_result_src_blob failed!\n");

    ret = sample_svp_nnie_check_get_result_dst_blob(&sw_param->dst_roi, &sw_param->dst_score, &sw_param->class_roi_num,
        sw_param->max_roi_num, sw_param->class_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_get_result_dst_blob failed!\n");

    /* check asist buf */
    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->get_result_tmp_buf.virt_addr is 0!\n");
    score_size = sizeof(hi_float) * sw_param->max_roi_num * sw_param->class_num;
    proposal_size = sizeof(hi_u32) * sw_param->max_roi_num * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH;
    stack_size = sizeof(sample_svp_nnie_stack) * sw_param->max_roi_num;
    size = score_size + proposal_size + stack_size;
    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.size < size, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->get_result_tmp_buf.size(%u) is less than %llu!\n", sw_param->get_result_tmp_buf.size, size);

    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_and_fill_faster_rcnn_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_faster_rcnn_sw_param *sw_param, sample_svp_nnie_faster_rcnn_get_result_param *param)
{
    hi_s32 ret;
    hi_s32 *bbox = HI_NULL;

    sample_svp_check_exps_return(((nnie_param == HI_NULL) || (sw_param == HI_NULL) || (param == HI_NULL)),
        HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param or sw_param or param is HI_NULL!\n");

    /* check input param */
    ret = sample_svp_nnie_check_faster_rcnn_get_result_input_param(nnie_param, sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_faster_rcnn_get_result_input_param failed!\n");
    param->is_rpn_sw = (sw_param->rpn_bbox.type == HI_SVP_BLOB_TYPE_BBOX_S20Q12) ? HI_TRUE : HI_FALSE;
    ret = sample_svp_nnie_check_rpn_dst_blob(&sw_param->rpn_bbox, sw_param->max_roi_num, param->is_rpn_sw);
    sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_rpn_dst_blob failed!\n");

    /* fill param */
    bbox = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->rpn_bbox.virt_addr);
    if (param->is_rpn_sw == HI_TRUE) {
        param->roi_num = sw_param->rpn_bbox.shape.whc.height;
        param->bbox = bbox;
    } else {
        param->roi_num = *bbox;
        param->bbox = bbox + sample_svp_nnie_align_32(sw_param->rpn_bbox.shape.whc.chn * sizeof(hi_s32)) /
            sizeof(hi_s32);
    }
    sample_svp_check_exps_return(((param->roi_num == 0) || (param->roi_num > sw_param->max_roi_num)),
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,param->roi_num(%u) should be (0, %u]!\n", param->roi_num, sw_param->max_roi_num);
    param->bbox_stride = sw_param->rpn_bbox.stride;
    param->bbox_delta = sample_svp_convert_addr_to_ptr(hi_s32, nnie_param->seg_data[1].dst[0].virt_addr);
    param->bbox_delta_stride = nnie_param->seg_data[1].dst[0].stride;
    param->score = sample_svp_convert_addr_to_ptr(hi_s32, nnie_param->seg_data[1].dst[1].virt_addr);
    param->score_stride = nnie_param->seg_data[1].dst[1].stride;
    param->conf_threshold = sw_param->conf_threshold;
    param->nms_threshold = sw_param->valid_nms_threshold;
    param->max_roi = sw_param->max_roi_num;
    param->class_num = sw_param->class_num;
    param->ori_img_width = sw_param->ori_img_width;
    param->ori_img_height = sw_param->ori_img_height;
    param->mem_pool = sample_svp_convert_addr_to_ptr(hi_u32, sw_param->get_result_tmp_buf.virt_addr);
    param->dst_score = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_score.virt_addr);
    param->dst_bbox = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_roi.virt_addr);
    param->class_roi_num = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->class_roi_num.virt_addr);

    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_and_fill_rfcn_rpn_param(sample_svp_nnie_rfcn_sw_param *sw_param,
    sample_svp_nnie_rpn_param *param)
{
    hi_s32 ret;
    hi_u32 i;

    sample_svp_check_exps_return(((sw_param == HI_NULL) || (param == HI_NULL)), HI_ERR_SVP_NNIE_NULL_PTR,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param or param is HI_NULL!\n");
    ret = sample_svp_nnie_check_rpn_param(sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sample_svp_nnie_check_rpn_param failed!\n");

    param->conv_num = sw_param->conv_num;
    for (i = 0; i < param->conv_num; i++) {
        sample_svp_check_exps_return(sw_param->conv[i].type != HI_SVP_BLOB_TYPE_S20Q12, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->conv[%u].type(%d) should be %d!\n",
            i, sw_param->conv[i].type, HI_SVP_BLOB_TYPE_S20Q12);
        param->src[i] = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->conv[i].virt_addr);
        param->conv_height[i] = sw_param->conv[i].shape.whc.height;
        param->conv_width[i] = sw_param->conv[i].shape.whc.width;
        param->conv_channel[i] = sw_param->conv[i].shape.whc.chn;
        param->conv_stride[i] = sw_param->conv[i].stride;
    }

    param->ratio_anchor_num = sw_param->ratio_anchor_num;
    param->scale_anchor_num = sw_param->scale_anchor_num;
    param->ori_img_height = sw_param->ori_img_height;
    param->ori_img_width = sw_param->ori_img_width;
    param->max_rois = sw_param->max_roi_num;
    param->min_size = sw_param->min_size;
    param->spatial_scale = sw_param->spatial_scale;
    param->nms_threshold = sw_param->nms_threshold;
    param->filter_threshold = sw_param->filter_threshold;
    param->num_before_nms = sw_param->num_before_nms;
    param->base_anchor = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->rpn_base_anchor.virt_addr);
    param->mem_pool = sample_svp_convert_addr_to_ptr(hi_u32, sw_param->rpn_tmp_buf.virt_addr);
    param->dst_stride = sw_param->rpn_bbox.stride;
    param->proposal_result = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->rpn_bbox.virt_addr);
    param->num_rois = &(sw_param->rpn_bbox.shape.whc.height);

    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_rfcn_get_result_src_blob(hi_svp_src_blob *bbox, hi_svp_src_blob *score,
    hi_u32 max_roi_num, hi_u32 class_num)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    sample_svp_check_exps_return(bbox->type != HI_SVP_BLOB_TYPE_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->type(%d) should be %d!\n", bbox->type, HI_SVP_BLOB_TYPE_S20Q12);
    sample_svp_check_exps_return(bbox->shape.whc.chn != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->shape.whc.chn(%u) should be 1!\n", bbox->shape.whc.chn);
    sample_svp_check_exps_return(bbox->shape.whc.height != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->shape.whc.height(%u) should be 1!\n", bbox->shape.whc.height);
    sample_svp_check_exps_return((bbox->shape.whc.width != SAMPLE_SVP_NNIE_DOUBLE * SAMPLE_SVP_NNIE_COORD_NUM), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,bbox->shape.whc.width(%u) should be %u!\n", bbox->shape.whc.width,
        SAMPLE_SVP_NNIE_DOUBLE * SAMPLE_SVP_NNIE_COORD_NUM);
    sample_svp_check_exps_return(bbox->num < max_roi_num, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->num(%u) is less than %u!\n", bbox->num, max_roi_num);
    sample_svp_check_exps_return((bbox->stride < bbox->shape.whc.width * sizeof(hi_u32)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,bbox->stride(%u) is less than %u!\n",
        bbox->stride, (hi_u32)(bbox->shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(bbox->stride) != 0, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,bbox->stride(%u) is not %u bytes align!\n",
        bbox->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(bbox->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,bbox->virt_addr is 0!\n");

    sample_svp_check_exps_return(score->type != HI_SVP_BLOB_TYPE_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->type(%d) should be %d!\n", score->type, HI_SVP_BLOB_TYPE_S20Q12);
    sample_svp_check_exps_return(score->shape.whc.chn != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->shape.whc.chn(%u) should be 1!\n", score->shape.whc.chn);
    sample_svp_check_exps_return(score->shape.whc.height != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->shape.whc.height(%u) should be 1!\n", score->shape.whc.height);
    sample_svp_check_exps_return(score->shape.whc.width != class_num, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->shape.whc.width(%u) should be %u!\n", score->shape.whc.width, class_num);
    sample_svp_check_exps_return(score->num < max_roi_num, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->num(%u) is less than %u!\n", score->num, max_roi_num);
    sample_svp_check_exps_return((score->stride < score->shape.whc.width * sizeof(hi_u32)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,score->stride(%u) is less than %u!\n",
        score->stride, (hi_u32)(score->shape.whc.width * sizeof(hi_u32)));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(score->stride) != 0, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,score->stride(%u) is not %u bytes align!\n",
        score->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(score->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,score->virt_addr is 0!\n");
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_rfcn_get_result_input_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_rfcn_sw_param *sw_param)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u32 i, score_size, proposal_size, stack_size;
    hi_u64 size;

    /* check param */
    sample_svp_check_exps_return(sw_param->conv_num != SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->conv_num(%u) must be %u!\n", sw_param->conv_num,
        SAMPLE_SVP_NNIE_RPN_INPUT_BLOB_NUM);
    sample_svp_check_exps_return(sw_param->max_roi_num == 0, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->max_roi_num(%u) is 0!\n", sw_param->max_roi_num);
    sample_svp_check_exps_return(sw_param->nms_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->nms_threshold(%u) must be [0, %u]!\n",
        sw_param->nms_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(((sw_param->class_num == 0) || (sw_param->class_num > SAMPLE_SVP_NNIE_MAX_CLASS_NUM)),
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->class_num(%u) should be (0, %u]!\n",
        sw_param->class_num, SAMPLE_SVP_NNIE_MAX_CLASS_NUM);
    for (i = 0; i < sw_param->class_num; i++) {
        sample_svp_check_exps_return(sw_param->conf_threshold[i] > SAMPLE_SVP_NNIE_QUANT_BASE, ret,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->conf_threshold[%u](%u) must be [0, %u]!\n",
            i, sw_param->conf_threshold[i], SAMPLE_SVP_NNIE_QUANT_BASE);
    }
    sample_svp_check_exps_return(((sw_param->ori_img_width == 0) ||
        (sw_param->ori_img_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->ori_img_width(%u) should be (0, %u]!\n", sw_param->ori_img_width,
        SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(((sw_param->ori_img_height == 0) ||
        (sw_param->ori_img_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->ori_img_height(%u) should be (0, %u]!\n", sw_param->ori_img_height,
        SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);

    /* check blob */
    ret = sample_svp_nnie_check_rfcn_get_result_src_blob(
        &nnie_param->seg_data[SAMPLE_SVP_NNIE_RFCN_DELTA_BLOB_OFFSET].dst[0],
        &nnie_param->seg_data[SAMPLE_SVP_NNIE_RFCN_SCORE_BLOB_OFFSET].dst[0],
        sw_param->max_roi_num, sw_param->class_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_rfcn_get_result_src_blob failed!\n");

    ret = sample_svp_nnie_check_get_result_dst_blob(&sw_param->dst_roi, &sw_param->dst_score, &sw_param->class_roi_num,
        sw_param->max_roi_num, sw_param->class_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_get_result_dst_blob failed!\n");

    /* check assist buf */
    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->get_result_tmp_buf.virt_addr is 0!\n");
    score_size = sizeof(hi_float) * sw_param->max_roi_num * sw_param->class_num;
    proposal_size = sizeof(hi_u32) * sw_param->max_roi_num * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH;
    stack_size = sizeof(sample_svp_nnie_stack) * sw_param->max_roi_num;
    size = score_size + proposal_size + stack_size;
    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.size < size, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->get_result_tmp_buf.size(%u) is less than %llu!\n", sw_param->get_result_tmp_buf.size, size);
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_and_fill_rfcn_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_rfcn_sw_param *sw_param, sample_svp_nnie_rfcn_get_result_param *param)
{
    hi_s32 ret;
    hi_s32 *bbox = HI_NULL;

    sample_svp_check_exps_return(((nnie_param == HI_NULL) || (sw_param == HI_NULL) || (param == HI_NULL)),
        HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param or sw_param or param is HI_NULL!\n");

    /* check input param */
    ret = sample_svp_nnie_check_rfcn_get_result_input_param(nnie_param, sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_rfcn_get_result_input_param failed!\n");

    param->is_rpn_sw = (sw_param->rpn_bbox.type == HI_SVP_BLOB_TYPE_BBOX_S20Q12) ? HI_TRUE : HI_FALSE;
    ret = sample_svp_nnie_check_rpn_dst_blob(&sw_param->rpn_bbox, sw_param->max_roi_num, param->is_rpn_sw);
    sample_svp_check_exps_return(ret != HI_SUCCESS, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_rpn_dst_blob failed!\n");

    /* fill param */
    bbox = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->rpn_bbox.virt_addr);
    if (param->is_rpn_sw == HI_TRUE) {
        param->roi_num = sw_param->rpn_bbox.shape.whc.height;
        param->bbox = bbox;
    } else {
        param->roi_num = *bbox;
        param->bbox = bbox + sample_svp_nnie_align_32(sw_param->rpn_bbox.shape.whc.chn * sizeof(hi_s32)) /
            sizeof(hi_s32);
    }
    sample_svp_check_exps_return(((param->roi_num == 0) || (param->roi_num > sw_param->max_roi_num)),
        HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,param->roi_num(%u) should be (0, %u]!\n", param->roi_num, sw_param->max_roi_num);

    param->score = sample_svp_convert_addr_to_ptr(hi_s32,
        nnie_param->seg_data[SAMPLE_SVP_NNIE_RFCN_SCORE_BLOB_OFFSET].dst[0].virt_addr);
    param->score_stride = nnie_param->seg_data[SAMPLE_SVP_NNIE_RFCN_SCORE_BLOB_OFFSET].dst[0].stride;
    param->bbox_delta = sample_svp_convert_addr_to_ptr(hi_s32,
        nnie_param->seg_data[SAMPLE_SVP_NNIE_RFCN_DELTA_BLOB_OFFSET].dst[0].virt_addr);
    param->bbox_delta_stride = nnie_param->seg_data[SAMPLE_SVP_NNIE_RFCN_DELTA_BLOB_OFFSET].dst[0].stride;
    param->bbox_stride = sw_param->rpn_bbox.stride;
    param->conf_threshold = sw_param->conf_threshold;
    param->nms_threshold = sw_param->valid_nms_threshold;
    param->max_roi = sw_param->max_roi_num;
    param->class_num = sw_param->class_num;
    param->ori_img_width = sw_param->ori_img_width;
    param->ori_img_height = sw_param->ori_img_height;
    param->mem_pool = sample_svp_convert_addr_to_ptr(hi_u32, sw_param->get_result_tmp_buf.virt_addr);
    param->dst_score = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_score.virt_addr);
    param->dst_bbox = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_roi.virt_addr);
    param->class_roi_num = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->class_roi_num.virt_addr);

    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_ssd_generate_prior_box_dst_mem(sample_svp_nnie_ssd_generate_prior_box_param *param,
    hi_bool is_used_for_sw)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u32 i;
    hi_u64 size, prior_box_num;
    for (i = 0; i < SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM; i++) {
        sample_svp_check_exps_return(((param->prior_box_height[i] == 0) ||
            (param->prior_box_height[i] > param->ori_img_height)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error, param->prior_box_height[%u](%u) should be (0, %u]!\n",
            i, param->prior_box_height[i], param->ori_img_height);
        sample_svp_check_exps_return(((param->prior_box_width[i] == 0) ||
            (param->prior_box_width[i] > param->ori_img_width)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error, param->prior_box_width[%u](%u) should be (0, %u]!\n",
            i, param->prior_box_width[i], param->ori_img_width);
        sample_svp_check_exps_return(param->input_aspect_ratio_num[i] > SAMPLE_SVP_NNIE_SSD_MAX_ASPECT_RATIO_NUM,
            ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error, param->input_aspect_ratio_num[%u](%u) is greater than %u!\n",
            i, param->input_aspect_ratio_num[i], SAMPLE_SVP_NNIE_SSD_MAX_ASPECT_RATIO_NUM);
    }
    if (is_used_for_sw == HI_TRUE) {
        for (i = 0; i < SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM; i++) {
            sample_svp_check_exps_return(param->prior_box[i] == HI_NULL, HI_ERR_SVP_NNIE_NULL_PTR,
                SAMPLE_SVP_ERR_LEVEL_ERROR, "Error, param->prior_box[%u] is HI_NULL!\n", i);
            prior_box_num = (hi_u64)param->prior_box_height[i] * param->prior_box_width[i] *
                (param->max_size_num + param->min_size_num + param->min_size_num *
                param->input_aspect_ratio_num[i] * (param->flip_flag == HI_TRUE ? SAMPLE_SVP_NNIE_DOUBLE : 1));
            size = prior_box_num * SAMPLE_SVP_NNIE_COORD_NUM * sizeof(hi_u32) +
                prior_box_num * SAMPLE_SVP_NNIE_COORD_NUM * sizeof(hi_u32);
            sample_svp_check_exps_return(param->prior_box_size[i] < size, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
                "Error, param->prior_box_size[%u](%u) is less than %llu!\n", i, param->prior_box_size[i], size);
        }
    } else {
        prior_box_num = 0;
        sample_svp_check_exps_return(param->dst == HI_NULL, HI_ERR_SVP_NNIE_NULL_PTR,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error, param->dst is HI_NULL!\n");
        for (i = 0; i < SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM; i++) {
            prior_box_num += (hi_u64)param->prior_box_height[i] * param->prior_box_width[i] *
                (param->max_size_num + param->min_size_num + param->min_size_num *
                param->input_aspect_ratio_num[i] * (param->flip_flag == HI_TRUE ? SAMPLE_SVP_NNIE_DOUBLE : 1));
        }
        size = SAMPLE_SVP_NNIE_COORD_NUM * sample_svp_nnie_align_16(prior_box_num * sizeof(hi_s32)) *
            SAMPLE_SVP_NNIE_DOUBLE;
        sample_svp_check_exps_return(param->dst_size < size, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error, param->dst_size(%u) is less than %llu!\n", param->dst_size, size);
    }
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_ssd_generate_prior_box_param(sample_svp_nnie_ssd_generate_prior_box_param *param,
    hi_bool is_used_for_sw)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    sample_svp_check_exps_return(((is_used_for_sw != HI_TRUE) && (is_used_for_sw != HI_FALSE)),
        HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error, is_used_for_sw(%d) must be [%d, %d]!\n", is_used_for_sw, HI_FALSE, HI_TRUE);

    sample_svp_check_exps_return(param == HI_NULL, HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error, param is HI_NULL!\n");
    sample_svp_check_exps_return(param->min_size_num != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error, param->min_size_num(%u) must be 1!\n", param->min_size_num);
    sample_svp_check_exps_return(param->max_size_num != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error, param->max_size_num(%u) must be 1!\n", param->max_size_num);
    sample_svp_check_exps_return(((param->ori_img_height == 0) ||
        (param->ori_img_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error, param->ori_img_height(%u) should be (0, %u]!\n", param->ori_img_height, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(((param->ori_img_width == 0) ||
        (param->ori_img_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error, param->ori_img_width(%u) should be (0, %u]!\n", param->ori_img_width, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(param->flip_flag != HI_TRUE && param->flip_flag != HI_FALSE, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error, param->flip_flag(%d) must be [%d, %d]!\n",
        param->flip_flag, HI_FALSE, HI_TRUE);
    sample_svp_check_exps_return(param->clip_flag != HI_TRUE && param->clip_flag != HI_FALSE, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error, param->clip_flag(%d) must be [%d, %d]!\n",
        param->clip_flag, HI_FALSE, HI_TRUE);
    ret = sample_svp_nnie_check_ssd_generate_prior_box_dst_mem(param, is_used_for_sw);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error, sample_svp_nnie_check_ssd_generate_prior_box_dst_mem failed!\n");
    return HI_SUCCESS;
}
static hi_s32 sample_svp_nnie_check_ssd_param_each_src_blob(hi_svp_blob *blob, hi_u32 width, hi_bool is_loc_blob)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    /* CHW -> HWC */
    sample_svp_check_exps_return(blob->type != HI_SVP_BLOB_TYPE_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->type(%d) must be %d!\n", blob->type, HI_SVP_BLOB_TYPE_S20Q12);
    sample_svp_check_exps_return(blob->num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->num(%u) is 0!\n", blob->num);
    sample_svp_check_exps_return(((blob->shape.whc.chn == 0) ||
        (blob->shape.whc.chn > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.chn(%u) should be (0, %u]!\n", blob->shape.whc.chn,
        SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(((blob->shape.whc.height == 0) ||
        (blob->shape.whc.height > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.height(%u) should be (0, %u]!\n", blob->shape.whc.height,
        SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    if (is_loc_blob == HI_TRUE) {
        sample_svp_check_exps_return(((blob->shape.whc.width < width) ||
            (blob->shape.whc.width % width != 0)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,blob->shape.whc.width(%u) should be multiple of %u!\n",
            blob->shape.whc.width, width);
    } else {
        sample_svp_check_exps_return(blob->shape.whc.width != width, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,blob->shape.whc.width(%u) should be %u!\n", blob->shape.whc.width, width);
    }

    sample_svp_check_exps_return(((blob->stride == 0) || (blob->stride < sizeof(hi_u32) * blob->shape.whc.width)),
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,blob->stride(%u) is 0 or less than %u!\n",
        blob->stride, (hi_u32)(sizeof(hi_u32) * blob->shape.whc.width));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(blob->stride) != 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->stride(%u) is not %u bytes align!\n", blob->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(blob->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->virt_addr is 0!\n");
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_ssd_param_src_blob(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_ssd_sw_param *sw_param)
{
    hi_u32 i;
    hi_svp_blob *loc_blob = HI_NULL;
    hi_svp_blob *conf_blob = HI_NULL;
    hi_s32 ret;

    for (i = 0; i < SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM; i++) {
        loc_blob = &nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]];
        ret = sample_svp_nnie_check_ssd_param_each_src_blob(loc_blob, SAMPLE_SVP_NNIE_COORD_NUM, HI_TRUE);
        sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,%u-th loc_blob check failed!\n", i);
    }
    for (i = 0; i < SAMPLE_SVP_NNIE_SSD_REPORT_CONF_NODE_NUM; i++) {
        loc_blob = &nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]];
        conf_blob = &nnie_param->seg_data[0].dst[sw_param->conf_blob_idx[i]];
        ret = sample_svp_nnie_check_ssd_param_each_src_blob(conf_blob,
            sw_param->class_num * loc_blob->shape.whc.width / SAMPLE_SVP_NNIE_COORD_NUM, HI_FALSE);
        sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,%u-th conf_blob check failed!\n", i);
    }

    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_ssd_get_result_param_dim(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_ssd_sw_param *sw_param)
{
    hi_u32 i;
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_svp_blob *loc_blob = HI_NULL;
    hi_svp_blob *conf_blob = HI_NULL;
    hi_u64 size, softmax_size, detection_size;
    hi_u32 prior_box_num = 0;

    sample_svp_check_exps_return(((sw_param->softmax_tmp_buf.virt_addr == 0) ||
        (sw_param->get_result_tmp_buf.virt_addr == 0)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->softmax_tmp_buf.virt_addr or sw_param->get_result_tmp_buf.virt_addr is 0!\n");
    for (i = 0; i < SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM; i++) {
        loc_blob = &nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]];
        conf_blob = &nnie_param->seg_data[0].dst[sw_param->conf_blob_idx[i]];
        sample_svp_check_exps_return(loc_blob->shape.whc.chn != conf_blob->shape.whc.chn, ret,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,%u-th loc_blob->shape.whc.chn(%u) should be equal to %u!\n",
            i, loc_blob->shape.whc.chn, conf_blob->shape.whc.chn);
        sample_svp_check_exps_return(loc_blob->shape.whc.height != conf_blob->shape.whc.height, ret,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,%u-th loc_blob->shape.whc.height(%u) should be equal to %u!\n",
            i, loc_blob->shape.whc.height, conf_blob->shape.whc.height);
    }
    for (i = 0; i < SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM; i++) {
        loc_blob = &nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]];
        size = loc_blob->shape.whc.width * sizeof(hi_u32) * SAMPLE_SVP_NNIE_DOUBLE;
        sample_svp_check_exps_return(sw_param->prior_box_size[i] < size, ret,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->prior_box_size[%u](%u) is less than %llu!\n",
            i, sw_param->prior_box_size[i], size);
    }
    /* softmax size */
    softmax_size = 0;
    for (i = 0; i < sw_param->concat_num; i++) {
        softmax_size += nnie_param->seg_data[0].dst[sw_param->conf_blob_idx[i]].shape.whc.chn *
            nnie_param->seg_data[0].dst[sw_param->conf_blob_idx[i]].shape.whc.height *
            nnie_param->seg_data[0].dst[sw_param->conf_blob_idx[i]].shape.whc.width * sizeof(hi_u32);
    }
    sample_svp_check_exps_return(sw_param->softmax_tmp_buf.size < softmax_size, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->softmax_tmp_buf.size(%u) is less than %llu!\n", sw_param->softmax_tmp_buf.size, softmax_size);
    /* detection size */
    for (i = 0; i < sw_param->concat_num; i++) {
        prior_box_num += nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]].shape.whc.chn *
            nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]].shape.whc.height *
            nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]].shape.whc.width;
    }
    /* decode bbox result */
    detection_size = prior_box_num * SAMPLE_SVP_NNIE_COORD_NUM * sizeof(hi_u32);
    /* top_k proposal and keep_top_k proposal */
    detection_size += prior_box_num * SAMPLE_SVP_NNIE_PROPOSAL_WIDTH * sizeof(hi_u32) * SAMPLE_SVP_NNIE_DOUBLE;
    /* stack */
    detection_size += prior_box_num * SAMPLE_SVP_NNIE_DOUBLE * sizeof(hi_u32);
    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.size < detection_size, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->get_result_tmp_buf.size(%u) is less than %llu!\n",
        sw_param->get_result_tmp_buf.size, detection_size);
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_ssd_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_ssd_sw_param *sw_param)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u32 i;

    sample_svp_check_exps_return(sw_param->concat_num != SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM,
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->concat_num(%u) must be %u!\n", sw_param->concat_num,
        SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM);
    sample_svp_check_exps_return(sw_param->conf_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->conf_threshold(%u) must be [0, %u]!\n", sw_param->conf_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(sw_param->class_num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->class_num(%u) is 0!\n", sw_param->class_num);
    sample_svp_check_exps_return(sw_param->top_k == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->top_k(%u) is 0!\n", sw_param->top_k);
    sample_svp_check_exps_return(((sw_param->keep_top_k == 0) || (sw_param->keep_top_k > sw_param->top_k)), ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->keep_top_k(%u) should be (0, %u]!\n", sw_param->keep_top_k,
        sw_param->top_k);
    sample_svp_check_exps_return(sw_param->nms_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->nms_threshold(%u) must be [0, %u]!\n", sw_param->nms_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(sw_param->prior_box_num != SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM,
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->prior_box_num(%u) must be %u!\n", sw_param->prior_box_num,
        SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM);
    for (i = 0; i < sw_param->prior_box_num; i++) {
        sample_svp_check_exps_return(sw_param->prior_box[i] == HI_NULL, ret,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->prior_box[%u] is HI_NULL!\n", i);
    }

    ret = sample_svp_nnie_check_ssd_param_src_blob(nnie_param, sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_ssd_param_src_blob failed!\n");
    ret = sample_svp_nnie_check_get_result_dst_blob(&sw_param->dst_roi, &sw_param->dst_score,
        &sw_param->class_roi_num, sw_param->top_k, sw_param->class_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_get_result_dst_blob failed!\n");
    ret = sample_svp_nnie_check_ssd_get_result_param_dim(nnie_param, sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_ssd_get_result_param_dim failed!\n");
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_and_fill_ssd_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_ssd_sw_param *sw_param, sample_svp_nnie_ssd_get_result_param *param)
{
    hi_s32 ret;
    hi_u32 i;

    sample_svp_check_exps_return(((nnie_param == HI_NULL) || (sw_param == HI_NULL) || (param == HI_NULL)),
        HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param or sw_param or param is HI_NULL!\n");

    ret = sample_svp_nnie_check_ssd_param(nnie_param, sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sample_svp_nnie_check_ssd_param failed!\n");

    for (i = 0; i < SAMPLE_SVP_NNIE_SSD_REPORT_BBOX_NODE_NUM; i++) {
        param->loc_blob_height[i] = nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]].shape.whc.height;
        param->loc_blob_width[i] = nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]].shape.whc.width;
        param->loc_blob_chn[i] = nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]].shape.whc.chn;
        param->loc_blob_stride[i] = nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]].stride;
        param->loc_addr[i] = sample_svp_convert_addr_to_ptr(hi_s32,
            nnie_param->seg_data[0].dst[sw_param->loc_blob_idx[i]].virt_addr);
    }
    for (i = 0; i < SAMPLE_SVP_NNIE_SSD_REPORT_CONF_NODE_NUM; i++) {
        param->conf_blob_height[i] = nnie_param->seg_data[0].dst[sw_param->conf_blob_idx[i]].shape.whc.height;
        param->conf_blob_width[i] = nnie_param->seg_data[0].dst[sw_param->conf_blob_idx[i]].shape.whc.width;
        param->conf_blob_chn[i] = nnie_param->seg_data[0].dst[sw_param->conf_blob_idx[i]].shape.whc.chn;
        param->conf_blob_stride[i] = nnie_param->seg_data[0].dst[sw_param->conf_blob_idx[i]].stride;
        param->conf_addr[i] = sample_svp_convert_addr_to_ptr(hi_s32,
            nnie_param->seg_data[0].dst[sw_param->conf_blob_idx[i]].virt_addr);
    }
    param->concat_num = sw_param->concat_num;
    param->conf_threshold = sw_param->conf_threshold;
    param->class_num = sw_param->class_num;
    param->top_k = sw_param->top_k;
    param->keep_top_k = sw_param->keep_top_k;
    param->nms_threshold = sw_param->nms_threshold;
    ret = memcpy_s(param->prior_box, sizeof(param->prior_box), sw_param->prior_box, sizeof(sw_param->prior_box));
    sample_svp_check_exps_return(ret != EOK, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,memcpy_s param->prior_box[] failed!\n");
    param->prior_box_num = sw_param->prior_box_num;
    param->assist_mem_pool = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->get_result_tmp_buf.virt_addr);;
    param->dst_score = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_score.virt_addr);
    param->dst_roi = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_roi.virt_addr);
    param->class_roi_num = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->class_roi_num.virt_addr);

    return ret;
}

static hi_s32 sample_svp_nnie_check_yolov1_get_result_src_blob(hi_svp_blob *blob, hi_u32 width)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    sample_svp_check_exps_return(blob->type != HI_SVP_BLOB_TYPE_VEC_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->type (%d) must be %u!\n", blob->type, HI_SVP_BLOB_TYPE_VEC_S20Q12);
    sample_svp_check_exps_return(blob->num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->num (%u) is 0!\n", blob->num);
    sample_svp_check_exps_return(blob->shape.whc.chn != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.chn(%u) must be 1!\n", blob->shape.whc.chn);
    sample_svp_check_exps_return(blob->shape.whc.height != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.height(%u) must be 1!\n", blob->shape.whc.height);
    sample_svp_check_exps_return(blob->shape.whc.width != width, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.width(%u) must be %u!\n", blob->shape.whc.width, width);
    sample_svp_check_exps_return(blob->stride < sizeof(hi_u32) * width, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->stride(%u) is less than %u!\n", blob->stride, (hi_u32)(sizeof(hi_u32) * width));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(blob->stride) != 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->stride(%u) is not %u bytes align!\n", blob->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(blob->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->virt_addr is 0!\n");
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_yolov1_get_result_tmp_buf(sample_svp_nnie_yolov1_sw_param *sw_param)
{
    hi_u32 total_grid_num = sw_param->grid_num_height * sw_param->grid_num_width;
    hi_u32 class_num = sw_param->class_num;
    hi_u32 each_grid_bbox_num = sw_param->bbox_num_each_grid;
    hi_u32 total_bbox_num = total_grid_num * each_grid_bbox_num;
    hi_u32 trans_size = (class_num + each_grid_bbox_num * (SAMPLE_SVP_NNIE_COORD_NUM + 1)) *
        total_grid_num * sizeof(hi_u32);
    hi_u32 probsize = class_num * total_bbox_num * sizeof(hi_u32);
    hi_u32 score_size = total_bbox_num * sizeof(sample_svp_nnie_yolov1_score);
    hi_u32 stack_size = total_bbox_num * sizeof(sample_svp_nnie_stack);
    hi_u64 total_size = trans_size + probsize + score_size + stack_size;
    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.virt_addr == 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->get_result_tmp_buf.virt_addr(%llu) is 0!\n",
        sw_param->get_result_tmp_buf.virt_addr);
    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.size < total_size, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->get_result_tmp_buf.size(%u) is less than %llu!\n",
        sw_param->get_result_tmp_buf.size, total_size);
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_yolov1_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov1_sw_param *sw_param)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u64 width;

    sample_svp_check_exps_return(((sw_param->class_num == 0) || (sw_param->class_num > SAMPLE_SVP_NNIE_MAX_CLASS_NUM)),
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->class_num(%u) should be (0, %u]!\n",
        sw_param->class_num, SAMPLE_SVP_NNIE_MAX_CLASS_NUM);
    sample_svp_check_exps_return(sw_param->bbox_num_each_grid == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->bbox_num_each_grid(%u) is 0!\n", sw_param->bbox_num_each_grid);
    sample_svp_check_exps_return(((sw_param->grid_num_height == 0) ||
        (sw_param->grid_num_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->grid_num_height(%u) should be (0, %u]!\n",
        sw_param->grid_num_height, SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(((sw_param->grid_num_width == 0) ||
        (sw_param->grid_num_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->grid_num_width(%u) should be (0, %u]!\n",
        sw_param->grid_num_width, SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(((sw_param->ori_img_width == 0) ||
        (sw_param->ori_img_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->ori_img_width(%u) should be (0, %u]!\n",
        sw_param->ori_img_width, SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(((sw_param->ori_img_height == 0) ||
        (sw_param->ori_img_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->ori_img_height(%u) should be (0, %u]!\n",
        sw_param->ori_img_height, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(sw_param->conf_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->conf_threshold(%u) must be [0, %u]!\n", sw_param->conf_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(sw_param->nms_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->nms_threshold(%u) must be [0, %u]!\n", sw_param->nms_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);

    width = sw_param->grid_num_height * sw_param->grid_num_width *
        (sw_param->class_num + (SAMPLE_SVP_NNIE_COORD_NUM + 1) * (hi_u64)sw_param->bbox_num_each_grid);
    sample_svp_check_exps_return(width > SAMPLE_SVP_NNIE_MAX_U32, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,width(%llu) is greater than %u!\n", width, SAMPLE_SVP_NNIE_MAX_U32);
    ret = sample_svp_nnie_check_yolov1_get_result_src_blob(&nnie_param->seg_data[0].dst[0], (hi_u32)width);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_yolov1_get_result_src_blob failed!\n");
    ret = sample_svp_nnie_check_get_result_dst_blob(&sw_param->dst_roi, &sw_param->dst_score,
        &sw_param->class_roi_num, sw_param->grid_num_height * sw_param->grid_num_width * sw_param->bbox_num_each_grid,
        sw_param->class_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_get_result_dst_blob failed!\n");
    ret = sample_svp_nnie_check_yolov1_get_result_tmp_buf(sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_yolov1_get_result_tmp_buf failed!\n");
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_and_fill_yolov1_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov1_sw_param *sw_param, sample_svp_nnie_yolov1_get_result_param *param)
{
    hi_s32 ret;

    sample_svp_check_exps_return(((nnie_param == HI_NULL) || (sw_param == HI_NULL) || (param == HI_NULL)),
        HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param or sw_param or param is HI_NULL!\n");

    ret = sample_svp_nnie_check_yolov1_param(nnie_param, sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sample_svp_nnie_check_yolov1_param failed!\n");

    param->fc_result = sample_svp_convert_addr_to_ptr(hi_s32, nnie_param->seg_data[0].dst[0].virt_addr);
    param->class_num = sw_param->class_num;
    param->bbox_num_each_grid = sw_param->bbox_num_each_grid;
    param->grid_num_height = sw_param->grid_num_height;
    param->grid_num_width = sw_param->grid_num_width;
    param->conf_threshold = sw_param->conf_threshold;
    param->nms_threshold = sw_param->nms_threshold;
    param->ori_img_width = sw_param->ori_img_width;
    param->ori_img_height = sw_param->ori_img_height;
    param->tmp_buf = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->get_result_tmp_buf.virt_addr);
    param->dst_scores = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_score.virt_addr);
    param->dst_roi = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_roi.virt_addr);
    param->class_roi_num = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->class_roi_num.virt_addr);

    return ret;
}

static hi_s32 sample_svp_nnie_check_yolov2_get_result_src_blob(hi_svp_blob *blob, hi_u32 width)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;

    sample_svp_check_exps_return(blob->type != HI_SVP_BLOB_TYPE_VEC_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->type (%d) must be %u!\n", blob->type, HI_SVP_BLOB_TYPE_VEC_S20Q12);
    sample_svp_check_exps_return(blob->num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->num (%u) is 0!\n", blob->num);
    sample_svp_check_exps_return(blob->shape.whc.chn != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.chn(%u) must be 1!\n", blob->shape.whc.chn);
    sample_svp_check_exps_return(blob->shape.whc.height != 1, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.height(%u) must be 1!\n", blob->shape.whc.height);
    sample_svp_check_exps_return(blob->shape.whc.width != width, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->shape.whc.width(%u) must be %u!\n", blob->shape.whc.width, width);
    sample_svp_check_exps_return(blob->stride < sizeof(hi_u32) * width, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->stride(%u) is less than %u!\n", blob->stride, (hi_u32)(sizeof(hi_u32) * width));
    sample_svp_check_exps_return(sample_svp_nnie_check_align_16(blob->stride) != 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->stride(%u) is not %u bytes align!\n", blob->stride, SAMPLE_SVP_NNIE_ALIGN_16);
    sample_svp_check_exps_return(blob->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,blob->virt_addr is 0!\n");
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_yolov2_get_result_tmp_buf(sample_svp_nnie_yolov2_sw_param *sw_param)
{
    hi_u32 total_grid_num = sw_param->grid_num_height * sw_param->grid_num_width;
    hi_u32 para_length = sw_param->bbox_num_each_grid * (SAMPLE_SVP_NNIE_COORD_NUM + 1 + sw_param->class_num);
    hi_u32 total_bbox_num = total_grid_num * sw_param->bbox_num_each_grid;
    hi_u32 trans_size = total_grid_num * para_length * sizeof(hi_u32);
    hi_u32 bbox_assist_buf_size = total_bbox_num * sizeof(sample_svp_nnie_stack);
    hi_u32 bbox_buf_size = total_bbox_num * sizeof(sample_svp_nnie_yolov2_bbox);
    hi_u32 bbox_tmp_buf_size = total_grid_num * para_length * sizeof(hi_float);
    hi_u64 total_size = trans_size + bbox_assist_buf_size + bbox_buf_size + bbox_tmp_buf_size;
    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.virt_addr == 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->get_result_tmp_buf.virt_addr(%llu) is 0!\n",
        sw_param->get_result_tmp_buf.virt_addr);
    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.size < total_size, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->get_result_tmp_buf.size(%u) is less than %llu!\n",
        sw_param->get_result_tmp_buf.size, total_size);
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_yolov2_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov2_sw_param *sw_param)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u64 width;

    sample_svp_check_exps_return(((sw_param->class_num == 0) || (sw_param->class_num > SAMPLE_SVP_NNIE_MAX_CLASS_NUM)),
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->class_num(%u) should be (0, %u]!\n",
        sw_param->class_num, SAMPLE_SVP_NNIE_MAX_CLASS_NUM);
    sample_svp_check_exps_return(sw_param->bbox_num_each_grid == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->bbox_num_each_grid(%u) is 0!\n", sw_param->bbox_num_each_grid);
    sample_svp_check_exps_return(((sw_param->grid_num_height == 0) ||
        (sw_param->grid_num_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->grid_num_height(%u) should be (0, %u]!\n",
        sw_param->grid_num_height, SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(((sw_param->grid_num_width == 0) ||
        (sw_param->grid_num_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->grid_num_width(%u) should be (0, %u]!\n",
        sw_param->grid_num_width, SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(((sw_param->ori_img_width == 0) ||
        (sw_param->ori_img_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->ori_img_width(%u) should be (0, %u]!\n",
        sw_param->ori_img_width, SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(((sw_param->ori_img_height == 0) ||
        (sw_param->ori_img_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->ori_img_height(%u) should be (0, %u]!\n",
        sw_param->ori_img_height, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(sw_param->conf_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->conf_threshold(%u) must be [0, %u]!\n", sw_param->conf_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(sw_param->nms_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->nms_threshold(%u) must be [0, %u]!\n", sw_param->nms_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);

    width = sw_param->grid_num_height * sw_param->grid_num_width *
        (sw_param->class_num + SAMPLE_SVP_NNIE_COORD_NUM + 1) * (hi_u64)sw_param->bbox_num_each_grid;
    sample_svp_check_exps_return(width > SAMPLE_SVP_NNIE_MAX_U32, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,width(%llu) is greater than %u!\n", width, SAMPLE_SVP_NNIE_MAX_U32);
    ret = sample_svp_nnie_check_yolov2_get_result_src_blob(&nnie_param->seg_data[0].dst[0], (hi_u32)width);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_yolov2_get_result_src_blob failed!\n");
    ret = sample_svp_nnie_check_get_result_dst_blob(&sw_param->dst_roi, &sw_param->dst_score,
        &sw_param->class_roi_num, sw_param->grid_num_height * sw_param->grid_num_width * sw_param->bbox_num_each_grid,
        sw_param->class_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_get_result_dst_blob failed!\n");
    ret = sample_svp_nnie_check_yolov2_get_result_tmp_buf(sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_yolov2_get_result_tmp_buf failed!\n");
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_and_fill_yolov2_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov2_sw_param *sw_param, sample_svp_nnie_yolov2_get_result_param *param)
{
    hi_s32 ret;

    sample_svp_check_exps_return(((nnie_param == HI_NULL) || (sw_param == HI_NULL) || (param == HI_NULL)),
        HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param or sw_param or param is HI_NULL!\n");
    ret = sample_svp_nnie_check_yolov2_param(nnie_param, sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sample_svp_nnie_check_yolov2_param failed!\n");

    param->input_data = sample_svp_convert_addr_to_ptr(hi_s32, nnie_param->seg_data[0].dst[0].virt_addr);
    param->grid_num_width = sw_param->grid_num_width;
    param->grid_num_height = sw_param->grid_num_height;
    param->bbox_num_each_grid = sw_param->bbox_num_each_grid;
    param->class_num = sw_param->class_num;
    param->ori_img_width = sw_param->ori_img_width;
    param->ori_img_height = sw_param->ori_img_height;
    param->nms_threshold = sw_param->nms_threshold;
    param->conf_threshold = sw_param->conf_threshold;
    param->bias = sw_param->bias;
    param->tmp_buf = sample_svp_convert_addr_to_ptr(hi_u32, sw_param->get_result_tmp_buf.virt_addr);
    param->dst_score = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_score.virt_addr);
    param->dst_roi = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_roi.virt_addr);
    param->class_roi_num = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->class_roi_num.virt_addr);

    return ret;
}

static hi_s32 sample_svp_nnie_check_yolov3_get_result_src_blob(hi_svp_blob *blob, hi_u32 chn)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u32 i;

    for (i = 0; i < SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM; i++) {
        sample_svp_check_exps_return(blob->type != HI_SVP_BLOB_TYPE_S20Q12, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,blob->type (%d) should be %d!\n", blob->type, HI_SVP_BLOB_TYPE_S20Q12);
        sample_svp_check_exps_return(blob->num == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,blob->num (%u) is 0!\n", blob->num);
        sample_svp_check_exps_return(blob->shape.whc.chn != chn, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,blob->shape.whc.chn(%u) must be %u!\n", blob->shape.whc.chn, chn);
        sample_svp_check_exps_return(((blob->shape.whc.height == 0) ||
            (blob->shape.whc.height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,blob->shape.whc.height(%u) must be (0, %u]!\n",
            blob->shape.whc.height, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
        sample_svp_check_exps_return(((blob->shape.whc.width == 0) ||
            (blob->shape.whc.width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,blob->shape.whc.width(%u) must be (0, %u]!\n",
            blob->shape.whc.width, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
        sample_svp_check_exps_return(blob->stride < sizeof(hi_u32) * blob->shape.whc.width,
            ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,blob->stride(%u) is less than %u!\n",
            blob->stride, (hi_u32)(sizeof(hi_u32) * blob->shape.whc.width));
        sample_svp_check_exps_return(sample_svp_nnie_check_align_16(blob->stride) != 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,blob->stride(%u) is not %u bytes align!\n", blob->stride, SAMPLE_SVP_NNIE_ALIGN_16);
        sample_svp_check_exps_return(blob->virt_addr == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,blob->virt_addr is 0!\n");
    }

    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_yolov3_bbox_num(sample_svp_nnie_yolov3_sw_param *sw_param, hi_u32 *bbox_num)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u32 i;
    hi_u64 num = 0;

    sample_svp_check_exps_return(sw_param->bbox_num_each_grid == 0, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->bbox_num_each_grid(%u) is 0!\n", sw_param->bbox_num_each_grid);
    for (i = 0; i < SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM; i++) {
        sample_svp_check_exps_return(((sw_param->grid_num_height[i] == 0) ||
            (sw_param->grid_num_height[i] > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sw_param->grid_num_height[%u](%u) should be (0, %u]!\n",
            i, sw_param->grid_num_height[i], SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
        sample_svp_check_exps_return(((sw_param->grid_num_width[i] == 0) ||
            (sw_param->grid_num_width[i] > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sw_param->grid_num_width[%u](%u) should be (0, %u]!\n",
            i, sw_param->grid_num_width[i], SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
        num += (hi_u64)sw_param->grid_num_width[i] * sw_param->grid_num_height[i] * sw_param->bbox_num_each_grid;
        sample_svp_check_exps_return(num > SAMPLE_SVP_NNIE_MAX_U32, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,num(%llu) is greater than %u!\n", num, SAMPLE_SVP_NNIE_MAX_U32);
    }
    *bbox_num = num;
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_yolov3_get_result_tmp_buf(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov3_sw_param *sw_param, hi_u32 total_bbox_num)
{
    hi_u32 assist_stack_size;
    hi_u32 total_bbox_size;
    hi_u64 dst_blob_size;
    hi_u64 max_blob_size = 0;
    hi_u64 total_size;
    hi_u32 i;

    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.virt_addr == 0, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->get_result_tmp_buf.virt_addr(%llu) is 0!\n",
        sw_param->get_result_tmp_buf.virt_addr);
    for (i = 0; i < SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM; i++) {
        dst_blob_size = nnie_param->model->seg[0].dst_node[i].shape.whc.width * sizeof(hi_u32) *
            nnie_param->model->seg[0].dst_node[i].shape.whc.height *
            nnie_param->model->seg[0].dst_node[i].shape.whc.chn;
        if (max_blob_size < dst_blob_size) {
            max_blob_size = dst_blob_size;
        }
    }
    assist_stack_size = total_bbox_num * sizeof(sample_svp_nnie_stack);
    total_bbox_size = total_bbox_num * sizeof(sample_svp_nnie_yolov3_bbox);
    total_size = (max_blob_size + assist_stack_size + total_bbox_size);

    sample_svp_check_exps_return(sw_param->get_result_tmp_buf.size < total_size, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->get_result_tmp_buf.size(%u) is less than %llu!\n",
        sw_param->get_result_tmp_buf.size, total_size);
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_check_yolov3_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov3_sw_param *sw_param)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u64 chn;
    hi_u32 bbox_num;

    sample_svp_check_exps_return(((sw_param->class_num == 0) || (sw_param->class_num > SAMPLE_SVP_NNIE_MAX_CLASS_NUM)),
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sw_param->class_num(%u) should be (0, %u]!\n",
        sw_param->class_num, SAMPLE_SVP_NNIE_MAX_CLASS_NUM);

    sample_svp_check_exps_return(((sw_param->ori_img_width == 0) ||
        (sw_param->ori_img_width > SAMPLE_SVP_NNIE_MAX_IMG_WIDTH)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->ori_img_width(%u) should be (0, %u]!\n",
        sw_param->ori_img_width, SAMPLE_SVP_NNIE_MAX_IMG_WIDTH);
    sample_svp_check_exps_return(((sw_param->ori_img_height == 0) ||
        (sw_param->ori_img_height > SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT)), ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->ori_img_height(%u) should be (0, %u]!\n",
        sw_param->ori_img_height, SAMPLE_SVP_NNIE_MAX_IMG_HEIGHT);
    sample_svp_check_exps_return(sw_param->conf_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->conf_threshold(%u) must be [0, %u]!\n", sw_param->conf_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);
    sample_svp_check_exps_return(sw_param->nms_threshold > SAMPLE_SVP_NNIE_QUANT_BASE, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sw_param->nms_threshold(%u) must be [0, %u]!\n", sw_param->nms_threshold, SAMPLE_SVP_NNIE_QUANT_BASE);

    ret = sample_svp_nnie_check_yolov3_bbox_num(sw_param, &bbox_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_yolov3_bbox_num failed!\n");
    chn = (sw_param->class_num + SAMPLE_SVP_NNIE_COORD_NUM + 1) * (hi_u64)sw_param->bbox_num_each_grid;
    sample_svp_check_exps_return(chn > SAMPLE_SVP_NNIE_MAX_U32, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,chn(%llu) is greater than %u!\n", chn, SAMPLE_SVP_NNIE_MAX_U32);
    ret = sample_svp_nnie_check_yolov3_get_result_src_blob(&nnie_param->seg_data[0].dst[0], (hi_u32)chn);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_yolov3_get_result_src_blob failed!\n");
    ret = sample_svp_nnie_check_yolov3_get_result_tmp_buf(nnie_param, sw_param, bbox_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_yolov3_get_result_tmp_buf failed!\n");
    ret = sample_svp_nnie_check_get_result_dst_blob(&sw_param->dst_roi, &sw_param->dst_score,
        &sw_param->class_roi_num, bbox_num, sw_param->class_num);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_check_get_result_dst_blob failed!\n");
    return HI_SUCCESS;
}

hi_s32 sample_svp_nnie_check_and_fill_yolov3_get_result_param(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov3_sw_param *sw_param, sample_svp_nnie_yolov3_get_result_param *param)
{
    hi_u32 i;
    hi_s32 ret;

    sample_svp_check_exps_return(((nnie_param == HI_NULL) || (sw_param == HI_NULL) || (param == HI_NULL)),
        HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param or sw_param or param is HI_NULL!\n");
    ret = sample_svp_nnie_check_yolov3_param(nnie_param, sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret,
        SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,sample_svp_nnie_check_yolov3_param failed!\n");

    for (i = 0; i < SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM; i++) {
        param->input_blob[i] = sample_svp_convert_addr_to_ptr(hi_s32, nnie_param->seg_data[0].dst[i].virt_addr);
        param->input_stride[i] = nnie_param->seg_data[0].dst[i].stride;
        ret = memcpy_s(param->bias[i], sizeof(hi_u32) * SAMPLE_SVP_NNIE_YOLOV3_BIAS_NUM, sw_param->bias[i],
            sizeof(hi_u32) * SAMPLE_SVP_NNIE_YOLOV3_BIAS_NUM);
        sample_svp_check_exps_return(ret != EOK, HI_ERR_SVP_NNIE_ILLEGAL_PARAM,
            SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,memcpy_s param->bias[%u] failed!\n", i);
    }
    param->grid_num_width = sw_param->grid_num_width;
    param->grid_num_height = sw_param->grid_num_height;
    param->bbox_num_each_grid = sw_param->bbox_num_each_grid;
    param->class_num = sw_param->class_num;
    param->ori_img_width = sw_param->ori_img_width;
    param->ori_img_height = sw_param->ori_img_height;
    param->nms_threshold = sw_param->nms_threshold;
    param->conf_threshold = sw_param->conf_threshold;
    param->tmp_buf = sample_svp_convert_addr_to_ptr(hi_u32, sw_param->get_result_tmp_buf.virt_addr);
    param->dst_score = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_score.virt_addr);
    param->dst_roi = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->dst_roi.virt_addr);
    param->class_roi_num = sample_svp_convert_addr_to_ptr(hi_s32, sw_param->class_roi_num.virt_addr);

    return ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

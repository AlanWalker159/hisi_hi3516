/*
 * Copyright (c) Hisilicon Technologies Co., Ltd. 2019-2020. All rights reserved.
 * Description: sample_svp_nnie_yolo.c
 * Author: Hisilicon multimedia software (SVP) group
 * Create: 2019-08-20
 */
#include "sample_svp_nnie_yolo.hpp"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <math.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/prctl.h>

#include <stdlib.h>
#include <semaphore.h>
#include <limits.h>


#include "hi_common.h"
#include "hi_common_svp.h"
#include "hi_common_ive.h"

#include "hi_mpi_ive.h"


#include "sample_common_svp.h"
#include "sample_common_nnie.h"
#include "sample_svp_nnie_software.h"


#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/core.hpp"
#include "opencv2/dnn.hpp"
#include "libyuv.h"




using namespace cv;
using namespace std;



#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */

#define SAMPLE_SVP_NNIE_YOLOV1_CLASS_NUM           20
#define SAMPLE_SVP_NNIE_YOLOV1_GRID_BBOX_NUM       2
#define SAMPLE_SVP_NNIE_YOLOV1_GRID_NUM_IN_WIDTH   7
#define SAMPLE_SVP_NNIE_YOLOV1_GRID_NUM_IN_HEIGHT  7
#define SAMPLE_SVP_NNIE_YOLOV1_NMS_THRESHOLD    0.5f
#define SAMPLE_SVP_NNIE_YOLOV1_CONF_THRESHOLD   0.3f

#define SAMPLE_SVP_NNIE_YOLOV2_CLASS_NUM           5
#define SAMPLE_SVP_NNIE_YOLOV2_GRID_BBOX_NUM       5
#define SAMPLE_SVP_NNIE_YOLOV2_GRID_NUM_IN_WIDTH   13
#define SAMPLE_SVP_NNIE_YOLOV2_GRID_NUM_IN_HEIGHT  13
#define SAMPLE_SVP_NNIE_YOLOV2_NMS_THRESHOLD     0.3f
#define SAMPLE_SVP_NNIE_YOLOV2_CONF_THRESHOLD   0.25f

#define SAMPLE_SVP_NNIE_YOLOV3_CLASS_NUM           80
#define SAMPLE_SVP_NNIE_YOLOV3_GRID_BBOX_NUM       3
#define SAMPLE_SVP_NNIE_YOLOV3_NMS_THRESHOLD    0.3f
#define SAMPLE_SVP_NNIE_YOLOV3_CONF_THRESHOLD   0.8f

/* Demo doesn't support multi-threading, please rewrite your owner demo when using multi-threading */
/* yolov1 para */
static sample_svp_nnie_model g_yolov1_model = { 0 };
static sample_svp_nnie_param g_yolov1_nnie_param = { 0 };
static sample_svp_nnie_yolov1_sw_param g_yolov1_sw_param = { 0 };
/* yolov2 para */
static sample_svp_nnie_model g_yolov2_model = { 0 };
static sample_svp_nnie_param g_yolov2_nnie_param = { 0 };
static sample_svp_nnie_yolov2_sw_param g_yolov2_sw_param = { 0 };
static hi_float g_yolov2_bias[SAMPLE_SVP_NNIE_YOLOV2_BIAS_NUM] = {1.08, 1.19, 3.42, 4.41, 6.63,
    11.38, 9.42, 5.11, 16.62, 10.52};
/* yolov3 para */
static sample_svp_nnie_model g_yolov3_model = { 0 };
static sample_svp_nnie_param g_yolov3_nnie_param = { 0 };
static sample_svp_nnie_yolov3_sw_param g_yolov3_sw_param = { 0 };
static hi_u32 g_yolov3_grid_num_in_width[SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM] = {13, 26, 52};
static hi_u32 g_yolov3_grid_num_in_height[SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM] = {13, 26, 52};
static hi_float g_yolov3_bias[SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM][SAMPLE_SVP_NNIE_YOLOV3_BIAS_NUM] = {
    {116.0f, 90.0f, 156.0f, 198.0f, 373.0f, 326.0f},
    {30.0f, 61.0f, 62.0f, 45.0f, 59.0f, 119.0f},
    {10.0f, 13.0f, 16.0f, 30.0f, 33.0f, 23.0f}};

/* function : yolov1 software deinit */
static hi_s32 sample_svp_nnie_yolov1_sw_deinit(sample_svp_nnie_yolov1_sw_param *yolov1_sw_param)
{
    sample_svp_check_exps_return(yolov1_sw_param == HI_NULL, HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error, sw_param can't be HI_NULL!\n");
    if (yolov1_sw_param->get_result_tmp_buf.phys_addr != 0 && yolov1_sw_param->get_result_tmp_buf.virt_addr != 0) {
        sample_svp_mmz_free(yolov1_sw_param->get_result_tmp_buf.phys_addr,
            yolov1_sw_param->get_result_tmp_buf.virt_addr);
        yolov1_sw_param->get_result_tmp_buf.phys_addr = 0;
        yolov1_sw_param->get_result_tmp_buf.virt_addr = 0;
        yolov1_sw_param->dst_roi.phys_addr = 0;
        yolov1_sw_param->dst_roi.virt_addr = 0;
        yolov1_sw_param->dst_score.phys_addr = 0;
        yolov1_sw_param->dst_score.virt_addr = 0;
        yolov1_sw_param->class_roi_num.phys_addr = 0;
        yolov1_sw_param->class_roi_num.virt_addr = 0;
    }
    return HI_SUCCESS;
}

/* function : yolov1 deinit */
static hi_s32 sample_svp_nnie_yolov1_deinit(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov1_sw_param *yolov1_sw_param, sample_svp_nnie_model *nnie_model)
{
    hi_s32 ret = HI_SUCCESS;
    /* hardware deinit */
    if (nnie_param != HI_NULL) {
        ret = sample_common_svp_nnie_param_deinit(nnie_param);
        sample_svp_check_exps_trace(ret != HI_SUCCESS, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_common_svp_nnie_param_deinit failed!\n");
    }
    /* software deinit */
    if (yolov1_sw_param != HI_NULL) {
        ret = sample_svp_nnie_yolov1_sw_deinit(yolov1_sw_param);
        sample_svp_check_exps_trace(ret != HI_SUCCESS, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_svp_nnie_yolov1_sw_deinit failed!\n");
    }
    /* model deinit */
    if (nnie_model != HI_NULL) {
        ret = sample_common_svp_nnie_unload_model(nnie_model);
        sample_svp_check_exps_trace(ret != HI_SUCCESS, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_common_svp_nnie_unload_model failed!\n");
    }
    return ret;
}

static hi_void sample_svp_nnie_yolov1_get_result_tmp_buf(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov1_sw_param *yolov1_sw_param, hi_u32 *total_size)
{
    hi_u32 total_grid_num = yolov1_sw_param->grid_num_height * yolov1_sw_param->grid_num_width;
    hi_u32 class_num = yolov1_sw_param->class_num;
    hi_u32 each_grid_bbox_num = yolov1_sw_param->bbox_num_each_grid;
    hi_u32 total_bbox_num = total_grid_num * each_grid_bbox_num;
    hi_u32 trans_size = (class_num + each_grid_bbox_num * (SAMPLE_SVP_NNIE_COORD_NUM + 1)) *
        total_grid_num * sizeof(hi_u32);
    hi_u32 probsize = class_num * total_bbox_num * sizeof(hi_u32);
    hi_u32 score_size = total_bbox_num * sizeof(sample_svp_nnie_yolov1_score);
    hi_u32 stack_size = total_bbox_num * sizeof(sample_svp_nnie_stack);
    *total_size = trans_size + probsize + score_size + stack_size;
}

static hi_s32 sample_svp_nnie_yolov1_sw_param_init(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov1_sw_param *yolov1_sw_param)
{
    yolov1_sw_param->ori_img_height = nnie_param->seg_data[0].src[0].shape.whc.height;
    yolov1_sw_param->ori_img_width = nnie_param->seg_data[0].src[0].shape.whc.width;
    yolov1_sw_param->bbox_num_each_grid = SAMPLE_SVP_NNIE_YOLOV1_GRID_BBOX_NUM;
    yolov1_sw_param->class_num = SAMPLE_SVP_NNIE_YOLOV1_CLASS_NUM;
    yolov1_sw_param->grid_num_height = SAMPLE_SVP_NNIE_YOLOV1_GRID_NUM_IN_HEIGHT;
    yolov1_sw_param->grid_num_width = SAMPLE_SVP_NNIE_YOLOV1_GRID_NUM_IN_WIDTH;
    yolov1_sw_param->nms_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV1_NMS_THRESHOLD * SAMPLE_SVP_NNIE_QUANT_BASE);
    yolov1_sw_param->conf_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV1_CONF_THRESHOLD * SAMPLE_SVP_NNIE_QUANT_BASE);
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_yolov1_sw_mem_init(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov1_sw_param *yolov1_sw_param)
{
    hi_s32 ret;
    hi_u32 class_num, bbox_num;
    hi_u32 total_size;
    hi_u32 dst_roi_size, dst_score_size, class_roi_num_size, tmp_buf_total_size;
    hi_phys_addr_t phys_addr;
    hi_u8 *virt_addr = HI_NULL;

    /* malloc assist buffer memory */
    class_num = yolov1_sw_param->class_num;
    bbox_num = yolov1_sw_param->bbox_num_each_grid * yolov1_sw_param->grid_num_height * yolov1_sw_param->grid_num_width;
    (hi_void)sample_svp_nnie_yolov1_get_result_tmp_buf(nnie_param, yolov1_sw_param, &tmp_buf_total_size);
    dst_roi_size = sample_svp_nnie_align_16(class_num * bbox_num * sizeof(hi_u32) * SAMPLE_SVP_NNIE_COORD_NUM);
    dst_score_size = sample_svp_nnie_align_16(class_num * bbox_num * sizeof(hi_u32));
    class_roi_num_size = sample_svp_nnie_align_16(class_num * sizeof(hi_u32));
    total_size = dst_roi_size + dst_score_size + class_roi_num_size + tmp_buf_total_size;
    ret = sample_common_svp_malloc_cached("yolov1_sw_init", HI_NULL, &phys_addr, (hi_void **)&virt_addr, total_size);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,malloc memory failed!\n");
    (hi_void)memset_s(virt_addr, total_size, 0, total_size);
    ret = sample_common_svp_flush_cache(phys_addr, (hi_void *)virt_addr, total_size);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,flush cache failed!\n");

    /* set each tmp buffer addr */
    yolov1_sw_param->get_result_tmp_buf.phys_addr = (hi_u64)phys_addr;
    yolov1_sw_param->get_result_tmp_buf.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr);
    yolov1_sw_param->get_result_tmp_buf.size = tmp_buf_total_size;

    /* set result blob */
    yolov1_sw_param->dst_roi.phys_addr = (hi_u64)phys_addr + tmp_buf_total_size;
    yolov1_sw_param->dst_roi.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr + tmp_buf_total_size);

    yolov1_sw_param->dst_score.phys_addr = (hi_u64)phys_addr + tmp_buf_total_size + dst_roi_size;
    yolov1_sw_param->dst_score.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr +
        tmp_buf_total_size + dst_roi_size);

    yolov1_sw_param->class_roi_num.phys_addr = (hi_u64)phys_addr + tmp_buf_total_size + dst_roi_size + dst_score_size;
    yolov1_sw_param->class_roi_num.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr +
        tmp_buf_total_size + dst_roi_size + dst_score_size);

    return ret;
}

static hi_s32 sample_svp_nnie_yolov1_sw_blob_init(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov1_sw_param *yolov1_sw_param)
{
    hi_u32 class_num, bbox_num;
    class_num = yolov1_sw_param->class_num;
    bbox_num = yolov1_sw_param->bbox_num_each_grid * yolov1_sw_param->grid_num_height * yolov1_sw_param->grid_num_width;

    /* set result blob */
    yolov1_sw_param->dst_roi.type = HI_SVP_BLOB_TYPE_S32;
    yolov1_sw_param->dst_roi.stride = sample_svp_nnie_align_16(class_num * bbox_num *
        sizeof(hi_u32) * SAMPLE_SVP_NNIE_COORD_NUM);
    yolov1_sw_param->dst_roi.num = 1;
    yolov1_sw_param->dst_roi.shape.whc.chn = 1;
    yolov1_sw_param->dst_roi.shape.whc.height = 1;
    yolov1_sw_param->dst_roi.shape.whc.width = class_num * bbox_num * SAMPLE_SVP_NNIE_COORD_NUM;

    yolov1_sw_param->dst_score.type = HI_SVP_BLOB_TYPE_S20Q12;
    yolov1_sw_param->dst_score.stride = sample_svp_nnie_align_16(class_num * bbox_num * sizeof(hi_u32));
    yolov1_sw_param->dst_score.num = 1;
    yolov1_sw_param->dst_score.shape.whc.chn = 1;
    yolov1_sw_param->dst_score.shape.whc.height = 1;
    yolov1_sw_param->dst_score.shape.whc.width = class_num * bbox_num;

    yolov1_sw_param->class_roi_num.type = HI_SVP_BLOB_TYPE_U32;
    yolov1_sw_param->class_roi_num.stride = sample_svp_nnie_align_16(class_num * sizeof(hi_u32));
    yolov1_sw_param->class_roi_num.num = 1;
    yolov1_sw_param->class_roi_num.shape.whc.chn = 1;
    yolov1_sw_param->class_roi_num.shape.whc.height = 1;
    yolov1_sw_param->class_roi_num.shape.whc.width = class_num;
    return HI_SUCCESS;
}

/* function: yolov1 software para init */
static hi_s32 sample_svp_nnie_yolov1_sw_init(sample_svp_nnie_cfg *cfg,
    sample_svp_nnie_param *nnie_param, sample_svp_nnie_yolov1_sw_param *yolov1_sw_param)
{
    hi_s32 ret;
    ret = sample_svp_nnie_yolov1_sw_param_init(nnie_param, yolov1_sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov1_sw_param_init failed!\n");

    ret = sample_svp_nnie_yolov1_sw_blob_init(nnie_param, yolov1_sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov1_sw_blob_init failed!\n");

    ret = sample_svp_nnie_yolov1_sw_mem_init(nnie_param, yolov1_sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov1_sw_mem_init failed!\n");

    return ret;
}

/* function: yolov1 init */
static hi_s32 sample_svp_nnie_yolov1_param_init(sample_svp_nnie_cfg *cfg,
    sample_svp_nnie_param *nnie_param, sample_svp_nnie_yolov1_sw_param *yolov1_sw_param)
{
    hi_s32 ret;
    /* init hardware para */
    ret = sample_common_svp_nnie_param_init(cfg, nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, init_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error(%#x),sample_common_svp_nnie_param_init failed!\n", ret);

    /* init software para */
    if (cfg->is_sw_gen_bbox == HI_TRUE) {
        ret = sample_svp_nnie_yolov1_sw_init(cfg, nnie_param, yolov1_sw_param);
        sample_svp_check_exps_goto(ret != HI_SUCCESS, init_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error(%#x),sample_svp_nnie_yolov1_sw_init failed!\n", ret);
    }

    return ret;
init_fail_0:
    ret = sample_svp_nnie_yolov1_deinit(nnie_param, yolov1_sw_param, HI_NULL);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error(%#x),sample_svp_nnie_yolov1_deinit failed!\n", ret);
    return HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
}

/* function : show YOLOV1 sample(image 448x448 U8_C3) */
static hi_s32 sample_svp_nnie_yolov1_detect_out_sw_proc(const hi_char *src_file, const hi_char *model_file)
{
    hi_float print_result_thresh;
    hi_s32 ret;
    sample_svp_nnie_cfg nnie_cfg;
    sample_svp_nnie_forward_info forward_info;

    /* set configuration parameter */
    (hi_void)memset_s(&nnie_cfg, sizeof(sample_svp_nnie_cfg), 0, sizeof(sample_svp_nnie_cfg));
    print_result_thresh = SAMPLE_SVP_NNIE_YOLOV1_CONF_THRESHOLD;
    nnie_cfg.max_input_num = 1;  /* max input image num in each batch */
    nnie_cfg.max_roi_num = 0;
    nnie_cfg.nnie_core_id[0] = HI_SVP_NNIE_ID_0;  /* set NNIE core */
    nnie_cfg.is_sw_gen_bbox = HI_TRUE;

    /* yolov1_detect_out_sw load model */
    sample_svp_trace_info("yolov1 load model!\n");
    ret = sample_common_svp_nnie_load_model(model_file, &g_yolov1_model);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_load_model failed!\n");

    /*
     * yolov1_detect_out_sw parameter initialization:
     * yolov1_detect_out_sw software parameters are set in sample_svp_nnie_yolov1_sw_init,
     * if user has changed net struct, please make sure the parameter settings in
     * sample_svp_nnie_yolov1_sw_init function are correct
     */
    sample_svp_trace_info("yolov1 parameter initialization!\n");
    g_yolov1_nnie_param.model = &(g_yolov1_model.model);
    ret = sample_svp_nnie_yolov1_param_init(&nnie_cfg, &g_yolov1_nnie_param, &g_yolov1_sw_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov1_param_init failed!\n");

    /* yolov1_detect_out_sw fill src data */
    sample_svp_trace_info("yolov1 start!\n");
    ret = sample_common_svp_nnie_fill_src_data(src_file, 0, 0, &g_yolov1_nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_fill_src_data failed!\n");

    /* yolov1_detect_out_sw NNIE process(process the 0-th segment) */
    forward_info.prev_seg_idx = 0;
    forward_info.proc_seg_idx = 0;
    forward_info.is_instant = HI_TRUE;
    ret = sample_common_svp_nnie_forward(&forward_info, HI_NULL, 1, &g_yolov1_nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_forward failed!\n");

    /*
     * yolov1_detect_out_sw software process:
     * if user has changed net struct, please make sure sample_svp_nnie_yolov1_get_result
     * function input datas are correct
     */
    ret = sample_svp_nnie_yolov1_get_result(&g_yolov1_nnie_param, &g_yolov1_sw_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov1_get_result failed!\n");

    /*
     * print result, this sample has 20 classes:
     * class 0:plane          class 1:bicycle
     * class 2:bird           class 3:boat            class 4:bottle
     * class 5:bus            class 6:car             class 7:cat
     * class 8:chair          class 9:cow             class10:diningtable
     * class 11:dog           class12:horse           class13:motorbike
     * class 14:person        class15:pottedplant     class16:sheep
     * class 17:sofa          class18:train           class19:tvmonitor
     */
    sample_svp_trace_info("yolov1 result:\n");
    ret = sample_common_svp_nnie_print_sw_detect_result(&(g_yolov1_sw_param.dst_score),
        &(g_yolov1_sw_param.dst_roi), &(g_yolov1_sw_param.class_roi_num), HI_FALSE, print_result_thresh);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_print_sw_detect_result failed!\n");

yolov1_fail_0:
    sample_svp_nnie_yolov1_deinit(&g_yolov1_nnie_param, &g_yolov1_sw_param, &g_yolov1_model);
    return ret;
}

/* function : show YOLOV1 sample(image 448x448 U8_C3) */
static hi_s32 sample_svp_nnie_yolov1_detect_out_hw_proc(const hi_char *src_file, const hi_char *model_file)
{
    hi_float print_result_thresh;
    hi_s32 ret;
    sample_svp_nnie_cfg nnie_cfg;
    sample_svp_nnie_forward_info forward_info;

    /* set configuration parameter */
    (hi_void)memset_s(&nnie_cfg, sizeof(sample_svp_nnie_cfg), 0, sizeof(sample_svp_nnie_cfg));
    print_result_thresh = SAMPLE_SVP_NNIE_YOLOV1_CONF_THRESHOLD;
    nnie_cfg.max_input_num = 1;  /* max input image num in each batch */
    nnie_cfg.max_roi_num = 0;
    nnie_cfg.nnie_core_id[0] = HI_SVP_NNIE_ID_0;  /* set NNIE core */
    /* set detection out layer's threshold */
    nnie_cfg.threshold_num[0] = 1;
    nnie_cfg.threshold[0][0].min_width = (hi_u32)(0 * SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.threshold[0][0].min_height = (hi_u32)(0 * SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.threshold[0][0].nms_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV1_NMS_THRESHOLD *
        SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.threshold[0][0].score_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV1_CONF_THRESHOLD *
        SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.is_sw_gen_bbox = HI_FALSE;

    /* yolov1_detect_out_hw load model */
    sample_svp_trace_info("yolov1 load model!\n");
    ret = sample_common_svp_nnie_load_model(model_file, &g_yolov1_model);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_load_model failed!\n");

    /* yolov1_detect_out_hw parameter initialization */
    sample_svp_trace_info("yolov1 parameter initialization!\n");
    g_yolov1_nnie_param.model = &(g_yolov1_model.model);
    ret = sample_svp_nnie_yolov1_param_init(&nnie_cfg, &g_yolov1_nnie_param, &g_yolov1_sw_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov1_param_init failed!\n");

    /* yolov1_detect_out_hw fill src data */
    sample_svp_trace_info("yolov1 start!\n");
    ret = sample_common_svp_nnie_fill_src_data(src_file, 0, 0, &g_yolov1_nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_fill_src_data failed!\n");

    /* yolov1_detect_out_hw NNIE process(process the 0-th segment) */
    forward_info.prev_seg_idx = 0;
    forward_info.proc_seg_idx = 0;
    forward_info.is_instant = HI_TRUE;
    ret = sample_common_svp_nnie_forward(&forward_info, HI_NULL, 1, &g_yolov1_nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_forward failed!\n");

    /*
     * print result, this sample has 20 classes:
     * class 0:plane          class 1:bicycle
     * class 2:bird           class 3:boat            class 4:bottle
     * class 5:bus            class 6:car             class 7:cat
     * class 8:chair          class 9:cow             class10:diningtable
     * class 11:dog           class12:horse           class13:motorbike
     * class 14:person        class15:pottedplant     class16:sheep
     * class 17:sofa          class18:train           class19:tvmonitor
     */
    sample_svp_trace_info("yolov1 result:\n");
    ret = sample_common_svp_nnie_print_hw_detect_result(&(g_yolov1_nnie_param.seg_data[0].dst[0]),
        SAMPLE_SVP_NNIE_YOLOV1_CLASS_NUM, HI_FALSE, print_result_thresh);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov1_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_print_hw_detect_result failed!\n");

yolov1_fail_0:
    sample_svp_nnie_yolov1_deinit(&g_yolov1_nnie_param, &g_yolov1_sw_param, &g_yolov1_model);
    return ret;
}

/* function : yolov2 software deinit */
static hi_s32 sample_svp_nnie_yolov2_sw_deinit(sample_svp_nnie_yolov2_sw_param *yolov2_sw_param)
{
    sample_svp_check_exps_return(yolov2_sw_param == HI_NULL, HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error, sw_param can't be HI_NULL!\n");
    if ((yolov2_sw_param->get_result_tmp_buf.phys_addr != 0) && (yolov2_sw_param->get_result_tmp_buf.virt_addr != 0)) {
        sample_svp_mmz_free(yolov2_sw_param->get_result_tmp_buf.phys_addr,
            yolov2_sw_param->get_result_tmp_buf.virt_addr);
        yolov2_sw_param->get_result_tmp_buf.phys_addr = 0;
        yolov2_sw_param->get_result_tmp_buf.virt_addr = 0;
        yolov2_sw_param->dst_roi.phys_addr = 0;
        yolov2_sw_param->dst_roi.virt_addr = 0;
        yolov2_sw_param->dst_score.phys_addr = 0;
        yolov2_sw_param->dst_score.virt_addr = 0;
        yolov2_sw_param->class_roi_num.phys_addr = 0;
        yolov2_sw_param->class_roi_num.virt_addr = 0;
    }
    return HI_SUCCESS;
}

/* function : yolov2 deinit */
static hi_s32 sample_svp_nnie_yolov2_deinit(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov2_sw_param *yolov2_sw_param, sample_svp_nnie_model *nnie_model)
{
    hi_s32 ret = HI_SUCCESS;
    /* hardware deinit */
    if (nnie_param != HI_NULL) {
        ret = sample_common_svp_nnie_param_deinit(nnie_param);
        sample_svp_check_exps_trace(ret != HI_SUCCESS, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_common_svp_nnie_param_deinit failed!\n");
    }
    /* software deinit */
    if (yolov2_sw_param != HI_NULL) {
        ret = sample_svp_nnie_yolov2_sw_deinit(yolov2_sw_param);
        sample_svp_check_exps_trace(ret != HI_SUCCESS, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_svp_nnie_yolov2_sw_deinit failed!\n");
    }
    /* model deinit */
    if (nnie_model != HI_NULL) {
        ret = sample_common_svp_nnie_unload_model(nnie_model);
        sample_svp_check_exps_trace(ret != HI_SUCCESS, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_common_svp_nnie_unload_model failed!\n");
    }
    return ret;
}

static hi_void sample_svp_nnie_yolov2_get_result_tmp_buf(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov2_sw_param *yolov2_sw_param, hi_u32 *total_size)
{
    hi_u32 total_grid_num = yolov2_sw_param->grid_num_height * yolov2_sw_param->grid_num_width;
    hi_u32 para_length = yolov2_sw_param->bbox_num_each_grid * (SAMPLE_SVP_NNIE_COORD_NUM + 1 +
        yolov2_sw_param->class_num);
    hi_u32 total_bbox_num = total_grid_num * yolov2_sw_param->bbox_num_each_grid;
    hi_u32 trans_size = total_grid_num * para_length * sizeof(hi_u32);
    hi_u32 bbox_assist_buf_size = total_bbox_num * sizeof(sample_svp_nnie_stack);
    hi_u32 bbox_buf_size = total_bbox_num * sizeof(sample_svp_nnie_yolov2_bbox);
    hi_u32 bbox_tmp_buf_size = total_grid_num * para_length * sizeof(hi_float);
    *total_size = trans_size + bbox_assist_buf_size + bbox_buf_size + bbox_tmp_buf_size;
}

static hi_s32 sample_svp_nnie_yolov2_sw_param_init(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov2_sw_param *yolov2_sw_param)
{
    hi_s32 ret;

    yolov2_sw_param->ori_img_height = nnie_param->seg_data[0].src[0].shape.whc.height;
    yolov2_sw_param->ori_img_width = nnie_param->seg_data[0].src[0].shape.whc.width;
    yolov2_sw_param->bbox_num_each_grid = SAMPLE_SVP_NNIE_YOLOV2_GRID_BBOX_NUM;
    yolov2_sw_param->class_num = SAMPLE_SVP_NNIE_YOLOV2_CLASS_NUM;
    yolov2_sw_param->grid_num_height = SAMPLE_SVP_NNIE_YOLOV2_GRID_NUM_IN_HEIGHT;
    yolov2_sw_param->grid_num_width = SAMPLE_SVP_NNIE_YOLOV2_GRID_NUM_IN_WIDTH;
    yolov2_sw_param->nms_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV2_NMS_THRESHOLD * SAMPLE_SVP_NNIE_QUANT_BASE);
    yolov2_sw_param->conf_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV2_CONF_THRESHOLD * SAMPLE_SVP_NNIE_QUANT_BASE);
    ret = memcpy_s(yolov2_sw_param->bias, sizeof(hi_u32) * SAMPLE_SVP_NNIE_YOLOV2_BIAS_NUM, g_yolov2_bias,
        sizeof(hi_u32) * SAMPLE_SVP_NNIE_YOLOV2_BIAS_NUM);
    sample_svp_check_exps_return(ret != EOK, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,memcpy_s yolov2_sw_param->bias failed!\n");
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_yolov2_sw_mem_init(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov2_sw_param *yolov2_sw_param)
{
    hi_s32 ret;
    hi_u32 class_num, bbox_num;
    hi_u32 total_size;
    hi_u32 dst_roi_size, dst_score_size, class_roi_num_size, tmp_buf_total_size;
    hi_phys_addr_t phys_addr;
    hi_u8 *virt_addr = HI_NULL;

    /* malloc assist buffer memory */
    class_num = yolov2_sw_param->class_num;
    bbox_num = yolov2_sw_param->bbox_num_each_grid * yolov2_sw_param->grid_num_height * yolov2_sw_param->grid_num_width;
    (hi_void)sample_svp_nnie_yolov2_get_result_tmp_buf(nnie_param, yolov2_sw_param, &tmp_buf_total_size);
    dst_roi_size = sample_svp_nnie_align_16(class_num * bbox_num * sizeof(hi_u32) * SAMPLE_SVP_NNIE_COORD_NUM);
    dst_score_size = sample_svp_nnie_align_16(class_num * bbox_num * sizeof(hi_u32));
    class_roi_num_size = sample_svp_nnie_align_16(class_num * sizeof(hi_u32));
    total_size = dst_roi_size + dst_score_size + class_roi_num_size + tmp_buf_total_size;
    ret = sample_common_svp_malloc_cached("yolov2_sw_init", HI_NULL, &phys_addr, (hi_void **)&virt_addr, total_size);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,malloc memory failed!\n");
    (hi_void)memset_s(virt_addr, total_size, 0, total_size);
    ret = sample_common_svp_flush_cache(phys_addr, (hi_void *)virt_addr, total_size);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,flush cache failed!\n");

    /* set each tmp buffer addr */
    yolov2_sw_param->get_result_tmp_buf.phys_addr = (hi_u64)phys_addr;
    yolov2_sw_param->get_result_tmp_buf.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr);
    yolov2_sw_param->get_result_tmp_buf.size = tmp_buf_total_size;

    /* set result blob */
    yolov2_sw_param->dst_roi.phys_addr = (hi_u64)phys_addr + tmp_buf_total_size;
    yolov2_sw_param->dst_roi.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr + tmp_buf_total_size);

    yolov2_sw_param->dst_score.phys_addr = (hi_u64)phys_addr + tmp_buf_total_size + dst_roi_size;
    yolov2_sw_param->dst_score.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr +
        tmp_buf_total_size + dst_roi_size);

    yolov2_sw_param->class_roi_num.phys_addr = (hi_u64)phys_addr + tmp_buf_total_size + dst_roi_size + dst_score_size;
    yolov2_sw_param->class_roi_num.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr +
        tmp_buf_total_size + dst_roi_size + dst_score_size);

    return ret;
}

static hi_s32 sample_svp_nnie_yolov2_sw_blob_init(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov2_sw_param *yolov2_sw_param)
{
    hi_u32 class_num, bbox_num;
    class_num = yolov2_sw_param->class_num;
    bbox_num = yolov2_sw_param->bbox_num_each_grid * yolov2_sw_param->grid_num_height * yolov2_sw_param->grid_num_width;

    /* set result blob */
    yolov2_sw_param->dst_roi.type = HI_SVP_BLOB_TYPE_S32;
    yolov2_sw_param->dst_roi.stride = sample_svp_nnie_align_16(class_num * bbox_num *
        sizeof(hi_u32) * SAMPLE_SVP_NNIE_COORD_NUM);
    yolov2_sw_param->dst_roi.num = 1;
    yolov2_sw_param->dst_roi.shape.whc.chn = 1;
    yolov2_sw_param->dst_roi.shape.whc.height = 1;
    yolov2_sw_param->dst_roi.shape.whc.width = class_num * bbox_num * SAMPLE_SVP_NNIE_COORD_NUM;

    yolov2_sw_param->dst_score.type = HI_SVP_BLOB_TYPE_S20Q12;
    yolov2_sw_param->dst_score.stride = sample_svp_nnie_align_16(class_num * bbox_num * sizeof(hi_u32));
    yolov2_sw_param->dst_score.num = 1;
    yolov2_sw_param->dst_score.shape.whc.chn = 1;
    yolov2_sw_param->dst_score.shape.whc.height = 1;
    yolov2_sw_param->dst_score.shape.whc.width = class_num * bbox_num;

    yolov2_sw_param->class_roi_num.type = HI_SVP_BLOB_TYPE_U32;
    yolov2_sw_param->class_roi_num.stride = sample_svp_nnie_align_16(class_num * sizeof(hi_u32));
    yolov2_sw_param->class_roi_num.num = 1;
    yolov2_sw_param->class_roi_num.shape.whc.chn = 1;
    yolov2_sw_param->class_roi_num.shape.whc.height = 1;
    yolov2_sw_param->class_roi_num.shape.whc.width = class_num;

    return HI_SUCCESS;
}

/* function : yolov2 software para init */
static hi_s32 sample_svp_nnie_yolov2_sw_init(sample_svp_nnie_cfg *cfg,
    sample_svp_nnie_param *nnie_param, sample_svp_nnie_yolov2_sw_param *yolov2_sw_param)
{
    hi_s32 ret;
    ret = sample_svp_nnie_yolov2_sw_param_init(nnie_param, yolov2_sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov2_sw_param_init failed!\n");

    ret = sample_svp_nnie_yolov2_sw_blob_init(nnie_param, yolov2_sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov2_sw_blob_init failed!\n");

    ret = sample_svp_nnie_yolov2_sw_mem_init(nnie_param, yolov2_sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov2_sw_mem_init failed!\n");

    return ret;
}

/* function : yolov1 init */
static hi_s32 sample_svp_nnie_yolov2_param_init(sample_svp_nnie_cfg *cfg,
    sample_svp_nnie_param *nnie_param, sample_svp_nnie_yolov2_sw_param *yolov2_sw_param)
{
    hi_s32 ret;
    /* init hardware para */
    ret = sample_common_svp_nnie_param_init(cfg, nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, init_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error(%#x),sample_common_svp_nnie_param_init failed!\n", ret);

    /* init software para */
    if (cfg->is_sw_gen_bbox == HI_TRUE) {
        ret = sample_svp_nnie_yolov2_sw_init(cfg, nnie_param, yolov2_sw_param);
        sample_svp_check_exps_goto(ret != HI_SUCCESS, init_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error(%#x),sample_svp_nnie_yolov2_sw_init failed!\n", ret);
    }

    return ret;
init_fail_0:
    ret = sample_svp_nnie_yolov2_deinit(nnie_param, yolov2_sw_param, HI_NULL);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error(%#x),sample_svp_nnie_yolov2_deinit failed!\n", ret);
    return HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
}

/* function : show YOLOV2 sample(image 416x416 U8_C3) */
static hi_s32 sample_svp_nnie_yolov2_detect_out_sw_proc(const hi_char *src_file, const hi_char *model_file)
{
    hi_float print_result_thresh;
    hi_s32 ret;
    sample_svp_nnie_cfg nnie_cfg;
    sample_svp_nnie_forward_info forward_info;

    /* set configuration parameter */
    (hi_void)memset_s(&nnie_cfg, sizeof(sample_svp_nnie_cfg), 0, sizeof(sample_svp_nnie_cfg));
    print_result_thresh = SAMPLE_SVP_NNIE_YOLOV2_CONF_THRESHOLD;
    nnie_cfg.max_input_num = 1;
    nnie_cfg.max_roi_num = 0;
    nnie_cfg.nnie_core_id[0] = HI_SVP_NNIE_ID_0;
    nnie_cfg.is_sw_gen_bbox = HI_TRUE;

    /* yolov2_detect_out_sw load model */
    sample_svp_trace_info("yolov2 load model!\n");
    ret = sample_common_svp_nnie_load_model(model_file, &g_yolov2_model);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_load_model failed!\n");

    /*
     * yolov2_detect_out_sw parameter initialization:
     * yolov2_detect_out_sw software parameters are set in sample_svp_nnie_yolov2_sw_init,
     * if user has changed net struct, please make sure the parameter settings in
     * sample_svp_nnie_yolov2_sw_init function are correct
     */
    sample_svp_trace_info("yolov2 parameter initialization!\n");
    g_yolov2_nnie_param.model = &(g_yolov2_model.model);
    ret = sample_svp_nnie_yolov2_param_init(&nnie_cfg, &g_yolov2_nnie_param, &g_yolov2_sw_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov2_param_init failed!\n");

    /* yolov2_detect_out_sw fill src data */
    sample_svp_trace_info("yolov2 start!\n");
    ret = sample_common_svp_nnie_fill_src_data(src_file, 0, 0, &g_yolov2_nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_fill_src_data failed!\n");

    /* yolov2_detect_out_sw NNIE process(process the 0-th segment) */
    forward_info.prev_seg_idx = 0;
    forward_info.proc_seg_idx = 0;
    forward_info.is_instant = HI_TRUE;
    ret = sample_common_svp_nnie_forward(&forward_info, HI_NULL, 0, &g_yolov2_nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_forward failed!\n");

    /*
     * yolov2_detect_out_sw software process:
     * if user has changed net struct, please make sure sample_svp_nnie_yolov2_get_result
     * function input datas are correct
     */
    ret = sample_svp_nnie_yolov2_get_result(&g_yolov2_nnie_param, &g_yolov2_sw_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov2_get_result failed!\n");

    /*
     * print result, this sample has 5 classes:
     * class 0:carclass       class 1:vanclass
     * class 2:truckclass     class 3:pedestrianclass    class 4:cyclist
     */
    sample_svp_trace_info("yolov2 result:\n");
    ret = sample_common_svp_nnie_print_sw_detect_result(&(g_yolov2_sw_param.dst_score),
        &(g_yolov2_sw_param.dst_roi), &(g_yolov2_sw_param.class_roi_num), HI_FALSE, print_result_thresh);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_print_sw_detect_result failed!\n");

yolov2_fail_0:
    sample_svp_nnie_yolov2_deinit(&g_yolov2_nnie_param, &g_yolov2_sw_param, &g_yolov2_model);
    return ret;
}

/* function : show YOLOV2 sample(image 416x416 U8_C3) */
static hi_s32 sample_svp_nnie_yolov2_detect_out_hw_proc(const char *src_file, const hi_char *model_file)
{
    hi_float print_result_thresh;
    hi_s32 ret;
    sample_svp_nnie_cfg nnie_cfg;
    sample_svp_nnie_forward_info forward_info;

    /* set configuration parameter */
    (hi_void)memset_s(&nnie_cfg, sizeof(sample_svp_nnie_cfg), 0, sizeof(sample_svp_nnie_cfg));
    print_result_thresh = SAMPLE_SVP_NNIE_YOLOV2_CONF_THRESHOLD;
    nnie_cfg.max_input_num = 1;
    nnie_cfg.max_roi_num = 0;
    nnie_cfg.nnie_core_id[0] = HI_SVP_NNIE_ID_0;
    /* set detection out layer's threshold */
    nnie_cfg.threshold_num[0] = 1;
    nnie_cfg.threshold[0][0].min_width = (hi_u32)(0 * SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.threshold[0][0].min_height = (hi_u32)(0 * SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.threshold[0][0].nms_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV2_NMS_THRESHOLD *
        SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.threshold[0][0].score_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV2_CONF_THRESHOLD *
        SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.is_sw_gen_bbox = HI_FALSE;

    /* yolov2_detect_out_hw load model */
    sample_svp_trace_info("yolov2 load model!\n");
    ret = sample_common_svp_nnie_load_model(model_file, &g_yolov2_model);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_load_model failed!\n");

    /* yolov2_detect_out_hw parameter initialization */
    sample_svp_trace_info("yolov2 parameter initialization!\n");
    g_yolov2_nnie_param.model = &(g_yolov2_model.model);
    ret = sample_svp_nnie_yolov2_param_init(&nnie_cfg, &g_yolov2_nnie_param, &g_yolov2_sw_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov2_param_init failed!\n");

    /* yolov2_detect_out_hw fill src data */
    sample_svp_trace_info("yolov2 start!\n");
    ret = sample_common_svp_nnie_fill_src_data(src_file, 0, 0, &g_yolov2_nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_fill_src_data failed!\n");

    /* yolov2_detect_out_hw NNIE process(process the 0-th segment) */
    forward_info.prev_seg_idx = 0;
    forward_info.proc_seg_idx = 0;
    forward_info.is_instant = HI_TRUE;
    ret = sample_common_svp_nnie_forward(&forward_info, HI_NULL, 0, &g_yolov2_nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_forward failed!\n");

    /* print result, this sample has 5 classes:
     class 0:carclass       class 1:vanclass
     class 2:truckclass     class 3:pedestrianclass    class 4:cyclist */
    sample_svp_trace_info("yolov2 result:\n");
    ret = sample_common_svp_nnie_print_hw_detect_result(&(g_yolov2_nnie_param.seg_data[0].dst[0]),
        SAMPLE_SVP_NNIE_YOLOV2_CLASS_NUM, HI_FALSE, print_result_thresh);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov2_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_print_hw_detect_result failed!\n");

yolov2_fail_0:
    sample_svp_nnie_yolov2_deinit(&g_yolov2_nnie_param, &g_yolov2_sw_param, &g_yolov2_model);
    return ret;
}

/* function: yolov3 software deinit */
static hi_s32 sample_svp_nnie_yolov3_sw_deinit(sample_svp_nnie_yolov3_sw_param *yolov3_sw_param)
{
    hi_s32 ret = HI_SUCCESS;
    sample_svp_check_exps_return(yolov3_sw_param == HI_NULL, HI_ERR_SVP_NNIE_NULL_PTR, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error, sw_param can't be HI_NULL!\n");
    if ((yolov3_sw_param->get_result_tmp_buf.phys_addr != 0) && (yolov3_sw_param->get_result_tmp_buf.virt_addr != 0)) {
        sample_svp_mmz_free(yolov3_sw_param->get_result_tmp_buf.phys_addr,
            yolov3_sw_param->get_result_tmp_buf.virt_addr);
        yolov3_sw_param->get_result_tmp_buf.phys_addr = 0;
        yolov3_sw_param->get_result_tmp_buf.virt_addr = 0;
        yolov3_sw_param->dst_roi.phys_addr = 0;
        yolov3_sw_param->dst_roi.virt_addr = 0;
        yolov3_sw_param->dst_score.phys_addr = 0;
        yolov3_sw_param->dst_score.virt_addr = 0;
        yolov3_sw_param->class_roi_num.phys_addr = 0;
        yolov3_sw_param->class_roi_num.virt_addr = 0;
    }
    return ret;
}

/* function: yolov3 deinit */
static hi_s32 sample_svp_nnie_yolov3_deinit(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov3_sw_param *yolov3_sw_param, sample_svp_nnie_model *nnie_model)
{
    hi_s32 ret = HI_SUCCESS;
    /* hardware deinit */
    if (nnie_param != HI_NULL) {
        ret = sample_common_svp_nnie_param_deinit(nnie_param);
        sample_svp_check_exps_trace(ret != HI_SUCCESS, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_common_svp_nnie_param_deinit failed!\n");
    }
    /* software deinit */
    if (yolov3_sw_param != HI_NULL) {
        ret = sample_svp_nnie_yolov3_sw_deinit(yolov3_sw_param);
        sample_svp_check_exps_trace(ret != HI_SUCCESS, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_svp_nnie_yolov3_sw_deinit failed!\n");
    }
    /* model deinit */
    if (nnie_model != HI_NULL) {
        ret = sample_common_svp_nnie_unload_model(nnie_model);
        sample_svp_check_exps_trace(ret != HI_SUCCESS, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,sample_common_svp_nnie_unload_model failed!\n");
    }
    return ret;
}

static hi_void sample_svp_nnie_yolov3_get_result_tmp_buf(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov3_sw_param *yolov3_sw_param, hi_u32 *total_size)
{
    hi_u32 assist_stack_size;
    hi_u32 total_bbox_num = 0;
    hi_u32 total_bbox_size;
    hi_u32 dst_blob_size;
    hi_u32 max_blob_size = 0;
    hi_u32 i;

    for (i = 0; i < nnie_param->model->seg[0].dst_num; i++) {
        dst_blob_size = nnie_param->model->seg[0].dst_node[i].shape.whc.width * sizeof(hi_u32) *
            nnie_param->model->seg[0].dst_node[i].shape.whc.height *
            nnie_param->model->seg[0].dst_node[i].shape.whc.chn;
        if (max_blob_size < dst_blob_size) {
            max_blob_size = dst_blob_size;
        }
        total_bbox_num += yolov3_sw_param->grid_num_width[i] * yolov3_sw_param->grid_num_height[i] *
            yolov3_sw_param->bbox_num_each_grid;
    }
    assist_stack_size = total_bbox_num * sizeof(sample_svp_nnie_stack);
    total_bbox_size = total_bbox_num * sizeof(sample_svp_nnie_yolov3_bbox);
    *total_size = (max_blob_size + assist_stack_size + total_bbox_size);
}

static hi_s32 sample_svp_nnie_yolov3_sw_param_init(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov3_sw_param *yolov3_sw_param)
{
    hi_u32 i;
    hi_s32 ret;

    yolov3_sw_param->ori_img_height = nnie_param->seg_data[0].src[0].shape.whc.height;
    yolov3_sw_param->ori_img_width = nnie_param->seg_data[0].src[0].shape.whc.width;
    yolov3_sw_param->bbox_num_each_grid = SAMPLE_SVP_NNIE_YOLOV3_GRID_BBOX_NUM;
    yolov3_sw_param->class_num = SAMPLE_SVP_NNIE_YOLOV3_CLASS_NUM;
    yolov3_sw_param->nms_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV3_NMS_THRESHOLD * SAMPLE_SVP_NNIE_QUANT_BASE);
    yolov3_sw_param->conf_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV3_CONF_THRESHOLD * SAMPLE_SVP_NNIE_QUANT_BASE);
    ret = memcpy_s(yolov3_sw_param->grid_num_height, sizeof(hi_u32) * SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM,
        g_yolov3_grid_num_in_height, sizeof(hi_u32) * SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM);
    sample_svp_check_exps_return(ret != EOK, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,memcpy_s yolov3_sw_param->grid_num_height[] failed!\n");
    ret = memcpy_s(yolov3_sw_param->grid_num_width, sizeof(hi_u32) * SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM,
        g_yolov3_grid_num_in_width, sizeof(hi_u32) * SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM);
    sample_svp_check_exps_return(ret != EOK, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,memcpy_s yolov3_sw_param->grid_num_width[] failed!\n");
    for (i = 0; i < SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM; i++) {
        ret = memcpy_s(yolov3_sw_param->bias[i], sizeof(hi_u32) * SAMPLE_SVP_NNIE_YOLOV3_BIAS_NUM,
            g_yolov3_bias[i], sizeof(hi_u32) * SAMPLE_SVP_NNIE_YOLOV3_BIAS_NUM);
        sample_svp_check_exps_return(ret != EOK, HI_ERR_SVP_NNIE_ILLEGAL_PARAM, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error,memcpy_s yolov3_sw_param->bias[] failed!\n");
    }
    return HI_SUCCESS;
}

static hi_s32 sample_svp_nnie_yolov3_sw_mem_init(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov3_sw_param *yolov3_sw_param)
{
    hi_s32 ret = HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
    hi_u32 i, class_num;
    hi_u32 total_size;
    hi_u32 dst_roi_size, dst_score_size, class_roi_num_size, tmp_buf_total_size;
    hi_phys_addr_t phys_addr;
    hi_u8 *virt_addr = HI_NULL;
    hi_u32 bbox_num = 0;

    /* malloc assist buffer memory */
    class_num = yolov3_sw_param->class_num;
    for (i = 0; i < nnie_param->model->seg[0].dst_num; i++) {
        bbox_num += yolov3_sw_param->grid_num_width[i] * yolov3_sw_param->grid_num_height[i] *
            yolov3_sw_param->bbox_num_each_grid;
    }

    sample_svp_check_exps_return(SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM != nnie_param->model->seg[0].dst_num,
        ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,nnie_param->model->seg[0].dst_num(%u) should be %u!\n",
        nnie_param->model->seg[0].dst_num, SAMPLE_SVP_NNIE_YOLOV3_REPORT_BLOB_NUM);
    (hi_void)sample_svp_nnie_yolov3_get_result_tmp_buf(nnie_param, yolov3_sw_param, &tmp_buf_total_size);
    dst_roi_size = sample_svp_nnie_align_16(class_num * bbox_num * sizeof(hi_u32) * SAMPLE_SVP_NNIE_COORD_NUM);
    dst_score_size = sample_svp_nnie_align_16(class_num * bbox_num * sizeof(hi_u32));
    class_roi_num_size = sample_svp_nnie_align_16(class_num * sizeof(hi_u32));
    total_size = dst_roi_size + dst_score_size + class_roi_num_size + tmp_buf_total_size;
    ret = sample_common_svp_malloc_cached("yolov3_sw_init", HI_NULL, &phys_addr, (hi_void **)&virt_addr, total_size);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,malloc memory failed!\n");
    (hi_void)memset_s(virt_addr, total_size, 0, total_size);
    ret = sample_common_svp_flush_cache(phys_addr, (hi_void *)virt_addr, total_size);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR, "Error,flush cache failed!\n");

    /* set each tmp buffer addr */
    yolov3_sw_param->get_result_tmp_buf.phys_addr = (hi_u64)phys_addr;
    yolov3_sw_param->get_result_tmp_buf.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr);
    yolov3_sw_param->get_result_tmp_buf.size = tmp_buf_total_size;

    /* set result blob */
    yolov3_sw_param->dst_roi.phys_addr = (hi_u64)phys_addr + tmp_buf_total_size;
    yolov3_sw_param->dst_roi.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr + tmp_buf_total_size);

    yolov3_sw_param->dst_score.phys_addr = (hi_u64)phys_addr + tmp_buf_total_size + dst_roi_size;
    yolov3_sw_param->dst_score.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr +
        tmp_buf_total_size + dst_roi_size);

    yolov3_sw_param->class_roi_num.phys_addr = (hi_u64)phys_addr + tmp_buf_total_size + dst_roi_size + dst_score_size;
    yolov3_sw_param->class_roi_num.virt_addr = sample_svp_convert_ptr_to_addr(hi_u64, virt_addr +
        tmp_buf_total_size + dst_roi_size + dst_score_size);

    return ret;
}

static hi_s32 sample_svp_nnie_yolov3_sw_blob_init(sample_svp_nnie_param *nnie_param,
    sample_svp_nnie_yolov3_sw_param *yolov3_sw_param)
{
    hi_u32 i, class_num;
    hi_u32 bbox_num = 0;
    class_num = yolov3_sw_param->class_num;

    for (i = 0; i < nnie_param->model->seg[0].dst_num; i++) {
        bbox_num += yolov3_sw_param->grid_num_width[i] * yolov3_sw_param->grid_num_height[i] *
            yolov3_sw_param->bbox_num_each_grid;
    }

    /* set result blob */
    yolov3_sw_param->dst_roi.type = HI_SVP_BLOB_TYPE_S32;
    yolov3_sw_param->dst_roi.stride = sample_svp_nnie_align_16(class_num * bbox_num *
        sizeof(hi_u32) * SAMPLE_SVP_NNIE_COORD_NUM);
    yolov3_sw_param->dst_roi.num = 1;
    yolov3_sw_param->dst_roi.shape.whc.chn = 1;
    yolov3_sw_param->dst_roi.shape.whc.height = 1;
    yolov3_sw_param->dst_roi.shape.whc.width = class_num * bbox_num * SAMPLE_SVP_NNIE_COORD_NUM;

    yolov3_sw_param->dst_score.type = HI_SVP_BLOB_TYPE_S20Q12;
    yolov3_sw_param->dst_score.stride = sample_svp_nnie_align_16(class_num * bbox_num * sizeof(hi_u32));
    yolov3_sw_param->dst_score.num = 1;
    yolov3_sw_param->dst_score.shape.whc.chn = 1;
    yolov3_sw_param->dst_score.shape.whc.height = 1;
    yolov3_sw_param->dst_score.shape.whc.width = class_num * bbox_num;

    yolov3_sw_param->class_roi_num.type = HI_SVP_BLOB_TYPE_U32;
    yolov3_sw_param->class_roi_num.stride = sample_svp_nnie_align_16(class_num * sizeof(hi_u32));
    yolov3_sw_param->class_roi_num.num = 1;
    yolov3_sw_param->class_roi_num.shape.whc.chn = 1;
    yolov3_sw_param->class_roi_num.shape.whc.height = 1;
    yolov3_sw_param->class_roi_num.shape.whc.width = class_num;

    return HI_SUCCESS;
}

/* function : yolov3 software para init */
static hi_s32 sample_svp_nnie_yolov3_sw_init(sample_svp_nnie_cfg *cfg,
    sample_svp_nnie_param *nnie_param, sample_svp_nnie_yolov3_sw_param *yolov3_sw_param)
{
    hi_s32 ret;
    ret = sample_svp_nnie_yolov3_sw_param_init(nnie_param, yolov3_sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov3_sw_param_init failed!\n");

    ret = sample_svp_nnie_yolov3_sw_blob_init(nnie_param, yolov3_sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov3_sw_blob_init failed!\n");

    ret = sample_svp_nnie_yolov3_sw_mem_init(nnie_param, yolov3_sw_param);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov3_sw_mem_init failed!\n");

    return ret;
}

/* function: yolov3 init */
static hi_s32 sample_svp_nnie_yolov3_param_init(sample_svp_nnie_cfg *cfg,
    sample_svp_nnie_param *nnie_param, sample_svp_nnie_yolov3_sw_param *yolov3_sw_param)
{
    hi_s32 ret;
    /* init hardware para */
    ret = sample_common_svp_nnie_param_init(cfg, nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, init_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error(%#x),sample_common_svp_nnie_param_init failed!\n", ret);

    /* init software para */
    if (cfg->is_sw_gen_bbox == HI_TRUE) {
        ret = sample_svp_nnie_yolov3_sw_init(cfg, nnie_param, yolov3_sw_param);
        sample_svp_check_exps_goto(ret != HI_SUCCESS, init_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
            "Error(%#x),sample_svp_nnie_yolov3_sw_init failed!\n", ret);
    }

    return ret;
init_fail_0:
    ret = sample_svp_nnie_yolov3_deinit(nnie_param, yolov3_sw_param, HI_NULL);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error(%#x),sample_svp_nnie_yolov3_deinit failed!\n", ret);
    return HI_ERR_SVP_NNIE_ILLEGAL_PARAM;
}





//////////////////////////////////////////////////////////////////////////
#include "sample_comm.h"
#include "loadbmp.h"
#define SAMPLE_VGS_BITMAP_PATH "./alan.bmp"

#define SAMPLE_SVP_NNIE_RECT_THICK        2
#define SAMPLE_SVP_NNIE_RECT_COLOR        0x0000FF00
#define SAMPLE_SVP_NNIE_FRAME_WAIT_TIME   20000

static sample_vi_config g_yolov3_vi_config = {0};
static hi_sample_svp_switch g_yolov3_switch = { HI_FALSE, HI_TRUE };


float width_scale = 0.0f;
float height_scale = 0.0f;

typedef enum {
    SAMPLE_VGS_OSD_NORM = 0,
    SAMPLE_VGS_OSD_CLUT2,
    SAMPLE_VGS_OSD_CLUT4,
    SAMPLE_VGS_OSD_BUTT
} sample_vgs_osd_type;

typedef struct {
    hi_bool fill_en;
    hi_u32 fill_color;
    hi_size osd_size;
    hi_u32 stride;
    hi_pixel_format img_pixel_format;
} sample_vgs_osd_load_bmp_info;


int people_count = 0;
PersonBox personBoxes[MAX_PEOPLE] = {0};
//////////////////////////////////////////////////////////////////////////


void yuvI420ToNV21(hi_u8* i420Src, hi_u8* nv21Src, int width, int height)
{
    hi_u8 *src_i420_data = i420Src;
    hi_u8 *src_nv21_data = nv21Src;

    int src_y_size = width * height;
    int src_u_size = (width >> 1) * (height >> 1);

    hi_u8 *src_i420_y_data = src_i420_data;
    hi_u8 *src_i420_u_data = src_i420_data + src_y_size;
    hi_u8 *src_i420_v_data = src_i420_data + src_y_size + src_u_size;

    hi_u8 *src_nv21_y_data = src_nv21_data;
    hi_u8 *src_nv21_vu_data = src_nv21_data + src_y_size;


    libyuv::I420ToNV21(
               (const hi_u8 *) src_i420_y_data, width,
               (const hi_u8 *) src_i420_u_data, width >> 1,
               (const hi_u8 *) src_i420_v_data, width >> 1,
               (hi_u8 *) src_nv21_y_data, width,
               (hi_u8 *) src_nv21_vu_data, width,
               width, height);
}

void nv21ToI420(hi_u8* src_nv21_data, hi_u16 width, hi_u16 height, hi_u8 *src_i420_data)
{
    int src_y_size = width * height;
    int src_u_size = (width >> 1) * (height >> 1);

    hi_u8 *src_nv21_y_data = src_nv21_data;
    hi_u8 *src_nv21_vu_data = src_nv21_data + src_y_size;

    hi_u8 *src_i420_y_data = src_i420_data;
    hi_u8 *src_i420_u_data = src_i420_data + src_y_size;
    hi_u8 *src_i420_v_data = src_i420_data + src_y_size + src_u_size;


    libyuv::NV21ToI420((const hi_u8 *) src_nv21_y_data, width,
               (const hi_u8 *) src_nv21_vu_data, width,
               (hi_u8 *) src_i420_y_data, width,
               (hi_u8 *) src_i420_u_data, width >> 1,
               (hi_u8 *) src_i420_v_data, width >> 1,
               width, height);
}

void scaleI420(hi_u8 *src_i420_data, int width, int height, hi_u8 *dst_i420_data,
               int dst_width, int dst_height, int mode)
{

    int src_i420_y_size = width * height;
    int src_i420_u_size = (width >> 1) * (height >> 1);
    hi_u8 *src_i420_y_data = src_i420_data;
    hi_u8 *src_i420_u_data = src_i420_data + src_i420_y_size;
    hi_u8 *src_i420_v_data = src_i420_data + src_i420_y_size + src_i420_u_size;

    int dst_i420_y_size = dst_width * dst_height;
    int dst_i420_u_size = (dst_width >> 1) * (dst_height >> 1);
    hi_u8 *dst_i420_y_data = dst_i420_data;
    hi_u8 *dst_i420_u_data = dst_i420_data + dst_i420_y_size;
    hi_u8 *dst_i420_v_data = dst_i420_data + dst_i420_y_size + dst_i420_u_size;

    libyuv::I420Scale((const hi_u8 *) src_i420_y_data, width,
              (const hi_u8 *) src_i420_u_data, width >> 1,
              (const hi_u8 *) src_i420_v_data, width >> 1,
              width, height,
              (hi_u8 *) dst_i420_y_data, dst_width,
              (hi_u8 *) dst_i420_u_data, dst_width >> 1,
              (hi_u8 *) dst_i420_v_data, dst_width >> 1,
              dst_width, dst_height,
              (libyuv::FilterMode) mode);
}

void yuv420sp_to_bgr_planner(unsigned char* src, unsigned char* dst, int s_w, int s_h, int d_w, int d_h, int channels)
{
    if(!src || !dst) {
        printf("[%s] [%d], params NULL error !", __func__, __LINE__);
        return;
    }

    hi_u8* i420_data     = malloc(s_w*s_h*channels);
    hi_u8* scaled_i420_data = malloc(d_w*d_h*channels);
    hi_u8* rgb_buff = malloc(d_w*d_h*channels);

    if(!i420_data || !scaled_i420_data || !rgb_buff)
        goto out;

    nv21ToI420(src, s_w, s_h, i420_data);

    scaleI420(i420_data, s_w, s_h, scaled_i420_data, d_w, d_h, 0);

    hi_u8* i420_image_y_ptr = scaled_i420_data;
    hi_u8* i420_image_u_ptr = i420_image_y_ptr + (d_w * d_h);
    hi_u8* i420_image_v_ptr = i420_image_u_ptr + (int)(d_w * d_h * 0.25);

    libyuv::I420ToRGB24(i420_image_y_ptr, d_w,
                        i420_image_u_ptr, (d_w >> 1),
                        i420_image_v_ptr, (d_w >> 1),
                        rgb_buff, (d_w*3),
                        d_w, d_h);

    int b = 0, g = d_w*d_h, r = d_w*d_h*2;
    for(int i = 0; i < d_w*d_h*3; i += 3) {
        dst[r++] = rgb_buff[i];
        dst[g++] = rgb_buff[i+1];
        dst[b++] = rgb_buff[i+2];
    }

 out:
    if(i420_data)
        free(i420_data);
    if(scaled_i420_data)
        free(scaled_i420_data);
    if(rgb_buff)
        free(rgb_buff);
}

void fill_rect(hi_sample_svp_rect* rect, int count)
{
    if(!rect) {
        printf("rect NULL error \n");
        return;
    }

    hi_u32 x_min, y_min;
    hi_u32 x_max, y_max;

    for(int i = 0; i < count; i++) {
        x_min = hi_u32(((float)personBoxes[i].x_min)/width_scale);
        y_min = hi_u32(((float)personBoxes[i].y_min)/height_scale);
        x_max = hi_u32(((float)personBoxes[i].x_max)/width_scale);
        y_max = hi_u32(((float)personBoxes[i].y_max)/height_scale);
        rect[i].point[SAMPLE_SVP_NNIE_RECT_LEFT_TOP].x = x_min & (~1);
        rect[i].point[SAMPLE_SVP_NNIE_RECT_LEFT_TOP].y = y_min & (~1);
        rect[i].point[SAMPLE_SVP_NNIE_RECT_RIGHT_TOP].x = x_max & (~1);
        rect[i].point[SAMPLE_SVP_NNIE_RECT_RIGHT_TOP].y = y_min & (~1);
        rect[i].point[SAMPLE_SVP_NNIE_RECT_RIGHT_BOTTOM].x = x_max & (~1);
        rect[i].point[SAMPLE_SVP_NNIE_RECT_RIGHT_BOTTOM].y = y_max & (~1);
        rect[i].point[SAMPLE_SVP_NNIE_RECT_LEFT_BOTTOM].x = x_min & (~1);
        rect[i].point[SAMPLE_SVP_NNIE_RECT_LEFT_BOTTOM].y = y_max & (~1);
    }
}

static hi_void sample_vgs_case2_set_osd_stat(hi_vgs_osd *vgs_add_osd, hi_u32 max_osd_cnt,
                                             hi_rgn_handle *rgn_handle, hi_u32 handle_cnt)
{
    hi_u32 i;

    for (i = 0; i < max_osd_cnt && i < handle_cnt; i++) {
        vgs_add_osd[i].rect.x = 20;
        vgs_add_osd[i].rect.y = 20;
        vgs_add_osd[i].rect.width = 500;
        vgs_add_osd[i].rect.height = 200;
        vgs_add_osd[i].bg_color = 0x0;
        vgs_add_osd[i].pixel_format = HI_PIXEL_FORMAT_ARGB_CLUT2;
        vgs_add_osd[i].phys_addr = 0;
        vgs_add_osd[i].stride = 0;
        vgs_add_osd[i].bg_alpha = 255;
        vgs_add_osd[i].fg_alpha = 128;
        rgn_handle[i] = i;
        switch (i) {
            case SAMPLE_VGS_OSD_NORM:
                vgs_add_osd[i].rect.width = 500;
                vgs_add_osd[i].rect.height = 200;
                vgs_add_osd[i].bg_color = 0xFF0000;
                vgs_add_osd[i].pixel_format = HI_PIXEL_FORMAT_ARGB_8888;
                break;
            case SAMPLE_VGS_OSD_CLUT2:
                vgs_add_osd[i].rect.width = 256;
                vgs_add_osd[i].rect.height = 200;
                vgs_add_osd[i].bg_color = 0x0;
                vgs_add_osd[i].pixel_format = HI_PIXEL_FORMAT_ARGB_CLUT2;
                break;
            case SAMPLE_VGS_OSD_CLUT4:
                vgs_add_osd[i].rect.width = 256;
                vgs_add_osd[i].rect.height = 200;
                vgs_add_osd[i].bg_color = 0x0;
                vgs_add_osd[i].pixel_format = HI_PIXEL_FORMAT_ARGB_CLUT4;
                break;
            default:
                printf("OSD type error!");
                break;
        }
    }
}

static hi_s32 sample_vgs_set_color_format(hi_pixel_format pixel_format, osd_surface *surface)
{
    if (HI_PIXEL_FORMAT_ARGB_1555 == pixel_format) {
        surface->color_format = OSD_COLOR_FORMAT_RGB1555;
    } else if (HI_PIXEL_FORMAT_ARGB_4444 == pixel_format) {
        surface->color_format = OSD_COLOR_FORMAT_RGB4444;
    } else if (HI_PIXEL_FORMAT_ARGB_8888 == pixel_format) {
        surface->color_format = OSD_COLOR_FORMAT_RGB8888;
    } else {
        SAMPLE_PRT("pixel format is not support!\n");
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

static hi_s32 sample_vgs_load_bmp(const hi_char *sz_file_name, hi_bmp *bitmap,
                                  const sample_vgs_osd_load_bmp_info *load_info)
{
    osd_surface surface;
    osd_bit_map_file_header bmp_file_header;
    osd_bit_map_info bmp_info;
    hi_u32 i, j;
    hi_u16 *temp = HI_NULL;
    canvas_size_info canvas_size;

    canvas_size.height = load_info->osd_size.height;
    canvas_size.width = load_info->osd_size.width;
    canvas_size.stride = load_info->stride;

    if (get_bmp_info(sz_file_name, &bmp_file_header, &bmp_info) < 0) {
        SAMPLE_PRT("get_bmp_info err!\n");
        return HI_FAILURE;
    }

    if (bitmap->data == HI_NULL) {
        SAMPLE_PRT("bitmap's data is null!\n");
        return HI_FAILURE;
    }

    if (sample_vgs_set_color_format(load_info->img_pixel_format, &surface) < 0) {
        SAMPLE_PRT("pixel format is not support!\n");
        return HI_FAILURE;
    }

    if (create_surface_by_canvas(sz_file_name, &surface, (hi_u8*)bitmap->data, &canvas_size)) {
        return HI_FAILURE;
    }

    bitmap->width = surface.width;
    bitmap->height = surface.height;
    bitmap->pixel_format = load_info->img_pixel_format;

    temp = (hi_u16*)bitmap->data;

    if (load_info->fill_en != HI_TRUE) {
        return HI_SUCCESS;
    }

    for (i = 0; i < bitmap->height; ++i) {
        for (j = 0; j < bitmap->width; ++j) {
            if (load_info->fill_color == *temp) {
                *temp &= 0x7FFF;
            }
            temp++;
        }
    }

    return HI_SUCCESS;
}

static hi_s32 sample_vgs_prepare_osd_info(hi_vgs_osd *vgs_add_osd, hi_rgn_handle *rgn_handle)
{
    hi_s32 ret;

    hi_rgn_attr rgn_attr;
    hi_rgn_canvas_info rgn_canvas_info;
    hi_bmp bitmap;
    sample_vgs_osd_load_bmp_info load_info = {0};

    rgn_attr.type = HI_RGN_OVERLAYEX;
    rgn_attr.attr.overlayex.pixel_format = vgs_add_osd->pixel_format;
    rgn_attr.attr.overlayex.bg_color = vgs_add_osd->bg_color;
    rgn_attr.attr.overlayex.size.width = vgs_add_osd->rect.width;
    rgn_attr.attr.overlayex.size.height = vgs_add_osd->rect.height;
    rgn_attr.attr.overlayex.canvas_num = 2;

    ret = hi_mpi_rgn_create(*rgn_handle, &rgn_attr);
    ret = hi_mpi_rgn_get_canvas_info(*rgn_handle, &rgn_canvas_info);
    if (ret != HI_SUCCESS) {
        printf("[%s] [%d], error \n", __func__, __LINE__);
        return ret;
    }

    bitmap.data = rgn_canvas_info.virt_addr;
    load_info.fill_en = HI_FALSE;
    load_info.fill_color = 0x0;
    load_info.osd_size.width = vgs_add_osd->rect.width;
    load_info.osd_size.height = vgs_add_osd->rect.height;
    load_info.stride = rgn_canvas_info.stride;
    load_info.img_pixel_format = vgs_add_osd->pixel_format;

    ret = sample_vgs_load_bmp(SAMPLE_VGS_BITMAP_PATH, &bitmap, &load_info);
    if (ret != HI_SUCCESS) {
        SAMPLE_PRT("sample_vgs_load_bmp failed, ret:0x%x", ret);
        return ret;
    }
    ret = hi_mpi_rgn_update_canvas(*rgn_handle);
    if (ret != HI_SUCCESS) {
        SAMPLE_PRT("hi_mpi_rgn_update_canvas failed, ret:0x%x", ret);
        return ret;
    }

    vgs_add_osd->phys_addr = rgn_canvas_info.phys_addr;
    vgs_add_osd->stride = rgn_canvas_info.stride;

    return ret;
}

static hi_s32 sample_vgs_add_osd_task(hi_vgs_handle h_handle,
                                      hi_vgs_task_attr *vgs_task_attr,
                                      hi_rgn_handle* rgn_handle,
                                      hi_vgs_osd* vgs_add_osd)
{
    hi_s32 ret;

    ret = sample_vgs_prepare_osd_info(&vgs_add_osd[SAMPLE_VGS_OSD_NORM],
                                      &rgn_handle[SAMPLE_VGS_OSD_NORM]);
    if (ret != HI_SUCCESS) {
        printf("[%s] [%d], error \n", __func__, __LINE__);
        return ret;
    }

    ret = hi_mpi_vgs_add_osd_task(h_handle, vgs_task_attr, vgs_add_osd, 1);
    if (ret != HI_SUCCESS) {
        printf("[%s] [%d], error \n", __func__, __LINE__);
        return ret;
    }

    return HI_SUCCESS;
}

hi_s32 frame_overlay(hi_video_frame_info* frame_info,
                     hi_vgs_handle handle,
                     hi_vgs_task_attr* vgs_task)
{
    hi_rgn_handle rgn_handle[SAMPLE_VGS_OSD_BUTT];
    hi_vgs_osd vgs_add_osd[SAMPLE_VGS_OSD_BUTT];

    sample_vgs_case2_set_osd_stat(vgs_add_osd, SAMPLE_VGS_OSD_BUTT, rgn_handle, SAMPLE_VGS_OSD_BUTT);
    sample_vgs_add_osd_task(handle, vgs_task, rgn_handle, vgs_add_osd);
}

hi_s32 frame_cover_box(hi_video_frame_info* frame_info, hi_u32 color)
{
    hi_vgs_handle handle;
    hi_s32 ret;
    hi_u32 i, j;
    hi_vgs_task_attr vgs_task;
    hi_cover cover;
    hi_sample_svp_rect* rect = (hi_sample_svp_rect*)malloc(sizeof(hi_sample_svp_rect)*people_count);

    fill_rect(rect, people_count);
    hi_mpi_vgs_begin_job(&handle);
    memcpy_s(&vgs_task.img_in, sizeof(hi_video_frame_info), frame_info, sizeof(hi_video_frame_info));
    memcpy_s(&vgs_task.img_out, sizeof(hi_video_frame_info), frame_info, sizeof(hi_video_frame_info));
    cover.type = HI_COVER_QUAD;
    cover.color = color;
    cover.quad.is_solid = HI_FALSE;
    cover.quad.thick = SAMPLE_SVP_NNIE_RECT_THICK;

    for (int i = 0; i < people_count; i++) {
        ret = memcpy_s(cover.quad.point, sizeof(rect[i].point),
                       rect[i].point, sizeof(rect[i].point));
        ret = hi_mpi_vgs_add_cover_task(handle, &vgs_task, &cover, 1);
        if (ret != HI_SUCCESS) {
            hi_mpi_vgs_cancel_job(handle);
        }
    }

    frame_overlay(frame_info, handle, &vgs_task);

    ret = hi_mpi_vgs_end_job(handle);
    if (ret != HI_SUCCESS) {
        hi_mpi_vgs_cancel_job(handle);
    }

    if(rect)
        free(rect);

    return ret;
}

void customize_video_frame(hi_video_frame_info* frame_info,
                           hi_u8* frame, hi_u16 d_w, hi_u16 d_h,
                           hi_u8* bgr_img,   hi_u16 s_w, hi_u16 s_h,
                           hi_u8  channels)
{
    char str_buf[32] = {0};
    sprintf(str_buf, "%d", people_count);
    cv::Mat image = cv::imread("bg.jpg");
    cv::resize(image, image, Size(150, 30));
    cv::putText(image, str_buf, Point(90, 25), cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(255, 255, 255), 2, CV_AA);
    cv::imwrite("alan.bmp", image);
    frame_cover_box(frame_info, SAMPLE_SVP_NNIE_RECT_COLOR);
}

/* thread deals with nnie inference */
static hi_void* thread_process_inference(hi_void* args)
{
    sample_svp_nnie_param *param;
    sample_svp_nnie_yolov3_sw_param *sw_param;
    hi_float print_result_thresh;
    hi_s32 ret;
    sample_svp_nnie_cfg nnie_cfg;
    sample_svp_nnie_forward_info forward_info;

    hi_video_frame_info proc_frame_info;
    hi_s32 milli_sec = 200;
    hi_vo_layer vo_layer = 0;
    hi_vo_chn vo_chn = 0;
    hi_s32 vpss_group = 0;
    hi_s32 vpss_chn[] = {HI_VPSS_CHN0, HI_VPSS_CHN1};
    hi_video_frame video_frame;

    hi_u32 depth = 0;
    int w = 0, h = 0;

    int retry = 3;
    int d_w = MODEL_IMG_WIDTH;
    int d_h = MODEL_IMG_HEIGHT;
    int channels = DEFAULT_CHANNELS;

    int u32Size = 0;
    hi_u8* l_pUserAddr = NULL;
    hi_u8* dst = NULL;
    FILE* fp = NULL;


    param = &g_yolov3_nnie_param;
    sw_param = &g_yolov3_sw_param;

    hi_mpi_vi_get_frame_depth(vpss_chn[1], &depth);
    if(depth == 0)
        hi_mpi_vi_set_frame_depth(vpss_chn[1], 1);

    dst = (hi_u8*)malloc(sizeof(hi_u8)*d_w*d_h*channels);
    if(!dst) {
        printf("[%s] [%d], memory allocating error \n", __func__, __LINE__);
        return HI_NULL;
    }
    memset(dst, 0, d_w*d_h*channels);

    while(retry > 0) {
        ret = hi_mpi_vpss_get_chn_frame(vpss_group, vpss_chn[1], &proc_frame_info, milli_sec);
        if (ret == HI_SUCCESS) {
            break;
        }
        retry--;
    }

    if(retry <= 0) {
        printf("[%s] [%d] , obtaing video fram failed \n", __func__, __LINE__);
        goto out;
    }

    video_frame = proc_frame_info.video_frame;
    w = video_frame.width;
    h = video_frame.height;

    width_scale = ((float)d_w)/w;
    height_scale = ((float)d_h)/h;

    u32Size = video_frame.stride[0]*h*3/2;
    l_pUserAddr =(hi_u8*)hi_mpi_sys_mmap(video_frame.phys_addr[0], u32Size);

    hi_mpi_vpss_release_chn_frame(vpss_group, vpss_chn[1], &proc_frame_info);

    while (HI_TRUE) {

        ret = hi_mpi_vpss_get_chn_frame(vpss_group, vpss_chn[1], &proc_frame_info, milli_sec);
        if (ret != HI_SUCCESS) {
            sample_svp_trace_err("Error(%#x),hi_mpi_vpss_get_chn_frame failed, vpss_group(%d), vpss_chn(%d)!\n",
                                 ret, vpss_group, vpss_chn[1]);
            usleep(100);
            continue;
        }
        video_frame = proc_frame_info.video_frame;

        if(NULL != l_pUserAddr) {

            yuv420sp_to_bgr_planner(l_pUserAddr, dst, w, h, d_w, d_h, channels);

            fp = fopen("alan.bgr", "wb");
            if(!fp) {
                goto proc_release;
            }
            fwrite(dst, 1, d_w*d_h*channels, fp);
            fclose(fp);

            {
                const hi_char* newfile = "alan.bgr";
                sample_common_svp_nnie_fill_src_data(newfile, 0, 0, &g_yolov3_nnie_param);

                forward_info.prev_seg_idx = 0;
                forward_info.proc_seg_idx = 0;
                forward_info.is_instant = HI_TRUE;
                sample_common_svp_nnie_forward(&forward_info, HI_NULL, 1, &g_yolov3_nnie_param);
                sample_common_svp_nnie_print_hw_detect_result(&(g_yolov3_nnie_param.seg_data[0].dst[0]),
                                                              SAMPLE_SVP_NNIE_YOLOV3_CLASS_NUM,
                                                              HI_FALSE, print_result_thresh);
#if 1
                for(int i = 0; i < people_count; i++) {
                    printf("%d %d %d %d \n",
                           personBoxes[i].x_min,
                           personBoxes[i].y_min,
                           personBoxes[i].x_max,
                           personBoxes[i].y_max);
                }
                printf("total people : %d \n", people_count);
#endif

                customize_video_frame(&proc_frame_info, l_pUserAddr, w, h, dst, d_w, d_h, channels);

                people_count = 0;
            }

        }

        hi_mpi_vo_send_frame(vo_layer, vo_chn, &proc_frame_info, milli_sec);

    proc_release:
        hi_mpi_vpss_release_chn_frame(vpss_group, vpss_chn[1], &proc_frame_info);

    }


 out:

    if(dst)
        free(dst);
    if(l_pUserAddr)
        hi_mpi_sys_munmap(l_pUserAddr, u32Size);

    return HI_NULL;
}

/* function: show YOLOV3 sample(image 416x416 U8_C3) */
static hi_s32 sample_svp_nnie_yolov3_detect_out_sw_proc(const hi_char *src_file, const hi_char *model_file)
{
    hi_float print_result_thresh;
    hi_s32 ret;
    sample_svp_nnie_cfg nnie_cfg;
    sample_svp_nnie_forward_info forward_info;

    /* set configuration parameter */
    (hi_void)memset_s(&nnie_cfg, sizeof(sample_svp_nnie_cfg), 0, sizeof(sample_svp_nnie_cfg));
    print_result_thresh = SAMPLE_SVP_NNIE_YOLOV3_CONF_THRESHOLD;
    nnie_cfg.max_input_num = 1;  /* max input image num in each batch */
    nnie_cfg.max_roi_num = 0;
    nnie_cfg.nnie_core_id[0] = HI_SVP_NNIE_ID_0;  /* set NNIE core */
    nnie_cfg.is_sw_gen_bbox = HI_TRUE;

    /* yolov3_detect_out_sw load model */
    sample_svp_trace_info("yolov3 load model!\n");
    ret = sample_common_svp_nnie_load_model(model_file, &g_yolov3_model);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov3_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_load_model failed!\n");

    /*
     * yolov3_detect_out_sw parameter initialization:
     * yolov3_detect_out_sw software parameters are set in sample_svp_nnie_yolov3_sw_init,
     * if user has changed net struct, please make sure the parameter settings in
     * sample_svp_nnie_yolov3_sw_init function are correct
     */
    sample_svp_trace_info("yolov3 parameter initialization!\n");
    g_yolov3_nnie_param.model = &(g_yolov3_model.model);
    ret = sample_svp_nnie_yolov3_param_init(&nnie_cfg, &g_yolov3_nnie_param, &g_yolov3_sw_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov3_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov3_param_init failed!\n");

    /* yolov3_detect_out_sw fill src data */
    sample_svp_trace_info("yolov3 start!\n");
    ret = sample_common_svp_nnie_fill_src_data(src_file, 0, 0, &g_yolov3_nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov3_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_fill_src_data failed!\n");

    /* yolov3_detect_out_sw NNIE process(process the 0-th segment) */
    forward_info.prev_seg_idx = 0;
    forward_info.proc_seg_idx = 0;
    forward_info.is_instant = HI_TRUE;
    ret = sample_common_svp_nnie_forward(&forward_info, HI_NULL, 1, &g_yolov3_nnie_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov3_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_forward failed!\n");

    /*
     * yolov3_detect_out_sw software process:
     * if user has changed net struct, please make sure sample_svp_nnie_yolov3_get_result
     * function input datas are correct
     */
    ret = sample_svp_nnie_yolov3_get_result(&g_yolov3_nnie_param, &g_yolov3_sw_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov3_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov3_get_result failed!\n");

    /*
     * print result, this sample has 81 classes:
     * class 0:person          class 1:bicycle      class 2:car             class 3:motorbike      class 4:aeroplane
     * class 5:bus             class 6:train        class 7:truck           class 8:boat           class 9:traffic light
     * class 10:fire hydrant   class 11:stop sign   class 12:parking meter  class 13:bench         class 14:bird
     * class 15:cat            class 16:dog         class 17:horse          class 18:sheep         class 19:cow
     * class 20:elephant       class 21:bear        class 22:zebra          class 23:giraffe       class 24:backpack
     * class 25:umbrella       class 26:handbag     class 27:tie            class 28:suitcase      class 29:frisbee
     * class 30:skis           class 31:snowboard   class 32:sports ball    class 33:kite          class 34:baseball bat
     * class 35:baseball glove class 36:skateboard  class 37:surfboard      class 38:tennis racket class 39:bottle
     * class 40:wine glass     class 41:cup         class 42:fork           class 43:knife         class 44:spoon
     * class 45:bowl           class 46:banana      class 47:apple          class 48:sandwich      class 49:orange
     * class 50:broccoli       class 51:carrot      class 52:hot dog        class 53:pizza         class 54:donut
     * class 55:cake           class 56:chair       class 57:sofa           class 58:pottedplant   class 59:bed
     * class 60:diningtable    class 61:toilet      class 62:vmonitor       class 63:laptop        class 64:mouse
     * class 65:remote         class 66:keyboard    class 67:cell phone     class 68:microwave     class 69:oven
     * class 70:toaster        class 71:sink        class 72:refrigerator   class 73:book          class 74:clock
     * class 75:vase           class 76:scissors    class 77:teddy bear     class 78:hair drier    class 79:toothbrush
     */
    sample_svp_trace_info("yolov3 result:\n");
    ret = sample_common_svp_nnie_print_sw_detect_result(&(g_yolov3_sw_param.dst_score),
        &(g_yolov3_sw_param.dst_roi), &(g_yolov3_sw_param.class_roi_num), HI_FALSE, print_result_thresh);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov3_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_print_sw_detect_result failed!\n");

yolov3_fail_0:
    sample_svp_nnie_yolov3_deinit(&g_yolov3_nnie_param, &g_yolov3_sw_param, &g_yolov3_model);
    return ret;
}

/* function: show YOLOV3 sample(image 416x416 U8_C3) */
static hi_s32 sample_svp_nnie_yolov3_detect_out_hw_proc(const hi_char *src_file, const hi_char *model_file)
{
    hi_float print_result_thresh;
    hi_s32 ret;
    sample_svp_nnie_cfg nnie_cfg;
    sample_svp_nnie_forward_info forward_info;

    /* set configuration parameter */
    (hi_void)memset_s(&nnie_cfg, sizeof(sample_svp_nnie_cfg), 0, sizeof(sample_svp_nnie_cfg));
    print_result_thresh = SAMPLE_SVP_NNIE_YOLOV3_CONF_THRESHOLD;
    nnie_cfg.max_input_num = 1;  /* max input image num in each batch */
    nnie_cfg.max_roi_num = 0;
    nnie_cfg.nnie_core_id[0] = HI_SVP_NNIE_ID_0;  /* set NNIE core */
    /* set detection out layer's threshold */
    nnie_cfg.threshold_num[0] = 1;
    nnie_cfg.threshold[0][0].min_width = (hi_u32)(0 * SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.threshold[0][0].min_height = (hi_u32)(0 * SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.threshold[0][0].nms_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV3_NMS_THRESHOLD *
        SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.threshold[0][0].score_threshold = (hi_u32)(SAMPLE_SVP_NNIE_YOLOV3_CONF_THRESHOLD *
        SAMPLE_SVP_NNIE_QUANT_BASE);
    nnie_cfg.is_sw_gen_bbox = HI_FALSE;

    /* yolov3_detect_out_hw load model */
    sample_svp_trace_info("yolov3 load model!\n");
    ret = sample_common_svp_nnie_load_model(model_file, &g_yolov3_model);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov3_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_common_svp_nnie_load_model failed!\n");

    /* yolov3_detect_out_hw parameter initialization */
    sample_svp_trace_info("yolov3 parameter initialization!\n");
    g_yolov3_nnie_param.model = &(g_yolov3_model.model);
    ret = sample_svp_nnie_yolov3_param_init(&nnie_cfg, &g_yolov3_nnie_param, &g_yolov3_sw_param);
    sample_svp_check_exps_goto(ret != HI_SUCCESS, yolov3_fail_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,sample_svp_nnie_yolov3_param_init failed!\n");

    thread_process_inference(NULL);

yolov3_fail_0:
    sample_common_svp_stop_vi_vpss_venc_vo(&g_yolov3_vi_config, &g_yolov3_switch);
    sample_svp_nnie_yolov3_deinit(&g_yolov3_nnie_param, &g_yolov3_sw_param, &g_yolov3_model);
    return ret;;
}

/* function : show YOLOV1 sample(image 448x448 U8_C3) */
hi_void sample_svp_nnie_yolov1_detect_out_sw(hi_void)
{
    hi_char *src_file = "./data/nnie_image/rgb_planar/dog_bike_car_448x448.bgr";
    hi_char *model_file = "./data/nnie_model/detection/inst_yolov1_detect_out_sw_cycle.wk";
    hi_s32 ret;
    /* sys init */
    sample_common_svp_check_sys_init();

    ret = sample_svp_nnie_yolov1_detect_out_sw_proc(src_file, model_file);
    if (ret != HI_SUCCESS) {
        sample_svp_trace_info("sample_svp_nnie_yolov1_detect_out_sw_proc failed\n");
    }
    sample_common_svp_check_sys_exit();
}

/* function : show YOLOV1 sample(image 448x448 U8_C3) */
hi_void sample_svp_nnie_yolov1_detect_out_hw(hi_void)
{
    hi_char *src_file = "./data/nnie_image/rgb_planar/dog_bike_car_448x448.bgr";
    hi_char *model_file = "./data/nnie_model/detection/inst_yolov1_detect_out_hw_cycle.wk";
    hi_s32 ret;
    /* sys init */
    sample_common_svp_check_sys_init();

    ret = sample_svp_nnie_yolov1_detect_out_hw_proc(src_file, model_file);
    if (ret != HI_SUCCESS) {
        sample_svp_trace_info("sample_svp_nnie_yolov1_detect_out_hw_proc failed\n");
    }
    sample_common_svp_check_sys_exit();
}

/* function : yolov1 sample signal handle */
hi_void sample_svp_nnie_yolov1_handle_sig(hi_void)
{
    sample_svp_nnie_yolov1_deinit(&g_yolov1_nnie_param, &g_yolov1_sw_param, &g_yolov1_model);
    (hi_void)memset_s(&g_yolov1_nnie_param, sizeof(sample_svp_nnie_param), 0, sizeof(sample_svp_nnie_param));
    (hi_void)memset_s(&g_yolov1_sw_param, sizeof(sample_svp_nnie_yolov1_sw_param),
        0, sizeof(sample_svp_nnie_yolov1_sw_param));
    (hi_void)memset_s(&g_yolov1_model, sizeof(sample_svp_nnie_model), 0, sizeof(sample_svp_nnie_model));
    sample_common_svp_check_sys_exit();
}

/* function : show YOLOV2 sample(image 416x416 U8_C3) */
hi_void sample_svp_nnie_yolov2_detect_out_sw(hi_void)
{
    hi_char *src_file = "./data/nnie_image/rgb_planar/street_cars_416x416.bgr";
    hi_char *model_file = "./data/nnie_model/detection/inst_yolov2_detect_out_sw_cycle.wk";
    hi_s32 ret;
    /* sys init */
    sample_common_svp_check_sys_init();

    ret = sample_svp_nnie_yolov2_detect_out_sw_proc(src_file, model_file);
    if (ret != HI_SUCCESS) {
        sample_svp_trace_info("sample_svp_nnie_yolov2_detect_out_sw_proc failed\n");
    }
    sample_common_svp_check_sys_exit();
}

/* function : show YOLOV2 sample(image 416x416 U8_C3) */
hi_void sample_svp_nnie_yolov2_detect_out_hw(hi_void)
{
    hi_char *src_file = "./data/nnie_image/rgb_planar/street_cars_416x416.bgr";
    hi_char *model_file = "./data/nnie_model/detection/inst_yolov2_detect_out_hw_cycle.wk";
    hi_s32 ret;
    /* sys init */
    sample_common_svp_check_sys_init();

    ret = sample_svp_nnie_yolov2_detect_out_hw_proc(src_file, model_file);
    if (ret != HI_SUCCESS) {
        sample_svp_trace_info("sample_svp_nnie_yolov2_detect_out_hw_proc failed\n");
    }
    sample_common_svp_check_sys_exit();
}

/* function: yolov2 sample signal handle */
hi_void sample_svp_nnie_yolov2_handle_sig(hi_void)
{
    sample_svp_nnie_yolov2_deinit(&g_yolov2_nnie_param, &g_yolov2_sw_param, &g_yolov2_model);
    (hi_void)memset_s(&g_yolov2_nnie_param, sizeof(sample_svp_nnie_param), 0, sizeof(sample_svp_nnie_param));
    (hi_void)memset_s(&g_yolov2_sw_param, sizeof(sample_svp_nnie_yolov2_sw_param), 0,
        sizeof(sample_svp_nnie_yolov2_sw_param));
    (hi_void)memset_s(&g_yolov2_model, sizeof(sample_svp_nnie_model), 0, sizeof(sample_svp_nnie_model));
    sample_common_svp_check_sys_exit();
}

/* function: show YOLOV3 sample(image 416x416 U8_C3) */
hi_void sample_svp_nnie_yolov3_detect_out_sw(hi_void)
{
    hi_char *src_file = "./data/nnie_image/rgb_planar/dog_bike_car_416x416.bgr";
    hi_char *model_file = "./data/nnie_model/detection/inst_yolov3_detect_out_sw_cycle.wk";
    hi_s32 ret;
    /* sys init */
    sample_common_svp_check_sys_init();

    ret = sample_svp_nnie_yolov3_detect_out_sw_proc(src_file, model_file);
    if (ret != HI_SUCCESS) {
        sample_svp_trace_info("sample_svp_nnie_yolov3_detect_out_sw_proc failed\n");
    }
    sample_common_svp_check_sys_exit();
}

/* function: show YOLOV3 sample(image 416x416 U8_C3) */
hi_void sample_svp_nnie_yolov3_detect_out_hw(hi_void)
{
    hi_char *src_file = "./data/nnie_image/rgb_planar/dog_bike_car_416x416.bgr";
    hi_char *model_file = "./data/nnie_model/detection/inst_yolov3_detect_out_hw_cycle.wk";
    hi_s32 ret;

    hi_pic_size pic_type = PIC_720P;

    /* sys init */
    sample_common_svp_check_sys_init();

    ret = sample_common_svp_start_vi_vpss_venc_vo(&g_yolov3_vi_config, &g_yolov3_switch, &pic_type);
    sample_svp_check_exps_return(ret != HI_SUCCESS, ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error(%#x),sample_common_svp_start_vi_vpss_venc_vo failed!\n", ret);

    ret = sample_svp_nnie_yolov3_detect_out_hw_proc(src_file, model_file);
    if (ret != HI_SUCCESS) {
        sample_svp_trace_info("sample_svp_nnie_yolov3_detect_out_hw_proc failed\n");
    }
    sample_common_svp_check_sys_exit();
}

/* function: yolov3 sample signal handle */
hi_void sample_svp_nnie_yolov3_handle_sig(hi_void)
{
    sample_svp_nnie_yolov3_deinit(&g_yolov3_nnie_param, &g_yolov3_sw_param, &g_yolov3_model);
    (hi_void)memset_s(&g_yolov3_nnie_param, sizeof(sample_svp_nnie_param), 0, sizeof(sample_svp_nnie_param));
    (hi_void)memset_s(&g_yolov3_sw_param, sizeof(sample_svp_nnie_yolov3_sw_param),
        0, sizeof(sample_svp_nnie_yolov3_sw_param));
    (hi_void)memset_s(&g_yolov3_model, sizeof(sample_svp_nnie_model), 0, sizeof(sample_svp_nnie_model));
    sample_common_svp_check_sys_exit();
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
